"""Pure binding and narrow executor adapters for compiled operations."""
from __future__ import annotations
import json
import re
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any, Mapping
from scidiscovery.artifact_agent.schema.refs import ArtifactRef
from .spec import (
    CompiledOperation,
    InputPortSpec,
    OutputPortSpec,
)
from scidiscovery.artifact_agent.schema.transform_output import TransformOutput
_RUNTIME_BINDING = re.compile(r"^[a-z][a-z0-9_.-]{0,127}$")
class OperationInvocationError(ValueError):
    def __init__(self, reason_code: str, *, port: str | None = None) -> None:
        self.reason_code = reason_code
        self.port = port
        super().__init__(f"{reason_code}: {port or 'operation'}")
@dataclass(frozen=True, slots=True)
class InvocationArtifact:
    artifact_name: str
    ref: ArtifactRef
    schema_id: str
    media_type: str
    size_bytes: int
    current: bool = False
    parent_refs: tuple[ArtifactRef, ...] = ()
    labels: tuple[tuple[str, str], ...] = ()
    handoff_verdict: str | None = None
@dataclass(frozen=True, slots=True)
class BoundInput:
    port_name: str
    source_name: str
    artifact_name: str
    artifact: InvocationArtifact
    exposure: str
    usage: str
@dataclass(frozen=True, slots=True)
class EffectExecutorPlan:
    executor: str
    preparation_profile: str
    payload_port: str
@dataclass(frozen=True, slots=True)
class BoundOperationCall:
    compiled: CompiledOperation
    name: str
    inputs: tuple[BoundInput, ...]
    instruction: str | None
    executor_plan: EffectExecutorPlan | None = None
@dataclass(frozen=True, slots=True)
class ApprovalSubjectSnapshot:
    subject_index: int
    port_name: str
    item_index: int
    ref: ArtifactRef
    schema_id: str
    media_type: str
    size_bytes: int
    parent_refs: tuple[ArtifactRef, ...]
    labels: tuple[tuple[str, str], ...]
    handoff_verdict: str | None
    content: bytes
@dataclass(frozen=True, slots=True)
class ProducerFamilyMember:
    port_name: str
    item_name: str | None
    ref: ArtifactRef
@dataclass(frozen=True, slots=True)
class ProducerEvidenceSource:
    source_kind: str
    source_name: str
    ref: ArtifactRef
@dataclass(frozen=True, slots=True)
class ProducerOutputFamily:
    primary_ref: ArtifactRef
    operation_id: str
    operation_version: str
    operation_digest: str
    members: tuple[ProducerFamilyMember, ...]
    evidence_sources: tuple[ProducerEvidenceSource, ...]
    reviewer_operation: str | None = None
    review_subject_outputs: tuple[str, ...] = ()
    family_identity: str | None = None
@dataclass(frozen=True, slots=True)
class ApprovalProjectorContext:
    operation_id: str
    operation_version: str
    operation_digest: str
    subjects: tuple[ApprovalSubjectSnapshot, ...]
    producer_families: tuple[ProducerOutputFamily, ...] = ()
_AGENT_INPUT_USAGES = frozenset(
    {
        "claim_evidence",
        "revision_base",
        "change_request",
        "prior_signal",
        "cached_excerpt",
        "evidence_inventory",
    }
)


def direct_revision_ports(
    compiled: CompiledOperation,
) -> tuple[InputPortSpec, OutputPortSpec] | None:
    """Recognize the one complete-object revision shape already in OperationSpec."""

    spec = compiled.spec
    bases = tuple(port for port in spec.inputs if port.usage == "revision_base")
    primary = tuple(port for port in spec.outputs if port.collection is None)
    review = spec.review
    if (
        spec.executor.kind != "agent"
        or spec.consequence != "scientific"
        or len(bases) != 1
        or (bases[0].min_items, bases[0].max_items) != (1, 1)
        or len(primary) != 1
        or any(port.collection is not None for port in spec.outputs)
        or review is None
        or review.reviewer_operation is None
        or review.reviewer_input_port is None
        or review.subject_outputs != (primary[0].name,)
    ):
        return None
    base = bases[0]
    output = primary[0]

    def component_key(reference: Any) -> str:
        return f"{reference.plugin_id or compiled.plugin_id}:{reference.component_id}"

    if (
        output.min_items != 1
        or output.max_items != 1
        or output.schema_id != base.schema_id
        or output.media_types != base.media_types
        or component_key(output.codec) != component_key(base.codec)
        or component_key(output.schema_resource)
        != component_key(base.schema_resource)
    ):
        return None
    return base, output


def preflight_operation(
    compiled: CompiledOperation,
    *,
    name: str,
    artifacts_by_port: Mapping[str, tuple[InvocationArtifact, ...]],
    instruction: str | None,
    parameters: Mapping[str, Any] | None = None,
) -> BoundOperationCall:
    spec = compiled.spec
    expected = {port.name: port for port in spec.inputs}
    if set(artifacts_by_port) != set(expected):
        missing = next(iter(sorted(set(expected) - set(artifacts_by_port))), None)
        extra = next(iter(sorted(set(artifacts_by_port) - set(expected))), None)
        raise OperationInvocationError(
            "input_port_missing" if missing else "input_port_unknown",
            port=missing or extra,
        )
    parameter_map = dict(parameters or {})
    if parameter_map:
        raise OperationInvocationError("parameters_not_declared")
    if spec.executor.kind == "agent":
        if instruction is None or not instruction.strip():
            raise OperationInvocationError("instruction_required")
        try:
            instruction_bytes = instruction.encode("utf-8")
        except UnicodeError as error:
            raise OperationInvocationError("instruction_encoding_invalid") from error
        if len(instruction_bytes) > 65536:
            raise OperationInvocationError("instruction_too_large")
        invalid_usage = next(
            (port.name for port in spec.inputs if port.usage not in _AGENT_INPUT_USAGES),
            None,
        )
        if invalid_usage is not None:
            raise OperationInvocationError(
                "agent_input_usage_invalid", port=invalid_usage
            )
    elif instruction is not None:
        raise OperationInvocationError("instruction_forbidden")
    bound: list[BoundInput] = []
    seen_refs: set[ArtifactRef] = set()
    total_bytes = 0
    for port in spec.inputs:
        artifacts = artifacts_by_port[port.name]
        _validate_port_binding(port, artifacts)
        total_bytes += sum(item.size_bytes for item in artifacts)
        for index, artifact in enumerate(artifacts, start=1):
            if artifact.ref in seen_refs:
                raise OperationInvocationError("input_artifact_duplicate", port=port.name)
            seen_refs.add(artifact.ref)
            source_name = (
                port.name
                if len(artifacts) == 1
                else f"{port.name}_{index:03d}"
            )
            bound.append(
                BoundInput(
                    port_name=port.name,
                    source_name=source_name,
                    artifact_name=artifact.artifact_name,
                    artifact=artifact,
                    exposure=port.exposure,
                    usage=port.usage,
                )
            )
    assert spec.limits is not None
    if total_bytes > spec.limits.max_input_bytes:
        raise OperationInvocationError("input_total_too_large")
    _run_guards(compiled, tuple(bound), parameter_map)
    return BoundOperationCall(
        compiled=compiled,
        name=name,
        inputs=tuple(bound),
        instruction=instruction,
    )
def preflight_result(action: Any) -> dict[str, Any]:
    try:
        bound = action()
    except OperationInvocationError as error:
        return {"admissible": False, "reason_code": error.reason_code,
                "port": error.port, "executor_kind": None}
    return {"admissible": True, "reason_code": None, "port": None,
            "executor_kind": bound.compiled.spec.executor.kind}
def effect_executor_plan(bound: BoundOperationCall) -> EffectExecutorPlan:
    value = effect_operation_plan(bound.compiled)
    if value.payload_port not in {item.port_name for item in bound.inputs}:
        raise OperationInvocationError(
            "effect_payload_port_missing", port=value.payload_port
        )
    return value


def effect_operation_plan(compiled: CompiledOperation) -> EffectExecutorPlan:
    if compiled.spec.executor.kind != "effect":
        raise OperationInvocationError("effect_executor_required")
    try:
        value = _executor_callable(compiled)()
    except Exception as error:
        raise OperationInvocationError("executor_component_failed") from error
    if not isinstance(value, EffectExecutorPlan):
        raise OperationInvocationError("effect_executor_result_invalid")
    if _RUNTIME_BINDING.fullmatch(value.executor) is None:
        raise OperationInvocationError("effect_executor_result_invalid")
    if value.payload_port not in {item.name for item in compiled.spec.inputs}:
        raise OperationInvocationError(
            "effect_payload_port_missing", port=value.payload_port
        )
    return EffectExecutorPlan(
        executor=f"{compiled.plugin_id}:{value.executor}",
        preparation_profile=value.preparation_profile,
        payload_port=value.payload_port,
    )
def operation_primary_output(compiled: CompiledOperation) -> OutputPortSpec:
    return next(port for port in compiled.spec.outputs if port.collection is None)
def operation_port_json_schema(
    compiled: CompiledOperation, port: OutputPortSpec
) -> dict[str, Any]:
    """Return the exact Worker-visible schema, including runtime semantics."""
    key = f"{port.schema_resource.plugin_id or compiled.plugin_id}:{port.schema_resource.component_id}"
    schema = json.loads(compiled.implementations[key])
    if port.semantic_contract is not None:
        owner = port.semantic_contract.plugin_id or compiled.plugin_id
        contract_key = f"{owner}:{port.semantic_contract.component_id}"
        schema["x-scidiscovery-semantic-constraints"] = json.loads(
            compiled.implementations[contract_key]
        )
    return schema
class CompiledTransformAdapter:
    def __init__(self, bound: BoundOperationCall) -> None:
        if bound.compiled.spec.executor.kind != "transform":
            raise OperationInvocationError("transform_executor_required")
        self.bound = bound
    def supports_transform_profile(self, profile: str) -> bool:
        return profile == self.bound.compiled.spec.operation_id
    def required_input_parentage(self, profile: str) -> tuple[tuple[str, str], ...]:
        return ()
    def nonqualifying_input_names(
        self, profile: str, input_names: tuple[str, ...]
    ) -> tuple[str, ...]:
        expected = tuple(item.source_name for item in self.bound.inputs)
        if not self.supports_transform_profile(profile) or input_names != expected:
            return ()
        return tuple(
            item.source_name
            for item in self.bound.inputs
            if self.bound.compiled.spec.consequence == "explore"
            or item.usage != "claim_evidence"
        )
    def payload_input_names(
        self, profile: str, input_names: tuple[str, ...]
    ) -> tuple[str, ...]:
        expected = tuple(item.source_name for item in self.bound.inputs)
        if not self.supports_transform_profile(profile) or input_names != expected:
            return ()
        return tuple(item.source_name for item in self.bound.inputs
                     if item.exposure != "handoff_only")
    def transform(
        self, *, profile: str, inputs: Mapping[str, bytes]
    ) -> tuple[TransformOutput, ...]:
        if not self.supports_transform_profile(profile):
            raise ValueError("compiled transform profile differs from operation")
        grouped: dict[str, list[bytes]] = {}
        for item in self.bound.inputs:
            grouped.setdefault(item.port_name, []).append(inputs[item.source_name])
        try:
            value = _executor_callable(self.bound.compiled)(
                MappingProxyType({key: tuple(items) for key, items in grouped.items()})
            )
        except Exception as error:
            raise OperationInvocationError("executor_component_failed") from error
        if not isinstance(value, Mapping):
            raise ValueError("transform component must return an output mapping")
        return _transform_outputs(self.bound.compiled, value)
def _validate_port_binding(
    port: InputPortSpec, artifacts: tuple[InvocationArtifact, ...]
) -> None:
    if not port.min_items <= len(artifacts) <= port.max_items:
        raise OperationInvocationError("input_cardinality_invalid", port=port.name)
    wildcard = port.schema_id == "*" and port.media_types == ("*/*",)
    for artifact in artifacts:
        if not wildcard and artifact.schema_id != port.schema_id:
            raise OperationInvocationError("input_schema_mismatch", port=port.name)
        if not wildcard and artifact.media_type not in port.media_types:
            raise OperationInvocationError("input_media_type_mismatch", port=port.name)
        if artifact.size_bytes > port.max_item_bytes:
            raise OperationInvocationError("input_item_too_large", port=port.name)
        if port.require_current and not artifact.current:
            raise OperationInvocationError("input_not_current", port=port.name)
def _run_guards(
    compiled: CompiledOperation,
    inputs: tuple[BoundInput, ...],
    parameters: Mapping[str, Any],
) -> None:
    for reference in compiled.spec.guards:
        key = f"{reference.plugin_id or compiled.plugin_id}:{reference.component_id}"
        try:
            accepted = compiled.implementations[key](inputs, parameters)
        except Exception as error:
            raise OperationInvocationError("guard_failed", port=reference.component_id) from error
        if accepted is not True:
            raise OperationInvocationError("guard_rejected", port=reference.component_id)
def _executor_callable(compiled: CompiledOperation) -> Any:
    reference = compiled.spec.executor.component
    key = f"{reference.plugin_id or compiled.plugin_id}:{reference.component_id}"
    return compiled.implementations[key]
def _transform_outputs(
    compiled: CompiledOperation, values: Mapping[Any, Any]
) -> tuple[TransformOutput, ...]:
    ports = {port.name: port for port in compiled.spec.outputs}
    if set(values) != set(ports):
        raise ValueError("transform output ports differ from the compiled operation")
    outputs: list[TransformOutput] = []
    for port in compiled.spec.outputs:
        raw_items = values[port.name]
        if not isinstance(raw_items, tuple) or not all(
            isinstance(item, bytes) for item in raw_items
        ):
            raise ValueError("transform output items must be a tuple of bytes")
        if not port.min_items <= len(raw_items) <= port.max_items:
            raise ValueError("transform output cardinality is invalid")
        for index, raw in enumerate(raw_items, start=1):
            _validate_transform_item(compiled, port, raw)
            label = ("primary" if not outputs else port.name
                     if port.collection is None and len(raw_items) == 1
                     else f"{port.name}_{index:03d}")
            outputs.append(
                TransformOutput(
                    label=label,
                    port_name=port.name,
                    content=raw,
                    kind=port.kind,
                    schema=port.schema_id,
                    payload_schema_version=port.payload_schema_version,
                    media_type=port.media_types[0],
                )
            )
    if not outputs:
        raise ValueError("transform operation produced no output")
    return tuple(outputs)
def _validate_transform_item(
    compiled: CompiledOperation, port: OutputPortSpec, raw: bytes
) -> None:
    if len(raw) > port.max_item_bytes:
        raise ValueError("transform output item exceeds its port limit")
    if port.validator is None:
        return
    key = f"{port.validator.plugin_id or compiled.plugin_id}:{port.validator.component_id}"
    compiled.implementations[key](raw)
__all__ = [
    "BoundOperationCall",
    "CompiledTransformAdapter",
    "EffectExecutorPlan",
    "InvocationArtifact",
    "OperationInvocationError",
    "operation_port_json_schema",
    "effect_executor_plan",
    "effect_operation_plan",
    "direct_revision_ports",
    "preflight_operation",
    "preflight_result",
    "operation_primary_output",
]
