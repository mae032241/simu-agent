"""Frozen, state-free declarations for plugin-provided operations."""
from __future__ import annotations
import hashlib
import json
import re
from dataclasses import dataclass, fields, is_dataclass
from typing import Any, Literal, Mapping
from pydantic import BaseModel, ConfigDict, Field
PLUGIN_PROTOCOL_VERSION = "1"
OPERATION_ABI_VERSION = "9"
_ID = re.compile(r"^[a-z][a-z0-9_.-]{0,127}$")
_JSON_POINTER = re.compile(r"^/(?:[^~/]|~[01])*(?:/(?:[^~/]|~[01])*)*$")
_DOMAIN = re.compile(r"^(?:\*\.)?[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?"
                     r"(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+$")
_DECISIONS = frozenset({"accept", "reject", "revise", "accept_with_exception"})
_INPUT_USAGES = frozenset({"claim_evidence", "revision_base", "change_request",
                           "prior_signal", "cached_excerpt",
                           "evidence_inventory"})
class FrozenSpec(BaseModel):
    model_config = ConfigDict(
        frozen=True, extra="forbid", strict=True, populate_by_name=True
    )
    def __init__(self, *values: Any, **data: Any) -> None:
        names = tuple(type(self).model_fields)
        if len(values) > len(names) or any(name in data for name in names[:len(values)]):
            raise TypeError("invalid positional declaration fields")
        super().__init__(**dict(zip(names, values)), **data)
class ComponentRef(FrozenSpec):
    component_id: str; plugin_id: str | None = None
class ComponentSpec(FrozenSpec):
    component_id: str
    kind: str
    implementation: str
    protocol_version: str = "1"
    resources: tuple[ComponentRef, ...] = ()
    public: bool = False
    configuration_identity: str | None = None
@dataclass(frozen=True, slots=True)
class CallableComponent:
    kind: str; implementation: Any
class WorkspaceContract(FrozenSpec):
    input_directory: str = "inputs"; output_directory: str = "output"
    scratch_directory: str = "scratch"
class CollectionSpec(FrozenSpec):
    max_total_bytes: int; bundle_validator: ComponentRef | None = None
class OperationDescription(FrozenSpec):
    purpose: str; applies_when: str
    not_for: str
class PortSpec(FrozenSpec):
    name: str
    description: str
    schema_id: str = Field(alias="schema")
    media_types: tuple[str, ...]
    codec: ComponentRef
    schema_resource: ComponentRef
    min_items: int = 1
    max_items: int = 1
    max_item_bytes: int = 1024 * 1024
    def issue(self) -> str | None:
        if (not _ID.fullmatch(self.name) or not all((self.description, self.schema_id))
                or not self.media_types or len(self.media_types) != len(set(self.media_types))
                or any(not item for item in self.media_types)):
            return "port_invalid"
        if self.min_items < 0 or self.max_items < max(1, self.min_items):
            return "port_cardinality_invalid"
        return "port_size_invalid" if self.max_item_bytes <= 0 else None
class InputPortSpec(PortSpec):
    usage: str = "scientific_input"
    exposure: str = "handoff_only"
    require_current: bool = False
    cohort_id: str | None = None
    approval_kind: str | None = None
    accepted_approval_options: tuple[str, ...] = ()
    accepted_approval_operations: tuple[str, ...] = ()
    def issue(self) -> str | None:
        wildcard = self.schema_id == "*" or self.media_types == ("*/*",)
        if wildcard and not (
            self.schema_id == "*"
            and self.media_types == ("*/*",)
            and self.exposure == "handoff_only"
            and self.usage == "evidence_inventory"
        ):
            return "input_wildcard_invalid"
        issue = super().issue() or (None if self.exposure in {
            "full", "on_demand", "handoff_only"
        } else "input_exposure_invalid")
        if issue is not None:
            return issue
        if self.cohort_id is not None and _ID.fullmatch(self.cohort_id) is None:
            return "input_cohort_invalid"
        if self.approval_kind is not None and (
            self.cohort_id is None or not self.approval_kind
            or not self.accepted_approval_options
            or not self.accepted_approval_operations
            or len(self.accepted_approval_options)
            != len(set(self.accepted_approval_options))
        ):
            return "input_cohort_approval_invalid"
        if self.approval_kind is None and (
            self.accepted_approval_options or self.accepted_approval_operations
        ):
            return "input_cohort_approval_invalid"
        if (
            len(self.accepted_approval_operations)
            != len(set(self.accepted_approval_operations))
            or any(_ID.fullmatch(item) is None for item in self.accepted_approval_operations)
        ):
            return "input_approval_provider_invalid"
        return None
class OutputPortSpec(PortSpec):
    kind: str
    payload_schema_version: int = Field(default=1, ge=1)
    validator: ComponentRef | None = None
    semantic_contract: ComponentRef | None = None
    collection: CollectionSpec | None = None
    context_validator: ComponentRef | None = None
    context_sources: tuple[str, ...] = ()
    evidence_paths: tuple[str, ...] = ()
    allowed_input_usages: tuple[str, ...] = ()
    def issue(self) -> str | None:
        issue = super().issue() or (None if self.kind else "port_invalid")
        if issue is not None:
            return issue
        if (
            len(self.evidence_paths) != len(set(self.evidence_paths))
            or any(_JSON_POINTER.fullmatch(path) is None for path in self.evidence_paths)
        ):
            return "output_evidence_path_invalid"
        if (
            not self.allowed_input_usages
            or len(self.allowed_input_usages) != len(set(self.allowed_input_usages))
            or not set(self.allowed_input_usages) <= _INPUT_USAGES
        ):
            return "output_usage_invalid"
        return None
class NativeToolPolicy(FrozenSpec):
    shell: str = "none"
    view_image: bool = False
    def issue(self) -> str | None:
        return (
            None
            if self.shell in {"none", "sandboxed", "inherited_prototype"}
            else "native_tool_policy_unsupported"
        )
class ExecutorRef(FrozenSpec):
    kind: str
    component: ComponentRef
    workspace: ComponentRef | None = None
    tools: tuple[ComponentRef, ...] = ()
    resources: tuple[ComponentRef, ...] = ()
    prompt: ComponentRef | None = None
    model: str | None = None
    native_tools: NativeToolPolicy = NativeToolPolicy()
class NetworkPolicy(FrozenSpec):
    mode: str = "none"
    allowed_domains: tuple[str, ...] = ()
    max_requests: int = 0
    def issue(self) -> str | None:
        if self.mode == "none":
            return "network_not_default_deny" if self.allowed_domains or self.max_requests else None
        if self.mode != "restricted":
            return "network_mode_invalid"
        domains = self.allowed_domains
        if (not domains or self.max_requests <= 0 or len(domains) != len(set(domains))
                or any(not _DOMAIN.fullmatch(domain) for domain in domains)):
            return "network_scope_invalid"
        return None
class LimitsSpec(FrozenSpec):
    timeout_seconds: int
    max_input_bytes: int
    max_output_bytes: int
    max_files: int
    max_attempts: int = 1
    network: NetworkPolicy = NetworkPolicy()
    def issue(self) -> str | None:
        values = (self.timeout_seconds, self.max_input_bytes, self.max_output_bytes,
                  self.max_files, self.max_attempts)
        return "limits_invalid" if min(values) <= 0 or self.max_attempts > 3 else self.network.issue()
class ApprovalOption(FrozenSpec):
    label: str; decision: str
    requires_reason: bool = False
    description: str | None = None
class ApprovalContract(FrozenSpec):
    subject_ports: tuple[str, ...]
    question: str
    options: tuple[ApprovalOption, ...]
    projector: ComponentRef | None = None
    kind: str = "execution_authorization"
    def issue(self, port_names: set[str], external: bool) -> str | None:
        subjects = set(self.subject_ports)
        if (not subjects or len(subjects) != len(self.subject_ports)
                or not subjects <= port_names):
            return "approval_subject_missing"
        decision_set = {item.decision for item in self.options}
        if external and (
            "reject" not in decision_set
            or not decision_set.intersection({"accept", "accept_with_exception"})
        ):
            return "external_approval_options_invalid"
        if (
            not 1 <= len(self.question) <= 16384
            or not 2 <= len(self.options) <= 32
            or self.projector is None
            or _ID.fullmatch(self.kind) is None
        ):
            return "approval_contract_invalid"
        labels = [item.label for item in self.options]
        decisions = [item.decision for item in self.options]
        if (
            len(labels) != len(set(labels))
            or len(decisions) != len(set(decisions))
            or any(
                not 1 <= len(item.label) <= 256
                or item.decision not in _DECISIONS
                or not 1 <= len(item.description or item.label) <= 4096
                for item in self.options
            )
        ):
            return "approval_option_invalid"
        if any(item.decision == "accept_with_exception" and not item.requires_reason
               for item in self.options):
            return "approval_reason_required"
        return None
class ReviewSpec(FrozenSpec):
    reviewer_operation: str | None = None; reviewer_input_port: str | None = None
    subject_outputs: tuple[str, ...] = ()
    accepted_verdicts: tuple[Literal["pass", "inconclusive"], ...] = ("pass",)
    approval: ApprovalContract | None = None
class OperationSpec(FrozenSpec):
    operation_id: str
    version: str
    catalog_scope: Literal["public", "support", "internal"]
    description: OperationDescription
    executor: ExecutorRef
    inputs: tuple[InputPortSpec, ...]
    outputs: tuple[OutputPortSpec, ...]
    consequence: str
    review: ReviewSpec | None = None
    guards: tuple[ComponentRef, ...] = ()
    limits: LimitsSpec | None = None
    def bounds_issue(self) -> str | None:
        if self.limits is None:
            return "limits_invalid"
        output_bytes = sum(
            p.collection.max_total_bytes if p.collection else p.max_items * p.max_item_bytes
            for p in self.outputs
        )
        if any(
            p.collection and p.collection.max_total_bytes <= 0 for p in self.outputs
        ):
            return "input_or_collection_limit_invalid"
        if (output_bytes > self.limits.max_output_bytes
                or sum(p.max_items for p in self.outputs) > self.limits.max_files):
            return "output_limits_inconsistent"
        return None
class PluginDependency(FrozenSpec):
    plugin_id: str; version: str | None = None
class PluginDefinition(FrozenSpec):
    plugin_id: str
    version: str
    protocol_version: str
    components: tuple[ComponentSpec, ...]
    operations: tuple[OperationSpec, ...]
    dependencies: tuple[PluginDependency, ...] = ()
    configuration_schema: ComponentRef | None = None
    runtime_factory: ComponentRef | None = None
class AgentLifecycleTool(FrozenSpec):
    name: str
    description: str
    input_schema_sha256: str
    capability: str
class AgentLifecycleProtocol(FrozenSpec):
    version: str
    tools: tuple[AgentLifecycleTool, ...]
@dataclass(frozen=True, slots=True)
class PermissionTemplate:
    inputs: tuple[tuple[str, str, int, int], ...]
    workspace: str
    tools: tuple[str, ...]
    resources: tuple[str, ...]
    model: str
    native_tools: NativeToolPolicy
    limits: LimitsSpec
    lifecycle: AgentLifecycleProtocol
@dataclass(frozen=True, slots=True)
class CompiledComponent:
    plugin_id: str
    spec: ComponentSpec
    implementation: Any
    resource_digest: str | None
@dataclass(frozen=True, slots=True)
class CompiledOperation:
    plugin_id: str
    spec: OperationSpec
    component_ids: tuple[str, ...]
    implementations: Mapping[str, Any]
    component_specs: Mapping[str, ComponentSpec]
    permission_template: PermissionTemplate | None
    digest: str
    approval_identity: ApprovalProviderIdentity | None
    approval_providers: Mapping[str, tuple[ApprovalProviderIdentity, ...]]
class ApprovalProviderIdentity(FrozenSpec):
    operation_id: str
    version: str
    operation_digest: str
    approval_contract_digest: str
class SchedulerPortView(FrozenSpec):
    name: str; description: str
    schema_id: str = Field(alias="schema")
    min_items: int
    max_items: int
    cohort_id: str | None = None
    approval_kind: str | None = None
    accepted_approval_options: tuple[str, ...] = ()
    accepted_approval_operations: tuple[str, ...] = ()
class SchedulerOperationView(FrozenSpec):
    operation_id: str
    version: str
    executor_kind: str
    catalog_scope: str
    purpose: str
    applies_when: str
    not_for: str
    inputs: tuple[SchedulerPortView, ...]
    outputs: tuple[SchedulerPortView, ...]
    consequence: str
    timeout_seconds: int
    max_input_bytes: int
    max_output_bytes: int
    max_files: int
    network_mode: str
    max_network_requests: int
    native_shell: str
    native_view_image: bool
    requires_independent_review: bool
    requires_human_approval: bool
@dataclass(frozen=True, slots=True)
class CompiledDigestEnvelope:
    abi_version: str
    plugin_id: str
    plugin_version: str
    operation: OperationSpec
    components: tuple[tuple[str, str, ComponentSpec, str | None], ...]
    permission_template: PermissionTemplate | None
    reviewer_digest: str | None
    approval_providers: tuple[
        tuple[str, tuple[ApprovalProviderIdentity, ...]], ...
    ] = ()
def scheduler_operation_view(spec: OperationSpec) -> SchedulerOperationView:
    if spec.limits is None:
        raise ValueError("an uncompiled operation has no limits")
    input_port = lambda item: SchedulerPortView(
        name=item.name, description=item.description, schema=item.schema_id,
        min_items=item.min_items, max_items=item.max_items,
        cohort_id=item.cohort_id, approval_kind=item.approval_kind,
        accepted_approval_options=item.accepted_approval_options,
        accepted_approval_operations=item.accepted_approval_operations,
    )
    output_port = lambda item: SchedulerPortView(
        name=item.name, description=item.description, schema=item.schema_id,
        min_items=item.min_items, max_items=item.max_items,
    )
    return SchedulerOperationView(
        operation_id=spec.operation_id, version=spec.version,
        executor_kind=spec.executor.kind,
        catalog_scope=spec.catalog_scope,
        purpose=spec.description.purpose, applies_when=spec.description.applies_when,
        not_for=spec.description.not_for,
        inputs=tuple(input_port(item) for item in spec.inputs),
        outputs=tuple(output_port(item) for item in spec.outputs), consequence=spec.consequence,
        timeout_seconds=spec.limits.timeout_seconds,
        max_input_bytes=spec.limits.max_input_bytes,
        max_output_bytes=spec.limits.max_output_bytes, max_files=spec.limits.max_files,
        network_mode=spec.limits.network.mode,
        max_network_requests=spec.limits.network.max_requests,
        native_shell=spec.executor.native_tools.shell,
        native_view_image=spec.executor.native_tools.view_image,
        requires_independent_review=bool(spec.review and spec.review.reviewer_operation),
        requires_human_approval=bool(spec.review and spec.review.approval),
    )
def _canonical_value(value: Any) -> Any:
    if isinstance(value, BaseModel):
        return _canonical_value(value.model_dump(mode="python", by_alias=True))
    if is_dataclass(value) and not isinstance(value, type):
        return {field.name: _canonical_value(getattr(value, field.name)) for field in fields(value)}
    if isinstance(value, Mapping):
        return {str(key): _canonical_value(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_canonical_value(item) for item in value]
    if value is None or isinstance(value, (bool, int, str)):
        return value
    raise TypeError(f"unsupported canonical value: {type(value).__name__}")
def canonical_json(value: Any) -> str:
    return json.dumps(_canonical_value(value), ensure_ascii=False,
                      separators=(",", ":"), sort_keys=True)
def canonical_digest(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()
