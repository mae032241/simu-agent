"""Domain-neutral Agent Operation declarations; no registration side effects."""

from __future__ import annotations

from .operation_declaration import scientific_agent_operation
from .operations.spec import CollectionSpec, ComponentRef, InputPortSpec, OperationSpec, OutputPortSpec, ReviewSpec

JSON_CODEC = ComponentRef("json_codec")
OPAQUE_CODEC = ComponentRef("opaque_codec")
WORKSPACE_REF = ComponentRef("workspace")
BUILTIN = "builtin"
_EVIDENCE_APPROVAL_PROVIDER = ("science.evidence.qualify.v1",)


def _ref(component_id: str) -> ComponentRef:
    if component_id in {
        "file_write_begin_tool",
        "file_write_chunk_tool",
        "file_write_commit_tool",
    }:
        return ComponentRef(component_id, plugin_id=BUILTIN)
    return ComponentRef(component_id)


BASE_TOOLS = tuple(
    _ref(name)
    for name in (
        "file_write_begin_tool",
        "file_write_chunk_tool",
        "file_write_commit_tool",
        "file_apply_patch_tool",
    )
)


def _input(
    name: str,
    description: str,
    schema: str,
    *,
    media_types: tuple[str, ...] = ("application/json",),
    min_items: int = 1,
    max_items: int = 1,
    max_item_bytes: int = 1024 * 1024,
    exposure: str = "full",
    usage: str = "claim_evidence",
    cohort_id: str | None = None,
    approval_kind: str | None = None,
    accepted_approval_options: tuple[str, ...] = (),
    accepted_approval_operations: tuple[str, ...] = (),
) -> InputPortSpec:
    return InputPortSpec(
        name=name,
        description=description,
        schema=schema,
        media_types=media_types,
        codec=OPAQUE_CODEC if schema in {"opaque", "*"} else JSON_CODEC,
        schema_resource=ComponentRef(_schema_component(schema)),
        min_items=min_items,
        max_items=max_items,
        max_item_bytes=max_item_bytes,
        exposure=exposure,
        usage=usage,
        cohort_id=cohort_id,
        approval_kind=approval_kind,
        accepted_approval_options=accepted_approval_options,
        accepted_approval_operations=accepted_approval_operations,
    )


def _output(
    name: str,
    description: str,
    kind: str,
    schema: str,
    validator: str,
    *,
    allowed_input_usages: tuple[str, ...],
    max_item_bytes: int,
    media_types: tuple[str, ...] = ("application/json",),
    min_items: int = 1,
    max_items: int = 1,
    collection: CollectionSpec | None = None,
    context_validator: str | None = None,
    context_sources: tuple[str, ...] = (),
    semantic_contract: str | None = None,
    evidence_paths: tuple[str, ...] | None = None,
) -> OutputPortSpec:
    return OutputPortSpec(
        name=name,
        description=description,
        kind=kind,
        schema=schema,
        media_types=media_types,
        codec=OPAQUE_CODEC if schema == "opaque" else JSON_CODEC,
        schema_resource=ComponentRef(_schema_component(schema)),
        min_items=min_items,
        max_items=max_items,
        max_item_bytes=max_item_bytes,
        validator=ComponentRef(validator),
        semantic_contract=ComponentRef(
            semantic_contract or _semantic_component(schema)
        ),
        collection=collection,
        context_validator=(
            ComponentRef(context_validator) if context_validator is not None else None
        ),
        context_sources=context_sources,
        evidence_paths=(
            _EVIDENCE_PATHS_BY_SCHEMA.get(schema, ())
            if evidence_paths is None
            else evidence_paths
        ),
        allowed_input_usages=allowed_input_usages,
    )


_EVIDENCE_PATHS_BY_SCHEMA = {
    "scidiscovery.scientific-intake.v1": ("/scientific_foundation/evidence",),
    "scidiscovery.scientific-foundation.v1": ("/evidence",),
    "scidiscovery.hypothesis-proposal.v1": ("/evidence",),
    "scidiscovery.critic-review.v1": ("/evidence",),
    "scidiscovery.evidence-audit.v1": ("/evidence",),
    "scidiscovery.scientific-review.v1": ("/evidence",),
}


def _schema_component(schema: str) -> str:
    return {
        "opaque": "opaque_schema",
        "scidiscovery.scientific-intake.v1": "scientific_intake_schema",
        "scidiscovery.scientific-foundation.v1": "scientific_foundation_schema",
        "scidiscovery.problem-frame.v1": "problem_frame_schema",
        "scidiscovery.hypothesis-proposal.v1": "hypothesis_schema",
        "scidiscovery.critic-review.v1": "critic_review_schema",
        "scidiscovery.evidence-audit.v1": "evidence_audit_schema",
        "scidiscovery.research-objective.v1": "research_objective_schema",
        "scidiscovery.experiment-design-intent.v1": "experiment_intent_schema",
        "scidiscovery.experiment-portfolio.v1": "experiment_portfolio_schema",
        "scidiscovery.scientific-review.v1": "scientific_review_schema",
        "*": "wildcard_schema",
    }[schema]


def _semantic_component(schema: str) -> str:
    return {
        "opaque": "intake_semantic_contract",
        "scidiscovery.scientific-intake.v1": "intake_semantic_contract",
        "scidiscovery.hypothesis-proposal.v1": "hypothesis_semantic_contract",
        "scidiscovery.critic-review.v1": "critic_semantic_contract",
        "scidiscovery.evidence-audit.v1": "evidence_audit_semantic_contract",
        "scidiscovery.experiment-design-intent.v1": "experiment_semantic_contract",
        "scidiscovery.experiment-portfolio.v1": "experiment_semantic_contract",
        "scidiscovery.scientific-review.v1": "scientific_review_semantic_contract",
    }[schema]


def _agent(
    operation_id: str,
    purpose: str,
    applies_when: str,
    not_for: str,
    *,
    agent: str,
    prompt: str,
    inputs: tuple[InputPortSpec, ...],
    outputs: tuple[OutputPortSpec, ...],
    timeout: int,
    max_input_bytes: int,
    max_output_bytes: int,
    max_files: int,
    tools: tuple[ComponentRef, ...] = BASE_TOOLS,
    native_view_image: bool = False,
    review: ReviewSpec | None = None,
    guards: tuple[str, ...] = (),
    consequence: str = "scientific",
) -> OperationSpec:
    return scientific_agent_operation(
        operation_id,
        purpose,
        applies_when,
        not_for,
        agent=ComponentRef(agent),
        workspace=WORKSPACE_REF,
        prompt=ComponentRef(prompt),
        tools=tools,
        inputs=inputs,
        outputs=outputs,
        timeout=timeout,
        max_input_bytes=max_input_bytes,
        max_output_bytes=max_output_bytes,
        max_files=max_files,
        native_view_image=native_view_image,
        review=review,
        guards=tuple(ComponentRef(item) for item in guards),
        consequence=consequence,
    )


INTAKE_OUTPUT = _output(
    "scientific_intake",
    "Concise problem frame and source-bound scientific foundation.",
    "scientific_intake",
    "scidiscovery.scientific-intake.v1",
    "intake_validator",
    allowed_input_usages=("prior_signal", "revision_base"),
    max_item_bytes=64 * 1024,
)
HYPOTHESIS_OUTPUT = _output(
    "hypothesis_portfolio",
    "Distinct falsifiable hypothesis proposal.",
    "hypothesis_portfolio",
    "scidiscovery.hypothesis-proposal.v1",
    "hypothesis_validator",
    allowed_input_usages=("prior_signal", "revision_base"),
    max_item_bytes=64 * 1024,
)
def _audit_output(*context_sources: str) -> OutputPortSpec:
    return _output(
        "evidence_audit",
        "Independent evidence and provenance audit.",
        "evidence_audit",
        "scidiscovery.evidence-audit.v1",
        "audit_validator",
        allowed_input_usages=(
            "change_request", "prior_signal", "evidence_inventory",
        ),
        max_item_bytes=32 * 1024,
        context_validator="evidence_audit_context",
        context_sources=context_sources,
    )


OPERATIONS = (
    _agent(
        "science.evidence.audit.v1",
        "Audit one scientific foundation against its exact supplied sources.",
        "A foundation exists and its source support must be checked independently.",
        "Extracting evidence, generating mechanisms, or granting qualification.",
        agent="auditor_agent",
        prompt="auditor_prompt",
        inputs=(
            _input(
                "scientific_foundation",
                "Scientific foundation under independent audit.",
                "scidiscovery.scientific-foundation.v1",
                usage="prior_signal",
            ),
            _input(
                "source_material",
                "Exact frozen source material cited by the foundation.",
                "opaque",
                media_types=(
                    "application/json",
                    "application/pdf",
                    "image/png",
                    "image/jpeg",
                    "image/webp",
                    "text/plain",
                    "text/plain; charset=utf-8",
                    "text/csv",
                ),
                min_items=0,
                max_items=6,
                max_item_bytes=16 * 1024 * 1024,
                exposure="on_demand",
                usage="evidence_inventory",
            ),
        ),
        outputs=(_audit_output("scientific_foundation", "source_material"),),
        timeout=600,
        max_input_bytes=97 * 1024 * 1024,
        max_output_bytes=32 * 1024,
        max_files=1,
        tools=BASE_TOOLS + (_ref("pdf_extract_tool"),),
        native_view_image=True,
    ),
    _agent(
        "science.evidence.audit.intake.v1",
        "Audit one extracted ScientificIntake against its exact supplied sources.",
        "A provisional intake must be checked before its claims are qualified.",
        "Creating the intake or approving it.",
        agent="auditor_agent",
        prompt="auditor_prompt",
        inputs=(
            _input(
                "scientific_intake",
                "Provisional scientific intake under review.",
                "scidiscovery.scientific-intake.v1",
                usage="prior_signal",
            ),
            _input(
                "source_material",
                "Exact frozen source material used by the intake.",
                "opaque",
                media_types=(
                    "application/json",
                    "application/pdf",
                    "image/png",
                    "image/jpeg",
                    "image/webp",
                    "text/plain",
                    "text/plain; charset=utf-8",
                    "text/csv",
                ),
                min_items=1,
                max_items=6,
                max_item_bytes=16 * 1024 * 1024,
                exposure="on_demand",
                usage="evidence_inventory",
            ),
        ),
        outputs=(_audit_output("scientific_intake", "source_material"),),
        timeout=600,
        max_input_bytes=97 * 1024 * 1024,
        max_output_bytes=32 * 1024,
        max_files=1,
        tools=BASE_TOOLS + (_ref("pdf_extract_tool"),),
        native_view_image=True,
    ),
    _agent(
        "science.evidence.extract.v1",
        "Extract one bounded ScientificIntake from supplied immutable sources.",
        "The objective needs a source-backed problem frame and foundation.",
        "Quantitative raster-figure digitization or parameter-specific extraction.",
        agent="evidence_agent",
        prompt="evidence_prompt",
        inputs=(
            _input(
                "source_material",
                "Immutable paper, text, table, or user-supplied source.",
                "opaque",
                media_types=(
                    "application/json",
                    "application/pdf",
                    "image/png",
                    "image/jpeg",
                    "image/webp",
                    "text/plain",
                    "text/plain; charset=utf-8",
                    "text/csv",
                ),
                max_items=6,
                max_item_bytes=16 * 1024 * 1024,
            ),
        ),
        outputs=(INTAKE_OUTPUT,),
        timeout=900,
        max_input_bytes=96 * 1024 * 1024,
        max_output_bytes=64 * 1024,
        max_files=1,
        tools=BASE_TOOLS + (_ref("pdf_extract_tool"),),
        native_view_image=True,
        review=ReviewSpec(
            reviewer_operation="science.evidence.audit.intake.v1",
            reviewer_input_port="scientific_intake",
            subject_outputs=("scientific_intake",),
        ),
    ),
    _agent(
        "science.hypothesis.criticize.v1",
        "Adversarially review every proposed hypothesis.",
        "A hypothesis portfolio and its scientific foundation are available.",
        "Generating hypotheses or deciding qualification.",
        agent="critic_agent",
        prompt="critic_prompt",
        inputs=(
            _input(
                "hypothesis_portfolio",
                "Exact hypothesis proposal under review.",
                "scidiscovery.hypothesis-proposal.v1",
                usage="prior_signal",
            ),
            _input(
                "scientific_foundation",
                "Exact scientific foundation used to challenge the proposal.",
                "scidiscovery.scientific-foundation.v1",
                cohort_id="qualified_foundation",
                approval_kind="scientific_foundation",
                accepted_approval_options=("approve",),
                accepted_approval_operations=_EVIDENCE_APPROVAL_PROVIDER,
            ),
        ),
        outputs=(
            _output(
                "scientific_review",
                "Independent hypothesis critic review.",
                "scientific_review",
                "scidiscovery.critic-review.v1",
                "critic_validator",
                allowed_input_usages=(
                    "change_request", "prior_signal", "evidence_inventory",
                ),
                max_item_bytes=32 * 1024,
                context_validator="critic_portfolio_context",
                context_sources=("hypothesis_portfolio",),
            ),
        ),
        timeout=600,
        max_input_bytes=2 * 1024 * 1024,
        max_output_bytes=32 * 1024,
        max_files=1,
    ),
    _agent(
        "science.hypothesis.propose.v1",
        "Propose a small falsifiable portfolio for the current contradiction.",
        "A problem frame and scientific foundation expose an unresolved mechanism.",
        "Reviewing, selecting, or qualifying hypotheses.",
        agent="ideator_agent",
        prompt="ideator_prompt",
        inputs=(
            _input(
                "problem_frame",
                "Exact bounded problem frame.",
                "scidiscovery.problem-frame.v1",
                max_item_bytes=512 * 1024,
                usage="prior_signal",
            ),
            _input(
                "scientific_foundation",
                "Exact evidence-bearing scientific foundation.",
                "scidiscovery.scientific-foundation.v1",
                cohort_id="qualified_foundation",
                approval_kind="scientific_foundation",
                accepted_approval_options=("approve",),
                accepted_approval_operations=_EVIDENCE_APPROVAL_PROVIDER,
            ),
        ),
        outputs=(HYPOTHESIS_OUTPUT,),
        timeout=900,
        max_input_bytes=2 * 1024 * 1024,
        max_output_bytes=64 * 1024,
        max_files=1,
        review=ReviewSpec(
            reviewer_operation="science.hypothesis.criticize.v1",
            reviewer_input_port="hypothesis_portfolio",
            subject_outputs=("hypothesis_portfolio",),
        ),
    ),
)



REVISION_OPERATIONS = (
    _agent(
        "science.intake.revise.v1",
        "Revise one complete ScientificIntake against its exact sources.",
        "An exact prior intake and independent change request require correction.",
        "Producing a patch, inheriting qualification, or changing unsupported facts.",
        agent="evidence_agent",
        prompt="evidence_prompt",
        inputs=(
            _input(
                "prior_draft",
                "Exact immutable ScientificIntake to revise.",
                "scidiscovery.scientific-intake.v1",
                max_item_bytes=8 * 1024 * 1024,
                usage="revision_base",
            ),
            _input(
                "change_request",
                "Exact independent evidence audit requesting correction.",
                "scidiscovery.evidence-audit.v1",
                max_item_bytes=512 * 1024,
                usage="change_request",
            ),
            _input(
                "source_material",
                "Complete immutable sources supporting the revised intake.",
                "opaque",
                media_types=(
                    "application/json",
                    "application/pdf",
                    "image/png",
                    "image/jpeg",
                    "image/webp",
                    "text/plain",
                    "text/plain; charset=utf-8",
                    "text/csv",
                ),
                max_items=6,
                max_item_bytes=16 * 1024 * 1024,
            ),
        ),
        outputs=(INTAKE_OUTPUT,),
        timeout=900,
        max_input_bytes=105 * 1024 * 1024,
        max_output_bytes=64 * 1024,
        max_files=1,
        tools=BASE_TOOLS + (_ref("pdf_extract_tool"),),
        native_view_image=True,
        review=ReviewSpec(
            reviewer_operation="science.evidence.audit.intake.v1",
            reviewer_input_port="scientific_intake",
            subject_outputs=("scientific_intake",),
        ),
    ),
    _agent(
        "science.hypothesis.revise.v1",
        "Revise one complete hypothesis portfolio within the approved foundation.",
        "An exact prior portfolio and independent critic request require correction.",
        "Producing a patch, inheriting a critic verdict, or expanding the evidence basis.",
        agent="ideator_agent",
        prompt="ideator_prompt",
        inputs=(
            _input(
                "prior_draft",
                "Exact immutable hypothesis portfolio to revise.",
                "scidiscovery.hypothesis-proposal.v1",
                max_item_bytes=8 * 1024 * 1024,
                usage="revision_base",
            ),
            _input(
                "change_request",
                "Exact independent critic review requesting correction.",
                "scidiscovery.critic-review.v1",
                max_item_bytes=512 * 1024,
                usage="change_request",
            ),
            _input(
                "scientific_foundation",
                "Exact approved scientific foundation bounding the revised portfolio.",
                "scidiscovery.scientific-foundation.v1",
                cohort_id="qualified_foundation",
                approval_kind="scientific_foundation",
                accepted_approval_options=("approve",),
                accepted_approval_operations=_EVIDENCE_APPROVAL_PROVIDER,
            ),
        ),
        outputs=(HYPOTHESIS_OUTPUT,),
        timeout=900,
        max_input_bytes=10 * 1024 * 1024,
        max_output_bytes=64 * 1024,
        max_files=1,
        review=ReviewSpec(
            reviewer_operation="science.hypothesis.criticize.v1",
            reviewer_input_port="hypothesis_portfolio",
            subject_outputs=("hypothesis_portfolio",),
        ),
    ),
)

AGENT_OPERATIONS = OPERATIONS + REVISION_OPERATIONS

__all__ = ["AGENT_OPERATIONS"]
