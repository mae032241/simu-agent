"""Public, state-free helpers for declaring compiled scientific Operations."""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any, Callable

from pydantic import BaseModel

from .operations.invoke import BoundInput
from .operations.spec import (
    ComponentRef,
    InputPortSpec,
    LimitsSpec,
    NativeToolPolicy,
    OperationDescription,
    OperationSpec,
    OutputPortSpec,
    ReviewSpec,
    ExecutorRef,
)


OPERATION_AGENT_PREAMBLE = """This is one bounded compiled scientific Operation.
Read only the exact assignment, declared inputs, and output contract returned by
the selected runtime backend. Do not search the project repository, installed
package, framework source, historical runs, or sibling workspaces. Treat missing
task-local evidence as a bounded gap rather than permission to find substitutes.

The runtime appends the authoritative backend-specific lifecycle, filesystem,
and tool instructions. A tool being visible is not authorization to use it. If
output validation fails, correct the reported field paths against the declared
Schema; never inspect framework implementation to reverse engineer a validator.
Scientific content must be delivered through the backend's declared submit
action, not through chat.

"""


def schema_resource(model: type[BaseModel], schema_id: str) -> str:
    value = model.model_json_schema(mode="validation")
    value["$id"] = schema_id
    return json.dumps(
        value, ensure_ascii=False, separators=(",", ":"), sort_keys=True
    )


def payload_validator(
    function: Callable[[dict[str, object]], Any],
) -> Callable[[bytes], None]:
    def validate(raw: bytes) -> None:
        value = json.loads(raw)
        if not isinstance(value, dict):
            raise ValueError("scientific payload must be a JSON object")
        function(value)

    return validate


def scientific_agent_operation(
    operation_id: str,
    purpose: str,
    applies_when: str,
    not_for: str,
    *,
    agent: ComponentRef,
    workspace: ComponentRef,
    prompt: ComponentRef,
    tools: tuple[ComponentRef, ...],
    inputs: tuple[InputPortSpec, ...],
    outputs: tuple[OutputPortSpec, ...],
    timeout: int,
    max_input_bytes: int,
    max_output_bytes: int,
    max_files: int,
    native_shell: str = "inherited_prototype",
    native_view_image: bool = False,
    review: ReviewSpec | None = None,
    guards: tuple[ComponentRef, ...] = (),
    consequence: str = "scientific",
) -> OperationSpec:
    """Build one bounded Agent declaration without registration side effects."""

    return OperationSpec(
        operation_id=operation_id,
        version="1",
        catalog_scope="public",
        description=OperationDescription(
            purpose=purpose, applies_when=applies_when, not_for=not_for
        ),
        executor=ExecutorRef(
            kind="agent",
            component=agent,
            workspace=workspace,
            tools=tools,
            prompt=prompt,
            model="gpt-5.4",
            native_tools=NativeToolPolicy(
                shell=native_shell, view_image=native_view_image
            ),
        ),
        inputs=inputs,
        outputs=outputs,
        consequence=consequence,
        review=review,
        guards=guards,
        limits=LimitsSpec(
            timeout_seconds=timeout,
            max_input_bytes=max_input_bytes,
            max_output_bytes=max_output_bytes,
            max_files=max_files,
        ),
    )


class RequiredParentage:
    """Guard exact input parentage without owning lifecycle or domain state."""

    def __init__(
        self,
        pairs: tuple[tuple[str, str], ...],
        *,
        allowed_port_sets: tuple[frozenset[str], ...] = (),
    ) -> None:
        self.pairs = pairs
        self.allowed_port_sets = allowed_port_sets

    def __call__(
        self, inputs: tuple[BoundInput, ...], parameters: Mapping[str, Any]
    ) -> bool:
        if parameters:
            return False
        grouped: dict[str, list[BoundInput]] = {}
        for item in inputs:
            grouped.setdefault(item.port_name, []).append(item)
        if self.allowed_port_sets:
            actual = frozenset(grouped)
            if actual not in self.allowed_port_sets:
                return False
            if actual != self.allowed_port_sets[-1]:
                return True
        for child_name, parent_name in self.pairs:
            if child_name not in grouped and parent_name not in grouped:
                continue
            children = grouped.get(child_name, ())
            parents = grouped.get(parent_name, ())
            if len(children) != 1 or len(parents) != 1:
                return False
            if parents[0].artifact.ref not in children[0].artifact.parent_refs:
                return False
        return True


__all__ = [
    "OPERATION_AGENT_PREAMBLE",
    "RequiredParentage",
    "payload_validator",
    "schema_resource",
    "scientific_agent_operation",
]
