"""Immutable schemas, prompts, and semantic contracts for general science."""

from __future__ import annotations

import json

from .artifact_agent.schema.cognitive import CriticReview, EvidenceAudit, HypothesisProposal
from .artifact_agent.schema.research_cycle import ProblemFrame, ScientificFoundation, ScientificIntake
from .operation_declaration import OPERATION_AGENT_PREAMBLE, schema_resource

EVIDENCE_PROMPT = """Return exactly one RoleResultEnvelope whose payload is the
ScientificIntake required by output.schema.json. Build a bounded ProblemFrame
and ScientificFoundation for only the assigned question. They must use the same
objective, and every problem-frame foundation reference must close over an item
in that foundation.

Use the exact assignment source_name as FoundationEvidence.source_key and in
every factual item's evidence_keys; do not invent aliases from filenames or the
local instruction. Preserve scope, conditions, units, uncertainty, conflicts,
assumptions, and open questions when supported. Paper facts, user definitions,
and runtime observations require exact supplied evidence; inference,
assumption, and speculation require an explicit rationale. Do not generalize
beyond the immutable inputs and do not copy whole source documents.

When the assignment includes a prior_draft and change_request, revise that exact
intake against the complete supplied sources and return the entire replacement
ScientificIntake. Preserve supported content that was not challenged, but do
not inherit qualification or emit a patch.
"""


IDEATOR_PROMPT = """Return exactly one RoleResultEnvelope whose payload is the
HypothesisProposal required by output.schema.json. Propose a small ordered
portfolio of distinct, testable mechanisms for the supplied contradiction.
Each hypothesis must state its mechanism, bounded parameters, observable
predictions, explicit falsifiers, competitors, scope, and only the exact source
keys that support it. Creative hypotheses are allowed but are not established
facts. Prefer whole-response tests and few degrees of freedom; never select or
qualify a candidate.

When the assignment includes a prior_draft and change_request, revise that exact
portfolio within the supplied approved foundation and return the entire
replacement HypothesisProposal. Preserve sound hypotheses where appropriate,
address the exact critic request, and do not inherit its verdict or emit a patch.
"""


CRITIC_PROMPT = """Return exactly one RoleResultEnvelope whose payload is the
CriticReview required by output.schema.json. Independently review every exact
hypothesis for physical plausibility, logical completeness, falsifiability,
identifiability, hidden degrees of freedom, numerical dependence, and simpler
competitors. Record an issue once and give the smallest resolving action only
for an unresolved dimension. A portfolio cannot pass while any hypothesis has
a failed dimension. Also enforce the boundary of the already qualified
scientific foundation: factual premises must be present there, inferences must
be labelled as inference, and missing inputs or historical observations must
not be restated as established mechanisms. If a premise is unsupported, request
the smallest evidence revision instead of re-auditing raw sources. Challenge
mechanisms; do not repeat source intake, grant qualification, or select a
candidate. Judge design-time identifiability by whether a bounded,
preregisterable future observation and decision rule can distinguish the
hypothesis from its competitors. A future observation not yet produced belongs
in missing inputs or next actions and does not by itself fail identifiability;
unbounded fallback mechanisms or post-hoc outcome mappings do fail it.
"""


AUDITOR_PROMPT = """Return exactly one RoleResultEnvelope whose payload is the
EvidenceAudit required by output.schema.json. Audit whether the exact supplied
object's factual claims, values, conditions, structures, and conclusions are
supported by the immutable sources. Declare each source once, use one compact
check per material question, preserve conflicts and missing support, and cite
only exact task-local source aliases. Do not grant qualification or inherit a
prior verdict.
"""


def _semantic_contract(*rules: str) -> str:
    return json.dumps(
        {
            "rules": (
                "Scientific content is authored only by the assigned Worker.",
                "A successful result is not human approval, qualification, or execution authorization.",
                *rules,
            )
        },
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    )


class Resources:
    opaque_schema = '{"$id":"opaque","type":["object","array","string","number","boolean","null"]}'
    intake_semantic_contract = _semantic_contract(
        "Every factual foundation item must cite an exact supplied source key.",
        "Problem-frame references must close over the exact foundation item keys in this payload.",
        "A parameter item requires both a value and a unit; use dimensionless when applicable.",
        "A unit cannot exist without a value, and numeric uncertainty requires a unit.",
        "Paper facts, user definitions, and runtime observations require evidence keys; inference, assumption, and speculation require a rationale.",
        "Item, source, conflict, condition, evidence, and tag keys must be unique and every reference must close locally.",
        "Conflict resolution fields must match unresolved, resolved, or accepted-assumption status.",
        "A supplied objective contract must exactly match the foundation objective and reference only declared items.",
        "The payload may frame the bounded question but must not generalize beyond supplied evidence.",
    )
    hypothesis_semantic_contract = _semantic_contract(
        "Hypothesis, prediction, falsifier, competitor, and evidence keys must be unique and closed.",
        "Every hypothesis must contain at least one falsifiable prediction and one explicit falsifier.",
        "Portfolio order is a proposal only and does not qualify or select a candidate.",
    )
    critic_semantic_contract = _semantic_contract(
        "The contextual validator requires exactly one review for every hypothesis in the bound portfolio.",
        "Every non-passing review dimension requires the smallest resolving action.",
        "Fail maps to a blocked handoff, unknown to inconclusive, not-applicable to revise, and all-pass to pass.",
        "The critic checks that factual premises stay inside the already qualified foundation and that inferences remain explicit.",
        "Unsupported premises require a bounded evidence revision; the critic does not repeat source intake or evidence qualification.",
        "Design-time identifiability means that a bounded preregisterable future observation and decision rule can distinguish competitors; the observation need not already exist.",
        "Unbounded fallback mechanisms and post-hoc outcome mappings fail identifiability even when a future experiment is proposed.",
    )
    evidence_audit_semantic_contract = _semantic_contract(
        "Every evidence reference must close over the audit's declared exact source keys.",
        "The audit preserves missing, conflicting, and unsupported evidence as fail, unknown, or not applicable.",
        "The audit must contain a check; decisive pass or fail checks require evidence keys; fail maps to blocked, unknown to inconclusive, otherwise pass.",
    )
    scientific_intake_schema = schema_resource(
        ScientificIntake, "scidiscovery.scientific-intake.v1"
    )
    scientific_foundation_schema = schema_resource(
        ScientificFoundation, "scidiscovery.scientific-foundation.v1"
    )
    problem_frame_schema = schema_resource(ProblemFrame, "scidiscovery.problem-frame.v1")
    hypothesis_schema = schema_resource(
        HypothesisProposal, "scidiscovery.hypothesis-proposal.v1"
    )
    critic_review_schema = schema_resource(CriticReview, "scidiscovery.critic-review.v1")
    evidence_audit_schema = schema_resource(EvidenceAudit, "scidiscovery.evidence-audit.v1")

    evidence_prompt = OPERATION_AGENT_PREAMBLE + EVIDENCE_PROMPT
    ideator_prompt = OPERATION_AGENT_PREAMBLE + IDEATOR_PROMPT
    critic_prompt = OPERATION_AGENT_PREAMBLE + CRITIC_PROMPT
    auditor_prompt = OPERATION_AGENT_PREAMBLE + AUDITOR_PROMPT

WILDCARD_SCHEMA = json.dumps(
    {"$id": "*", "description": "Lineage-only input; payload is never exposed."},
    ensure_ascii=True,
    separators=(",", ":"),
    sort_keys=True,
)


class TransformResources:
    wildcard_schema = WILDCARD_SCHEMA


__all__ = ["Resources", "TransformResources"]
