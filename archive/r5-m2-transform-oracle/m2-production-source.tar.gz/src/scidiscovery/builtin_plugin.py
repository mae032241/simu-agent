"""Minimal built-in plugin for the Worker file lifecycle."""

from .operations.spec import (
    PLUGIN_PROTOCOL_VERSION,
    ComponentSpec,
    PluginDefinition,
)


CORE_PLUGIN = PluginDefinition(
    plugin_id="builtin",
    version="0.1.0",
    protocol_version=PLUGIN_PROTOCOL_VERSION,
    components=(
        ComponentSpec(
            "file_write_begin_tool",
            "worker_tool",
            "scidiscovery.artifact_agent.interfaces.mcp_worker_protocol:FILE_WRITE_BEGIN_TOOL",
            public=True,
        ),
        ComponentSpec(
            "file_write_chunk_tool",
            "worker_tool",
            "scidiscovery.artifact_agent.interfaces.mcp_worker_protocol:FILE_WRITE_CHUNK_TOOL",
            public=True,
        ),
        ComponentSpec(
            "file_write_commit_tool",
            "worker_tool",
            "scidiscovery.artifact_agent.interfaces.mcp_worker_protocol:FILE_WRITE_COMMIT_TOOL",
            public=True,
        ),
    ),
    operations=(),
)


__all__ = ["CORE_PLUGIN"]
