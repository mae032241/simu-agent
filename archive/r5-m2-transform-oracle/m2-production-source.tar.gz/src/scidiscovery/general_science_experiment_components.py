"""Components for domain-neutral experiment Operations.

This module owns executable components and resources only.  Operation
declarations live in ``general_science_experiment_operations`` so plugin
registration remains a single, explicit composition step.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any, Callable

from pydantic import BaseModel

from .artifact_agent.schema.common import canonical_json
from .artifact_agent.schema.experiment import (
    ExperimentPortfolio,
    validate_experiment_design_task_output,
    validate_experiment_portfolio,
)
from .artifact_agent.schema.experiment_intent import (
    ExperimentDesignIntent,
    ExperimentPlanMaterializationReport,
    validate_experiment_design_intent,
    validate_experiment_design_intent_task_output,
)
from .artifact_agent.schema.knowledge import (
    KnowledgeStateProjection,
    KnowledgeUpdate,
)
from .artifact_agent.schema.research_cycle import (
    ScientificReview,
    validate_scientific_review,
)
from .artifact_agent.schema.research_objective import ResearchObjectiveContract
from .artifact_agent.schema.validation import ValidationReport
from .artifact_agent.transforms import (
    EXPERIMENT_PLAN_MATERIALIZE_PROFILE,
    KNOWLEDGE_UPDATE_PROFILE,
    RESEARCH_OBJECTIVE_PROJECT_PROFILE,
    ScientificStateTransformAdapter,
)
from .operation_declaration import (
    OPERATION_AGENT_PREAMBLE,
    RequiredParentage,
    payload_validator,
    schema_resource,
)
from .operations.spec import CallableComponent, ComponentRef, ComponentSpec


EXPERIMENT_PROMPT = """Return exactly one RoleResultEnvelope whose payload is
the scientific object required by output.schema.json. Without prior_draft,
produce the compact ExperimentDesignIntent: select only reviewed hypotheses and
design the smallest bounded study that states controls, interventions,
observables, predictions, falsifiers, resource judgment, and stop conditions.
With prior_draft and change_request, return the entire replacement
ExperimentPortfolio, preserving every still-supported field while applying the
bounded review correction. Never emit a patch, inherit a review verdict, invent
candidates, or make execution decisions.
"""

OBJECT_REVIEW_PROMPT = """Return exactly one RoleResultEnvelope whose payload is
the ScientificReview required by output.schema.json. Independently review the
complete supplied experiment plan without mutating it. The verdict is a
scientific assessment, not human approval or qualification. Report the
smallest bounded correction for each material defect.
"""


def _semantic_contract(*rules: str) -> str:
    return json.dumps(
        {
            "rules": (
                "Scientific content is authored only by the assigned Worker.",
                "A successful result is not human approval or execution authorization.",
                *rules,
            )
        },
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    )


def _agent_marker() -> None:
    return None


def _strict_validator(model: type[BaseModel]) -> Callable[[bytes], None]:
    def validate(raw: bytes) -> None:
        model.model_validate_json(raw, strict=True)

    return validate


def _experiment_portfolio_validator(raw: bytes) -> None:
    value = ExperimentPortfolio.model_validate_json(raw, strict=True)
    validate_experiment_portfolio(value.model_dump(mode="json"))


def _experiment_context(
    payload: dict[str, Any], sources: dict[str, bytes], handoff: dict[str, Any]
) -> None:
    validate_experiment_design_intent_task_output(payload, sources, handoff)


def _experiment_portfolio_context(
    payload: dict[str, Any], sources: dict[str, bytes], handoff: dict[str, Any]
) -> None:
    validate_experiment_design_task_output(payload, sources, handoff)


def _object_review_context(
    payload: dict[str, Any], sources: dict[str, bytes], handoff: dict[str, Any]
) -> None:
    if "experiment_plan" not in sources:
        raise ValueError("review target is absent")
    review = ScientificReview.model_validate_json(canonical_json(payload), strict=True)
    if review.review_target != "experiment_portfolio":
        raise ValueError("scientific review target differs from the bound object")
    expected_verdict = "blocked" if review.verdict == "reject" else review.verdict
    if handoff.get("verdict") != expected_verdict:
        raise ValueError("review handoff verdict differs from payload verdict")


def _one(values: Mapping[str, tuple[bytes, ...]], name: str) -> bytes:
    items = values.get(name, ())
    if len(items) != 1:
        raise ValueError(f"transform input {name} must contain exactly one item")
    return items[0]


def _run_transform(
    profile: str,
    values: Mapping[str, tuple[bytes, ...]],
    labels: tuple[tuple[str, str], ...],
) -> dict[str, tuple[bytes, ...]]:
    outputs = ScientificStateTransformAdapter.transform(
        profile=profile,
        inputs={name: _one(values, name) for name in values},
    )
    by_label = {item.label: item.content for item in outputs}
    if len(by_label) != len(outputs):
        raise ValueError("scientific transform returned duplicate labels")
    return {port: (by_label[label],) for port, label in labels}


def _objective_project(
    values: Mapping[str, tuple[bytes, ...]],
) -> dict[str, tuple[bytes, ...]]:
    return _run_transform(
        RESEARCH_OBJECTIVE_PROJECT_PROFILE,
        values,
        (("research_objective", "primary"),),
    )


def _experiment_materialize(
    values: Mapping[str, tuple[bytes, ...]],
) -> dict[str, tuple[bytes, ...]]:
    return _run_transform(
        EXPERIMENT_PLAN_MATERIALIZE_PROFILE,
        {
            name: items
            for name, items in values.items()
            if name not in {"scientific_foundation", "critic_review"}
        },
        (
            ("experiment_plan", "primary"),
            ("materialization_report", "materialization_report"),
        ),
    )


def _knowledge_update(
    values: Mapping[str, tuple[bytes, ...]],
) -> dict[str, tuple[bytes, ...]]:
    legacy = dict(values)
    prior = legacy.pop("prior_knowledge_state", None)
    if prior is not None:
        legacy["knowledge_state"] = prior
    return _run_transform(
        KNOWLEDGE_UPDATE_PROFILE,
        legacy,
        (("knowledge_update", "primary"), ("knowledge_state", "state")),
    )


class ExperimentResources:
    research_objective_schema = schema_resource(
        ResearchObjectiveContract, "scidiscovery.research-objective.v1"
    )
    experiment_intent_schema = schema_resource(
        ExperimentDesignIntent, "scidiscovery.experiment-design-intent.v1"
    )
    experiment_portfolio_schema = schema_resource(
        ExperimentPortfolio, "scidiscovery.experiment-portfolio.v1"
    )
    scientific_review_schema = schema_resource(
        ScientificReview, "scidiscovery.scientific-review.v1"
    )
    validation_report_schema = schema_resource(
        ValidationReport, "scidiscovery.validation-report.v1"
    )
    knowledge_update_schema = schema_resource(
        KnowledgeUpdate, "scidiscovery.knowledge-update.v1"
    )
    knowledge_state_schema = schema_resource(
        KnowledgeStateProjection, "scidiscovery.knowledge-state-projection.v1"
    )
    materialization_report_schema = schema_resource(
        ExperimentPlanMaterializationReport,
        "scidiscovery.experiment-plan-materialization.v1",
    )
    experiment_semantic_contract = _semantic_contract(
        "Bind a new intent or complete revised plan to its exact scientific context.",
        "A revision is a complete replacement object, never a patch or inherited verdict.",
    )
    scientific_review_semantic_contract = _semantic_contract(
        "Review the complete supplied experiment without mutating it.",
        "The review verdict is not a human approval decision.",
    )
    experiment_prompt = OPERATION_AGENT_PREAMBLE + EXPERIMENT_PROMPT
    object_review_prompt = OPERATION_AGENT_PREAMBLE + OBJECT_REVIEW_PROMPT


class ExperimentComponents:
    experiment_validator = CallableComponent(
        "validator", payload_validator(validate_experiment_design_intent)
    )
    review_validator = CallableComponent(
        "validator", payload_validator(validate_scientific_review)
    )
    experiment_context = CallableComponent("validator", _experiment_context)
    experiment_portfolio_context = CallableComponent(
        "validator", _experiment_portfolio_context
    )
    object_review_context = CallableComponent("validator", _object_review_context)
    experiment_agent = CallableComponent("agent", _agent_marker)
    objective_project = CallableComponent("transform", _objective_project)
    experiment_materialize = CallableComponent("transform", _experiment_materialize)
    knowledge_update = CallableComponent("transform", _knowledge_update)
    objective_validator = CallableComponent(
        "validator", _strict_validator(ResearchObjectiveContract)
    )
    experiment_portfolio_validator = CallableComponent(
        "validator", _experiment_portfolio_validator
    )
    materialization_report_validator = CallableComponent(
        "validator", _strict_validator(ExperimentPlanMaterializationReport)
    )
    knowledge_update_validator = CallableComponent(
        "validator", _strict_validator(KnowledgeUpdate)
    )
    knowledge_state_validator = CallableComponent(
        "validator", _strict_validator(KnowledgeStateProjection)
    )
    experiment_science_cohort = CallableComponent(
        "guard",
        RequiredParentage(
            (
                ("research_objective", "scientific_foundation"),
                ("hypothesis_portfolio", "scientific_foundation"),
                ("critic_review", "scientific_foundation"),
                ("critic_review", "hypothesis_portfolio"),
            ),
        ),
    )
    experiment_lineage = CallableComponent(
        "guard",
        RequiredParentage(
            (
                ("experiment_design_intent", "scientific_foundation"),
                ("experiment_design_intent", "research_objective"),
                ("experiment_design_intent", "hypothesis_portfolio"),
                ("experiment_design_intent", "critic_review"),
                ("research_objective", "scientific_foundation"),
                ("hypothesis_portfolio", "scientific_foundation"),
                ("critic_review", "scientific_foundation"),
                ("critic_review", "hypothesis_portfolio"),
            ),
            allowed_port_sets=(
                frozenset({"experiment_design_intent"}),
                frozenset(
                    {
                        "experiment_design_intent",
                        "scientific_foundation",
                        "research_objective",
                        "hypothesis_portfolio",
                        "critic_review",
                    }
                ),
            ),
        ),
    )


def component_specs() -> tuple[ComponentSpec, ...]:
    values: list[ComponentSpec] = []
    semantic_resources = {
        "experiment_validator": ("experiment_semantic_contract",),
        "review_validator": ("scientific_review_semantic_contract",),
        "experiment_context": ("experiment_semantic_contract",),
        "experiment_portfolio_context": ("experiment_semantic_contract",),
        "object_review_context": ("scientific_review_semantic_contract",),
        "experiment_portfolio_validator": ("experiment_semantic_contract",),
    }
    for name in (
        "experiment_validator",
        "review_validator",
        "experiment_context",
        "experiment_portfolio_context",
        "object_review_context",
        "experiment_agent",
        "objective_project",
        "experiment_materialize",
        "knowledge_update",
        "objective_validator",
        "experiment_portfolio_validator",
        "materialization_report_validator",
        "knowledge_update_validator",
        "knowledge_state_validator",
        "experiment_science_cohort",
        "experiment_lineage",
    ):
        component = getattr(ExperimentComponents, name)
        values.append(
            ComponentSpec(
                name,
                component.kind,
                f"scidiscovery.general_science_experiment_components:ExperimentComponents.{name}",
                resources=tuple(
                    ComponentRef(resource)
                    for resource in semantic_resources.get(name, ())
                ),
                configuration_identity=(
                    f"general-experiment:{name}:v1"
                    if component.kind in {"transform", "guard"}
                    else None
                ),
                public=name
                in {
                    "knowledge_update",
                    "knowledge_update_validator",
                    "knowledge_state_validator",
                },
            )
        )
    public_resources = {
        "experiment_portfolio_schema",
        "research_objective_schema",
        "knowledge_state_schema",
        "knowledge_update_schema",
        "scientific_review_schema",
    }
    for name in (
        "research_objective_schema",
        "experiment_intent_schema",
        "experiment_portfolio_schema",
        "scientific_review_schema",
        "validation_report_schema",
        "knowledge_update_schema",
        "knowledge_state_schema",
        "materialization_report_schema",
        "experiment_semantic_contract",
        "scientific_review_semantic_contract",
        "experiment_prompt",
        "object_review_prompt",
    ):
        values.append(
            ComponentSpec(
                name,
                "resource",
                f"scidiscovery.general_science_experiment_components:ExperimentResources.{name}",
                public=name in public_resources,
            )
        )
    return tuple(values)


COMPONENTS = component_specs()

__all__ = ["COMPONENTS", "ExperimentComponents", "ExperimentResources"]
