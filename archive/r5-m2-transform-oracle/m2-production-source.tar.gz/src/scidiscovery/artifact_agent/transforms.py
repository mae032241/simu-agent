"""Domain-neutral contract for deterministic Artifact transformations."""

from __future__ import annotations

from typing import Mapping

from .schema.common import canonical_json
from .schema.cognitive import HypothesisProposal
from .schema.hypothesis import HypothesisPortfolio
from .schema.experiment_intent import materialize_experiment_design_inputs
from .schema.knowledge import (
    KnowledgeStateProjection,
    advance_knowledge_state,
    derive_knowledge_update,
    project_knowledge_state,
)
from .schema.validation import ValidationReport
from .schema.layered_diagnosis import LayeredDiagnosisReport
from .schema.research_cycle import ScientificIntake
from .schema.scientific_foundation import ScientificFoundation
from .schema.transform_output import TransformOutput


KNOWLEDGE_UPDATE_PROFILE = "scidiscovery.knowledge-update-from-validation.v1"
SCIENTIFIC_INTAKE_SPLIT_PROFILE = "scidiscovery.scientific-intake-split.v1"
RESEARCH_OBJECTIVE_PROJECT_PROFILE = "scidiscovery.research-objective-project.v1"
EXPERIMENT_PLAN_MATERIALIZE_PROFILE = (
    "scidiscovery.experiment-plan-materialize.v1"
)


class ScientificStateTransformAdapter:
    """Domain-neutral transforms that preserve scientific judgment boundaries."""

    @staticmethod
    def supports_transform_profile(profile: str) -> bool:
        return profile in {
            KNOWLEDGE_UPDATE_PROFILE,
            SCIENTIFIC_INTAKE_SPLIT_PROFILE,
            RESEARCH_OBJECTIVE_PROJECT_PROFILE,
            EXPERIMENT_PLAN_MATERIALIZE_PROFILE,
        }

    @staticmethod
    def required_input_parentage(profile: str) -> tuple[tuple[str, str], ...]:
        return ()

    @staticmethod
    def required_input_parentage_for_inputs(
        profile: str, input_names: tuple[str, ...]
    ) -> tuple[tuple[str, str], ...]:
        if profile == EXPERIMENT_PLAN_MATERIALIZE_PROFILE:
            if input_names == ("experiment_design_intent",):
                return ()
            return tuple(
                ("experiment_design_intent", name)
                for name in (
                    "research_objective",
                    "hypothesis_portfolio",
                )
            )
        return ScientificStateTransformAdapter.required_input_parentage(profile)

    @staticmethod
    def nonqualifying_input_names(
        profile: str, input_names: tuple[str, ...]
    ) -> tuple[str, ...]:
        permitted = {
            SCIENTIFIC_INTAKE_SPLIT_PROFILE: ("scientific_intake",),
        }.get(profile)
        return input_names if permitted == input_names else ()

    @staticmethod
    def payload_input_names(
        profile: str, input_names: tuple[str, ...]
    ) -> tuple[str, ...]:
        return input_names

    @staticmethod
    def transform(
        *, profile: str, inputs: Mapping[str, bytes]
    ) -> tuple[TransformOutput, ...]:
        if profile == EXPERIMENT_PLAN_MATERIALIZE_PROFILE:
            return _materialize_experiment_plan(inputs)
        if profile == SCIENTIFIC_INTAKE_SPLIT_PROFILE:
            if frozenset(inputs) != {"scientific_intake"}:
                raise ValueError("scientific intake split requires scientific_intake")
            intake = ScientificIntake.model_validate_json(
                inputs["scientific_intake"], strict=True
            )
            return (
                TransformOutput(
                    # The root transform contract binds exactly one primary
                    # output to the requested semantic name. Here that object
                    # is the frame; the foundation remains a derived sibling.
                    label="primary",
                    content=intake.problem_frame.canonical_json(),
                    kind="problem_frame",
                    schema="scidiscovery.problem-frame.v1",
                    payload_schema_version=1,
                    media_type="application/json",
                ),
                TransformOutput(
                    label="scientific_foundation",
                    content=intake.scientific_foundation.canonical_json(),
                    kind="scientific_foundation",
                    schema="scidiscovery.scientific-foundation.v1",
                    payload_schema_version=1,
                    media_type="application/json",
                ),
            )
        if profile == RESEARCH_OBJECTIVE_PROJECT_PROFILE:
            if frozenset(inputs) != {"scientific_foundation"}:
                raise ValueError(
                    "research objective projection requires scientific_foundation"
                )
            foundation = ScientificFoundation.model_validate_json(
                inputs["scientific_foundation"], strict=True
            )
            if foundation.objective_contract is None:
                raise ValueError(
                    "research objective projection requires an explicit objective_contract"
                )
            return (
                TransformOutput(
                    label="primary",
                    content=foundation.objective_contract.canonical_json(),
                    kind="research_objective",
                    schema="scidiscovery.research-objective.v1",
                    payload_schema_version=1,
                    media_type="application/json",
                ),
            )
        if profile != KNOWLEDGE_UPDATE_PROFILE:
            raise ValueError("unsupported scientific-state transform profile")
        input_names = frozenset(inputs)
        report_names = {"validation_report", "layered_diagnosis"}
        selected_reports = input_names & report_names
        required_base = {"hypothesis_portfolio"}
        if len(selected_reports) != 1 or input_names not in {
            frozenset(required_base | selected_reports),
            frozenset(required_base | selected_reports | {"knowledge_state"}),
        }:
            raise ValueError(
                "knowledge update requires hypothesis_portfolio, exactly one diagnosis, "
                "and optionally knowledge_state"
            )
        portfolio = _knowledge_portfolio_view(inputs["hypothesis_portfolio"])
        report_name = next(iter(selected_reports))
        report = (
            LayeredDiagnosisReport.model_validate_json(
                inputs[report_name], strict=True
            )
            if report_name == "layered_diagnosis"
            else ValidationReport.model_validate_json(inputs[report_name], strict=True)
        )
        prior_state = (
            KnowledgeStateProjection.model_validate_json(
                inputs["knowledge_state"], strict=True
            )
            if "knowledge_state" in inputs
            else project_knowledge_state(portfolio, ())
        )
        update = derive_knowledge_update(portfolio, report, prior_state=prior_state)
        state = advance_knowledge_state(prior_state, update)
        return (
            TransformOutput(
                label="primary",
                content=canonical_json(update.model_dump(mode="json")),
                kind="knowledge_update",
                schema="scidiscovery.knowledge-update.v1",
                payload_schema_version=1,
                media_type="application/json",
            ),
            TransformOutput(
                label="state",
                content=canonical_json(state.model_dump(mode="json")),
                kind="knowledge_state_projection",
                schema="scidiscovery.knowledge-state-projection.v1",
                payload_schema_version=1,
                media_type="application/json",
            ),
        )


def _materialize_experiment_plan(
    inputs: Mapping[str, bytes],
) -> tuple[TransformOutput, ...]:
    portfolio, report = materialize_experiment_design_inputs(dict(inputs))
    return (
        TransformOutput(
            label="primary",
            content=portfolio.canonical_json(),
            kind="experiment_portfolio",
            schema="scidiscovery.experiment-portfolio.v1",
            payload_schema_version=1,
            media_type="application/json",
        ),
        TransformOutput(
            label="materialization_report",
            content=report.canonical_json(),
            kind="experiment_plan_materialization_report",
            schema="scidiscovery.experiment-plan-materialization.v1",
            payload_schema_version=1,
            media_type="application/json",
        ),
    )


def _knowledge_portfolio_view(raw: bytes) -> HypothesisPortfolio:
    """Build the narrow internal view required by the knowledge reducer."""

    parsed = HypothesisProposal.model_validate_json(raw, strict=True)
    evidence_keys = tuple(item.source_key for item in parsed.evidence)
    if not evidence_keys:
        raise ValueError("knowledge update requires a source-backed hypothesis handoff")
    hypotheses = []
    for item in parsed.hypotheses:
        hypotheses.append(
            {
                "hypothesis_key": item.hypothesis_key,
                "statement": item.statement,
                "mechanism": item.mechanism,
                "scope": item.scope,
                # The knowledge reducer never reads parameters. Keep simulator
                # locators in the source payload instead of normalizing them.
                "parameters": [],
                "predictions": [
                    {
                        "prediction_key": prediction.prediction_key,
                        "observable": prediction.observable,
                        "expected_outcome": prediction.expected_outcome,
                        "rationale": prediction.expected_outcome,
                    }
                    for prediction in item.predictions
                ],
                "falsifiers": [
                    {
                        "falsifier_key": falsifier.falsifier_key,
                        "observable": falsifier.observable,
                        "rejection_condition": falsifier.rejection_condition,
                        "rationale": falsifier.rejection_condition,
                    }
                    for falsifier in item.falsifiers
                ],
                "competing_hypothesis_keys": list(item.competing_hypothesis_keys),
                "status": "testable",
                "support_level": "unassessed",
                "support_rationale": (
                    "The proposal payload carries no support promotion; runtime evidence "
                    "must update support through the deterministic knowledge reducer."
                ),
            }
        )
    return HypothesisPortfolio.model_validate_json(
        canonical_json({
            "objective": parsed.objective,
            "contradiction": parsed.contradiction,
            "foundation_summary": parsed.objective,
            "foundation_item_keys": list(evidence_keys),
            "hypotheses": hypotheses,
            "ranking": [item.hypothesis_key for item in parsed.hypotheses],
            "ranking_rationale": "Payload order is the ideator's declared priority.",
            "missing_inputs": [],
        }),
        strict=True,
    )


__all__ = [
    "KNOWLEDGE_UPDATE_PROFILE",
    "SCIENTIFIC_INTAKE_SPLIT_PROFILE",
    "RESEARCH_OBJECTIVE_PROJECT_PROFILE",
    "ScientificStateTransformAdapter",
    "TransformOutput",
]
