"""Small scientific handoff signal emitted by one completed Agent Run."""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import Field

from .common import SchemaModel


SchedulerItem = Annotated[str, Field(min_length=1, max_length=512)]


class SchedulerSignal(SchemaModel):
    """Bounded handoff metadata; scientific content remains in the Artifact."""

    verdict: Literal["pass", "revise", "blocked", "inconclusive"]
    summary: Annotated[str, Field(min_length=1, max_length=2048)]
    assumptions: Annotated[tuple[SchedulerItem, ...], Field(max_length=32)] = ()
    missing_inputs: Annotated[tuple[SchedulerItem, ...], Field(max_length=32)] = ()
    next_actions: Annotated[tuple[SchedulerItem, ...], Field(max_length=32)] = ()


__all__ = ["SchedulerSignal"]
