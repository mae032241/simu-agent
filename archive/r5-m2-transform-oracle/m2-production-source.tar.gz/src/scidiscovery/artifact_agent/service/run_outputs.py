"""Pure validation of one sealed compiled-Operation result."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Mapping

from pydantic import ValidationError

from ...operations.invoke import operation_primary_output
from ...operations.spec import CompiledOperation
from ..schema.common import canonical_json
from ..schema.role_result import parse_role_result
from ..schema.run_signal import SchedulerSignal
from .local_workspace import SealedWorkspace, WorkspaceError


class RunOutputError(RuntimeError):
    def __init__(
        self, message: str, *, details: tuple[dict[str, str], ...] = ()
    ) -> None:
        super().__init__(message)
        self.details = details


@dataclass(frozen=True, slots=True)
class ValidatedRunOutput:
    content: bytes
    signal: SchedulerSignal
    media_type: str
    kind: str
    schema_id: str
    payload_schema_version: int
    output_port: str


def validate_run_output(
    compiled: CompiledOperation,
    sealed: SealedWorkspace,
    *,
    input_bytes: Mapping[str, bytes],
) -> ValidatedRunOutput:
    """Validate the one primary result without changing control state."""

    if sealed.run_id == "" or sealed.backend == "":
        raise RunOutputError("sealed workspace identity is invalid")
    paths = {item.relative_path for item in sealed.files}
    if paths != {"result.json"}:
        raise RunOutputError(
            "this minimal Run accepts exactly output/result.json",
            details=({"path": "$.files", "message": "unexpected output file set", "type": "value_error"},),
        )
    descriptor = sealed.files[0]
    path = sealed.root / descriptor.relative_path
    try:
        raw_envelope = path.read_bytes()
    except OSError as error:
        raise WorkspaceError("sealed result is unreadable") from error
    try:
        decoded = json.loads(raw_envelope.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise RunOutputError(
            "worker output is not valid UTF-8 JSON",
            details=({"path": "$", "message": str(error), "type": "json_invalid"},),
        ) from error
    try:
        result = parse_role_result(decoded)
    except ValidationError as error:
        raise RunOutputError(
            "worker output must use the role result envelope",
            details=_validation_details(error),
        ) from error
    if not isinstance(result.payload, dict):
        raise RunOutputError("operation JSON output payload must be an object")
    port = operation_primary_output(compiled)
    raw = canonical_json(result.payload)
    codec_key = f"{port.codec.plugin_id or compiled.plugin_id}:{port.codec.component_id}"
    try:
        encoded = compiled.implementations[codec_key](raw)
    except Exception as error:
        raise RunOutputError("operation output codec rejected the payload") from error
    if type(encoded) is not bytes:
        raise RunOutputError("operation output codec returned non-bytes")
    if port.validator is not None:
        key = (
            f"{port.validator.plugin_id or compiled.plugin_id}:"
            f"{port.validator.component_id}"
        )
        try:
            compiled.implementations[key](encoded)
        except Exception as error:
            raise RunOutputError(
                "operation output validator rejected the payload",
                details=_prefix(_validation_details(error), "$.payload"),
            ) from error
    try:
        normalized = json.loads(encoded)
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise RunOutputError("operation output codec returned invalid JSON") from error
    if canonical_json(normalized) != encoded:
        raise RunOutputError("operation output codec must return canonical JSON")
    assert compiled.spec.limits is not None
    if len(encoded) > min(port.max_item_bytes, compiled.spec.limits.max_output_bytes):
        raise RunOutputError("scientific output exceeds its compiled byte limit")
    if port.context_validator is not None:
        key = (
            f"{port.context_validator.plugin_id or compiled.plugin_id}:"
            f"{port.context_validator.component_id}"
        )
        sources = {
            name: content
            for name, content in input_bytes.items()
            if any(
                name == source or name.startswith(source + "_")
                for source in port.context_sources
            )
        }
        try:
            compiled.implementations[key](
                result.payload,
                sources,
                result.handoff.model_dump(mode="json"),
            )
        except Exception as error:
            raise RunOutputError(
                "operation contextual output validator rejected the payload",
                details=_prefix(_validation_details(error), "$.payload"),
            ) from error
    handoff = result.handoff
    return ValidatedRunOutput(
        content=encoded,
        signal=SchedulerSignal(
            verdict=handoff.verdict,
            summary=handoff.summary,
            assumptions=handoff.assumptions,
            missing_inputs=handoff.missing_inputs,
            next_actions=handoff.next_actions,
        ),
        media_type=port.media_types[0],
        kind=port.kind,
        schema_id=port.schema_id,
        payload_schema_version=port.payload_schema_version,
        output_port=port.name,
    )


def _validation_details(error: Exception) -> tuple[dict[str, str], ...]:
    if isinstance(error, ValidationError):
        return tuple(
            {
                "path": ".".join(str(part) for part in item["loc"]) or "$",
                "message": str(item["msg"]),
                "type": str(item["type"]),
            }
            for item in error.errors(include_url=False)[:32]
        )
    return ({"path": "$", "message": str(error), "type": "value_error"},)


def _prefix(
    details: tuple[dict[str, str], ...], prefix: str
) -> tuple[dict[str, str], ...]:
    return tuple(
        {
            **item,
            "path": (
                prefix
                if item["path"] == "$"
                else f"{prefix}.{item['path'].removeprefix('$.')}"
            ),
        }
        for item in details
    )


__all__ = [
    "RunOutputError",
    "ValidatedRunOutput",
    "validate_run_output",
]
