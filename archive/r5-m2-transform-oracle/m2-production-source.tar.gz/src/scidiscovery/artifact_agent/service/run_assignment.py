"""Compile one exact Operation binding into local assignment files."""

from __future__ import annotations

from typing import Any

from ...operations.invoke import BoundOperationCall, operation_port_json_schema, operation_primary_output
from ..schema.common import canonical_json
from ..schema.role_result import RoleResultEnvelope
from .local_workspace import workspace_input_filename
from .run_records import RunInputBinding


def assignment_json(
    bound: BoundOperationCall,
    inputs: tuple[RunInputBinding, ...],
    *,
    tool_names: tuple[str, ...],
    recovery_relative_path: str | None = None,
) -> bytes:
    return canonical_json(
        {
            "schema_version": 1,
            "operation": {
                "id": bound.compiled.spec.operation_id,
                "version": bound.compiled.spec.version,
                "digest": bound.compiled.digest,
            },
            "instruction": bound.instruction or "",
            "inputs": [
                {
                    "source_name": item.source_name,
                    "relative_path": (
                        "inputs/"
                        + workspace_input_filename(item.source_name, item.media_type)
                    ),
                    "media_type": item.media_type,
                    "usage": item.usage,
                    "exposure": item.exposure,
                }
                for item in inputs
                if item.exposure != "handoff_only"
            ],
            "output": {
                "relative_path": "output/result.json",
                "schema_path": "schema/result.schema.json",
            },
            "tools": list(tool_names),
            "recovery_draft": (
                None
                if recovery_relative_path is None
                else {
                    "relative_path": recovery_relative_path,
                    "scientific_evidence": False,
                    "instruction": "Use only as an editable starting point; revalidate the complete result.",
                }
            ),
        }
    )


def result_schema_json(compiled: Any) -> bytes:
    port = operation_primary_output(compiled)
    envelope = RoleResultEnvelope[Any].model_json_schema(mode="validation")
    envelope["properties"]["payload"] = operation_port_json_schema(compiled, port)
    envelope["$id"] = f"{port.schema_id}.run-envelope"
    return canonical_json(envelope)


__all__ = ["assignment_json", "result_schema_json"]
