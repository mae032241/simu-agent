"""Compiled Operation routing for the single Root scheduler facade."""

from __future__ import annotations

import uuid
from dataclasses import replace
from typing import Any, Protocol

from ..schema.approval import ApprovalOption, CompiledApprovalIdentity, ReviewDocument
from ..schema.artifact import ArtifactRegistration
from ..schema.common import canonical_sha256
from ...operations.invoke import (
    ApprovalProjectorContext,
    ApprovalSubjectSnapshot,
    BoundOperationCall,
    CompiledTransformAdapter,
    EffectExecutorPlan,
    InvocationArtifact,
    OperationInvocationError,
    ProducerEvidenceSource,
    ProducerFamilyMember,
    ProducerOutputFamily,
    direct_revision_ports,
    effect_executor_plan,
    effect_operation_plan,
    preflight_operation,
    preflight_result,
)
from ...operations.tooling import (
    operation_local_worker_missing_tools,
    operation_worker_tools,
)
from .mcp_root_shared import (
    APPROVAL_OPTION_IDS as _APPROVAL_OPTION_IDS,
    NONQUALIFYING_HANDOFF_VERDICTS as _NONQUALIFYING_HANDOFF_VERDICTS,
    RootToolError,
    claim_admissible as _claim_admissible,
    derived_name as _derived_name,
    operation_artifact_labels as _operation_artifact_labels,
)


class _OperationInputSelection(Protocol):
    """Structural input required by routing, independent of MCP decoding DTOs."""

    port: str
    artifact_names: tuple[str, ...]


class RootOperationRoutes:
    def operation_catalog(self, *, scope: str) -> dict[str, Any]:
        projection = self._operation_catalog.scheduler_projection()
        items = [
            self._operation_catalog_item(item)
            for item in projection
            if scope == "all" or item.catalog_scope == scope
        ]
        if scope == "public":
            items = [
                item
                for item in items
                if item.get("runtime_binding", {}).get("status") != "unavailable"
            ]
        return {
            "scope": scope,
            "operations": items,
        }

    def _operation_catalog_item(self, item: Any) -> dict[str, Any]:
        value = item.model_dump(mode="json", by_alias=True)
        compiled = self._operation_catalog.operation(item.operation_id)
        if compiled.spec.executor.kind == "effect":
            try:
                plan = effect_operation_plan(compiled)
            except OperationInvocationError:
                value["runtime_binding"] = {
                    "process": "control",
                    "required": [],
                    "status": "invalid_declaration",
                }
                return value
            available = bool(
                self.execution_bridge is not None
                and self.execution_bridge.has_adapter(plan.executor)
            )
            value["runtime_binding"] = {
                "process": "control",
                "required": [plan.executor],
                "status": "available" if available else "unavailable",
            }
        elif compiled.spec.executor.kind == "agent":
            if self.runs is not None:
                if not self.runs.backend.supports_operation(compiled):
                    value["runtime_binding"] = {
                        "process": "worker",
                        "required": list(
                            self.runs.backend.unsupported_requirements(compiled)
                        ),
                        "status": "unavailable",
                    }
                    return value
                missing = operation_local_worker_missing_tools(compiled)
                if missing:
                    value["runtime_binding"] = {
                        "process": "local_worker",
                        "required": list(missing),
                        "status": "unavailable",
                    }
                    return value
            services = sorted(
                {
                    service
                    for tool in operation_worker_tools(compiled)
                    for service in tool.required_services
                }
            )
            if services:
                value["runtime_binding"] = {
                    "process": "worker",
                    "required": services,
                    "status": "verified_on_worker_claim",
                }
        return value

    def operation_preflight(self, **values: Any) -> dict[str, Any]:
        return preflight_result(lambda: self._prepare_operation_call(**values))

    def operation_invoke(self, **values: Any) -> dict[str, Any]:
        with self._create_lock:
            try:
                bound = self._prepare_operation_call(**values)
                kind = bound.compiled.spec.executor.kind
                if kind == "agent":
                    result = self._invoke_agent_operation(
                        bound,
                        values["on_conflict"],
                        resume_from=values.get("resume_from"),
                    )
                elif kind == "transform":
                    result = self._invoke_compiled_transform(
                        bound, values["on_conflict"]
                    )
                elif kind == "effect":
                    plan = self._effect_operation_plan(bound)
                    payloads = tuple(
                        item for item in bound.inputs if item.port_name == plan.payload_port
                    )
                    if len(payloads) != 1 or len(bound.inputs) != 1:
                        raise OperationInvocationError("effect_payload_not_singular")
                    result = self._invoke_compiled_effect(
                        bound, plan, values["on_conflict"]
                    )
                elif kind == "approval":
                    result = self._invoke_approval_operation(
                        bound, values["on_conflict"]
                    )
                else:
                    raise OperationInvocationError("executor_kind_unknown")
            except OperationInvocationError as error:
                raise RootToolError(
                    f"operation invocation rejected [{error.reason_code}]"
                ) from error
        return {
            "operation_id": bound.compiled.spec.operation_id,
            "executor_kind": bound.compiled.spec.executor.kind,
            "result": result,
        }

    def _invoke_agent_operation(
        self,
        bound: BoundOperationCall,
        on_conflict: str,
        *,
        resume_from: str | None = None,
    ) -> dict[str, Any]:
        if self.runs is None:
            raise OperationInvocationError("runtime_backend_unavailable")
        return self._invoke_local_run(
            bound, on_conflict, resume_from=resume_from
        )

    def _invoke_local_run(
        self,
        bound: BoundOperationCall,
        on_conflict: str,
        *,
        resume_from: str | None,
    ) -> dict[str, Any]:
        resume_run_id = (
            None if resume_from is None else self._resolve("run", resume_from)
        )
        fingerprint = canonical_sha256(
            {
                "operation": bound.compiled.spec.operation_id,
                "operation_version": bound.compiled.spec.version,
                "operation_digest": bound.compiled.digest,
                "instruction": bound.instruction,
                "inputs": [
                    {
                        "port": item.port_name,
                        "source": item.source_name,
                        "artifact_name": item.artifact_name,
                        "artifact_ref": item.artifact.ref,
                        "usage": item.usage,
                        "exposure": item.exposure,
                    }
                    for item in bound.inputs
                ],
                "resume_from": resume_run_id,
            }
        )
        target = self._creation_target("run", bound.name, fingerprint, on_conflict)
        if target.existing_object_id is not None:
            return self.run_status(name=target.name)
        output_name = _derived_name(target.name, "output")
        output_logical_name = _derived_name(target.logical_name, "output")
        output_fingerprint = canonical_sha256(
            {"run_request": fingerprint, "output": "primary"}
        )
        try:
            run_id = self.runs.schedule(
                bound,
                instance_id=self._instance_id(),
                output_binding_name=output_name,
                output_logical_name=output_logical_name,
                output_revision=target.revision,
                output_binding_fingerprint=output_fingerprint,
                resume_from=resume_run_id,
            )
        except Exception as error:
            raise OperationInvocationError("local_run_creation_failed") from error
        self._bind_target("run", target, run_id, fingerprint)
        return self.run_status(name=target.name)

    def _invoke_approval_operation(
        self, bound: BoundOperationCall, on_conflict: str
    ) -> dict[str, Any]:
        review = bound.compiled.spec.review
        contract = review.approval if review is not None else None
        identity = bound.compiled.approval_identity
        if contract is None or contract.projector is None or identity is None:
            raise OperationInvocationError("approval_contract_missing")
        grouped = {
            port_name: tuple(
                item for item in bound.inputs if item.port_name == port_name
            )
            for port_name in contract.subject_ports
        }
        port_specs = {port.name: port for port in bound.compiled.spec.inputs}
        if any(
            not values and port_specs[port_name].min_items > 0
            for port_name, values in grouped.items()
        ):
            raise OperationInvocationError("approval_subject_missing")
        snapshots: list[ApprovalSubjectSnapshot] = []
        for port_name in contract.subject_ports:
            for item_index, item in enumerate(grouped[port_name]):
                snapshots.append(
                    ApprovalSubjectSnapshot(
                        subject_index=len(snapshots),
                        port_name=port_name,
                        item_index=item_index,
                        ref=item.artifact.ref,
                        schema_id=item.artifact.schema_id,
                        media_type=item.artifact.media_type,
                        size_bytes=item.artifact.size_bytes,
                        parent_refs=item.artifact.parent_refs,
                        labels=item.artifact.labels,
                        handoff_verdict=item.artifact.handoff_verdict,
                        content=self.artifacts.read(item.artifact.ref),
                    )
                )
        context = ApprovalProjectorContext(
            operation_id=bound.compiled.spec.operation_id,
            operation_version=bound.compiled.spec.version,
            operation_digest=bound.compiled.digest,
            subjects=tuple(snapshots),
            producer_families=self._approval_producer_families(bound),
        )
        projector_key = (
            f"{contract.projector.plugin_id or bound.compiled.plugin_id}:"
            f"{contract.projector.component_id}"
        )
        try:
            document = bound.compiled.implementations[projector_key](context)
        except Exception as error:
            raise OperationInvocationError("approval_projector_failed") from error
        if not isinstance(document, ReviewDocument):
            raise OperationInvocationError("approval_projector_result_invalid")
        subject_refs = tuple(item.ref for item in snapshots)
        options = tuple(
            ApprovalOption(
                option_id=_APPROVAL_OPTION_IDS[item.decision],
                label=item.label,
                description=item.description or item.label,
                requires_rationale=item.requires_reason,
            )
            for item in contract.options
        )
        compiled_identity = CompiledApprovalIdentity(
            operation_id=identity.operation_id,
            operation_version=identity.version,
            operation_digest=identity.operation_digest,
            approval_contract_digest=identity.approval_contract_digest,
        )
        fingerprint = canonical_sha256(
            {
                "operation": bound.compiled.spec.operation_id,
                "operation_version": bound.compiled.spec.version,
                "operation_digest": bound.compiled.digest,
                "approval_contract_digest": identity.approval_contract_digest,
                "kind": contract.kind,
                "subject_refs": subject_refs,
                "question": contract.question,
                "options": options,
                "review_document": document,
            }
        )
        target = self._creation_target(
            "approval", bound.name, fingerprint, on_conflict
        )
        if target.existing_object_id is not None:
            return self.approval_status(name=target.name)
        approval_id = f"apr_{uuid.uuid4().hex}"
        self.approvals.create_request(
            approval_id=approval_id,
            kind=contract.kind,
            subject_refs=subject_refs,
            question=contract.question,
            options=options,
            requested_by=self.intake.creator,
            idempotency_key=f"approval:{approval_id}",
            review_document=document,
            compiled_identity=compiled_identity,
        )
        self._bind_target("approval", target, approval_id, fingerprint)
        return self.approval_status(name=target.name)

    def _producer_output_family(
        self, item: Any
    ) -> ProducerOutputFamily | None:
        return self._producer_output_family_from_envelope(
            item.artifact_name,
            self.artifacts.catalog(item.artifact.ref),
        )

    def _approval_producer_families(
        self, bound: BoundOperationCall
    ) -> tuple[ProducerOutputFamily, ...]:
        """Resolve and de-duplicate complete producer families for all subjects."""

        by_identity: dict[str, ProducerOutputFamily] = {}
        by_members: dict[tuple[tuple[str, str | None, str], ...], ProducerOutputFamily] = {}
        for item in bound.inputs:
            family = self._producer_output_family(item)
            if family is None:
                continue
            if family.family_identity is None:
                raise OperationInvocationError("producer_family_identity_missing")
            prior = by_identity.get(family.family_identity)
            if prior is not None and prior != family:
                raise OperationInvocationError("producer_family_inconsistent")
            by_identity[family.family_identity] = family
            member_key = tuple(
                sorted(
                    (
                        member.port_name,
                        member.item_name,
                        member.ref.canonical_json(),
                    )
                    for member in family.members
                )
            )
            existing = by_members.get(member_key)
            if existing is not None:
                if existing != family:
                    raise OperationInvocationError("producer_family_inconsistent")
                continue
            by_members[member_key] = family
        return tuple(by_members.values())

    def _producer_output_family_from_envelope(
        self,
        artifact_name: str,
        envelope: Any,
    ) -> ProducerOutputFamily | None:
        run_family = self._run_output_family(envelope)
        if run_family is not None:
            return run_family
        return self._transform_output_family(artifact_name, envelope)

    def _run_output_family(self, envelope: Any) -> ProducerOutputFamily | None:
        if self.runs is None:
            return None
        status = self.runs.completed_for_output(envelope.ref)
        if status is None or status.output_ref != envelope.ref:
            return None
        try:
            producer = self._operation_catalog.operation(status.operation_id)
        except KeyError:
            return None
        if (
            producer.spec.executor.kind != "agent"
            or status.operation_version != producer.spec.version
            or status.operation_digest != producer.digest
        ):
            return None
        port_name = envelope.labels.get("operation_output_port")
        primary_port = next(
            (
                port
                for port in producer.spec.outputs
                if port.name == port_name and port.collection is None
            ),
            None,
        )
        if primary_port is None or not self._artifact_matches_output_port(
            envelope, primary_port
        ):
            return None
        sources = tuple(
            ProducerEvidenceSource(
                source_kind="run_input",
                source_name=value.source_name,
                ref=value.artifact_ref,
            )
            for value in status.inputs
            if value.usage
            in {"claim_evidence", "evidence_inventory", "cached_excerpt"}
        )
        return ProducerOutputFamily(
            primary_ref=envelope.ref,
            operation_id=producer.spec.operation_id,
            operation_version=producer.spec.version,
            operation_digest=producer.digest,
            members=(
                ProducerFamilyMember(
                    port_name=primary_port.name,
                    item_name=None,
                    ref=envelope.ref,
                ),
            ),
            evidence_sources=sources,
            reviewer_operation=(
                producer.spec.review.reviewer_operation
                if producer.spec.review is not None
                else None
            ),
            review_subject_outputs=(
                producer.spec.review.subject_outputs
                if producer.spec.review is not None
                else ()
            ),
            family_identity=canonical_sha256(
                {
                    "producer": "run",
                    "operation": producer.spec.operation_id,
                    "operation_version": producer.spec.version,
                    "operation_digest": producer.digest,
                    "run_id": status.run_id,
                    "primary_ref": envelope.ref,
                }
            ),
        )

    def _transform_output_family(
        self,
        artifact_name: str,
        envelope: Any,
    ) -> ProducerOutputFamily | None:
        labels = envelope.labels
        operation_id = labels.get("operation_id")
        operation_version = labels.get("operation_version")
        operation_digest = labels.get("operation_digest")
        invocation_fingerprint = labels.get("operation_invocation_fingerprint")
        if (
            not isinstance(operation_id, str)
            or not isinstance(operation_version, str)
            or not isinstance(operation_digest, str)
            or not isinstance(invocation_fingerprint, str)
            or labels.get("transform_profile") != operation_id
        ):
            return None
        try:
            compiled = self._operation_catalog.operation(operation_id)
        except KeyError:
            return None
        if (
            compiled.spec.executor.kind != "transform"
            or operation_version != compiled.spec.version
            or operation_digest != compiled.digest
        ):
            return None
        instance_bindings = self.bindings.list(
            instance=self._instance_id(), namespace="artifact"
        )
        subject_bindings = tuple(
            binding
            for binding in instance_bindings
            if binding.object_id == envelope.artifact_id
        )
        if not any(
            binding.name == artifact_name
            and binding.request_fingerprint == invocation_fingerprint
            for binding in subject_bindings
        ):
            return None
        siblings: dict[str, Any] = {}
        for binding in instance_bindings:
            if binding.request_fingerprint != invocation_fingerprint:
                continue
            candidate = self.artifacts.get_by_id(binding.object_id)
            candidate_labels = candidate.labels
            if candidate.parent_refs != envelope.parent_refs or any(
                candidate_labels.get(key) != expected
                for key, expected in (
                    ("operation_id", operation_id),
                    ("operation_version", operation_version),
                    ("operation_digest", operation_digest),
                    ("transform_profile", operation_id),
                    ("operation_invocation_fingerprint", invocation_fingerprint),
                )
            ):
                raise OperationInvocationError("producer_family_inconsistent")
            output_label = candidate_labels.get("output_label")
            if not isinstance(output_label, str):
                raise OperationInvocationError("producer_family_inconsistent")
            existing = siblings.get(output_label)
            if existing is not None and existing.ref != candidate.ref:
                raise OperationInvocationError("producer_family_inconsistent")
            siblings[output_label] = candidate
        if "primary" not in siblings or envelope.ref not in {
            value.ref for value in siblings.values()
        }:
            return None
        if self._transform_input_groups(compiled, envelope.parent_refs) is None:
            return None
        ordered_members = self._validated_transform_members(compiled, siblings)
        if ordered_members is None:
            return None
        return ProducerOutputFamily(
            primary_ref=siblings["primary"].ref,
            operation_id=operation_id,
            operation_version=compiled.spec.version,
            operation_digest=compiled.digest,
            members=ordered_members,
            evidence_sources=(),
            reviewer_operation=(
                compiled.spec.review.reviewer_operation
                if compiled.spec.review is not None
                else None
            ),
            review_subject_outputs=(
                compiled.spec.review.subject_outputs
                if compiled.spec.review is not None
                else ()
            ),
            family_identity=canonical_sha256(
                {
                    "producer": "transform",
                    "operation": operation_id,
                    "operation_version": compiled.spec.version,
                    "operation_digest": compiled.digest,
                    "invocation_fingerprint": invocation_fingerprint,
                    "ordered_parents": envelope.parent_refs,
                }
            ),
        )

    def _transform_input_groups(
        self, compiled: Any, parent_refs: tuple[Any, ...]
    ) -> dict[str, tuple[Any, ...]] | None:
        if len(parent_refs) != len(set(parent_refs)):
            return None
        envelopes = tuple(self.artifacts.verify(ref) for ref in parent_refs)
        ports = compiled.spec.inputs
        solutions: list[dict[str, tuple[Any, ...]]] = []

        def visit(port_index: int, offset: int, values: dict[str, tuple[Any, ...]]) -> None:
            if len(solutions) > 1:
                return
            if port_index == len(ports):
                if offset == len(envelopes):
                    solutions.append(dict(values))
                return
            port = ports[port_index]
            remaining_min = sum(item.min_items for item in ports[port_index + 1 :])
            remaining_max = sum(item.max_items for item in ports[port_index + 1 :])
            lower = max(port.min_items, len(envelopes) - offset - remaining_max)
            upper = min(port.max_items, len(envelopes) - offset - remaining_min)
            for count in range(lower, upper + 1):
                selected = envelopes[offset : offset + count]
                if not all(self._artifact_matches_input_port(item, port) for item in selected):
                    continue
                values[port.name] = selected
                visit(port_index + 1, offset + count, values)
            values.pop(port.name, None)

        visit(0, 0, {})
        return solutions[0] if len(solutions) == 1 else None

    def _validated_transform_members(
        self, compiled: Any, siblings: dict[str, Any]
    ) -> tuple[ProducerFamilyMember, ...] | None:
        by_port: dict[str, list[Any]] = {}
        valid_ports = {port.name for port in compiled.spec.outputs}
        for candidate in siblings.values():
            port_name = candidate.labels.get("operation_output_port")
            if port_name not in valid_ports:
                return None
            by_port.setdefault(port_name, []).append(candidate)
        expected_labels: list[tuple[str, str, int]] = []
        output_count = 0
        for port in compiled.spec.outputs:
            values = by_port.get(port.name, [])
            if not port.min_items <= len(values) <= port.max_items:
                return None
            if not all(self._artifact_matches_output_port(item, port) for item in values):
                return None
            for index in range(1, len(values) + 1):
                label = (
                    "primary"
                    if output_count == 0
                    else port.name
                    if port.collection is None and len(values) == 1
                    else f"{port.name}_{index:03d}"
                )
                expected_labels.append((label, port.name, index))
                output_count += 1
        if {label for label, _, _ in expected_labels} != set(siblings):
            return None
        if any(
            siblings[label].labels.get("operation_output_port") != port_name
            for label, port_name, _ in expected_labels
        ):
            return None
        return tuple(
            ProducerFamilyMember(
                port_name=port_name,
                item_name=(None if label == "primary" else label),
                ref=siblings[label].ref,
            )
            for label, port_name, _ in expected_labels
        )

    @staticmethod
    def _artifact_matches_input_port(envelope: Any, port: Any) -> bool:
        return bool(
            (port.schema_id == "*" or envelope.schema_id == port.schema_id)
            and (port.media_types == ("*/*",) or envelope.media_type in port.media_types)
            and envelope.size_bytes <= port.max_item_bytes
        )

    @staticmethod
    def _artifact_matches_output_port(envelope: Any, port: Any) -> bool:
        return bool(
            envelope.kind == port.kind
            and envelope.schema_id == port.schema_id
            and envelope.payload_schema_version == port.payload_schema_version
            and envelope.media_type in port.media_types
            and envelope.size_bytes <= port.max_item_bytes
        )

    def _effect_operation_plan(
        self, bound: BoundOperationCall
    ) -> EffectExecutorPlan:
        plan = (
            bound.executor_plan
            if isinstance(bound.executor_plan, EffectExecutorPlan)
            else effect_executor_plan(bound)
        )
        payloads = tuple(
            item for item in bound.inputs if item.port_name == plan.payload_port
        )
        if len(payloads) != 1 or len(bound.inputs) != 1:
            raise OperationInvocationError("effect_payload_not_singular")
        if self.execution_bridge is None:
            raise OperationInvocationError("effect_bridge_unavailable")
        if not self.execution_bridge.has_adapter(plan.executor):
            raise OperationInvocationError("runtime_binding_unavailable")
        try:
            self.execution_bridge.validate_request(
                executor=plan.executor,
                preparation_profile=plan.preparation_profile,
                payload=self.artifacts.read(payloads[0].artifact.ref),
            )
        except Exception as error:
            raise OperationInvocationError("effect_preparation_invalid") from error
        return plan

    def _invoke_compiled_transform(
        self,
        bound: BoundOperationCall,
        on_conflict: str,
    ) -> dict[str, Any]:
        name = bound.name
        profile = bound.compiled.spec.operation_id
        inputs = bound.inputs
        source_names = tuple(item.source_name for item in inputs)
        artifact_names = tuple(item.artifact_name for item in inputs)
        if len(source_names) != len(set(source_names)):
            raise RootToolError("transform source names must be unique")
        if len(artifact_names) != len(set(artifact_names)):
            raise RootToolError("transform artifacts must be unique")
        adapter = CompiledTransformAdapter(bound)

        nonqualifying_selector = getattr(
            adapter, "nonqualifying_input_names", None
        )
        allowed_nonqualifying = (
            frozenset(nonqualifying_selector(profile, source_names))
            if nonqualifying_selector is not None
            else frozenset()
        )
        if not allowed_nonqualifying.issubset(source_names):
            raise RootToolError(
                "deterministic transform selected invalid nonqualifying inputs"
            )

        envelopes = tuple(
            self.artifacts.get_by_id(
                self._resolve_input_artifact(
                    item.artifact_name,
                    allow_nonqualifying=(
                        item.source_name in allowed_nonqualifying
                    ),
                )
            )
            for item in inputs
        )
        derived_from_nonqualifying = any(
            item.source_name in allowed_nonqualifying
            and (
                envelope.labels.get("scientific_claim_admissible") == "false"
                or (
                    (signal := self._scheduler_signal_for_output(envelope.ref))
                    is not None
                    and signal.verdict in _NONQUALIFYING_HANDOFF_VERDICTS
                )
            )
            for item, envelope in zip(inputs, envelopes, strict=True)
        )
        by_source = {
            item.source_name: envelope
            for item, envelope in zip(inputs, envelopes, strict=True)
        }
        input_names = tuple(item.source_name for item in inputs)
        dynamic_parentage = getattr(
            adapter, "required_input_parentage_for_inputs", None
        )
        parentage = getattr(adapter, "required_input_parentage", None)
        parentage_pairs = (
            dynamic_parentage(profile, input_names)
            if dynamic_parentage is not None
            else parentage(profile)
            if parentage is not None
            else ()
        )
        for child_name, parent_name in parentage_pairs:
            if child_name not in by_source or parent_name not in by_source:
                raise RootToolError(
                    "deterministic transform parentage names are absent"
                )
            if by_source[parent_name].ref not in by_source[child_name].parent_refs:
                raise RootToolError(
                    f"{child_name} was not produced from the exact {parent_name}"
                )
        payload_selector = getattr(adapter, "payload_input_names", None)
        selected_payload_names = (
            tuple(payload_selector(profile, input_names))
            if payload_selector is not None
            else input_names
        )
        if len(selected_payload_names) != len(set(selected_payload_names)) or not set(
            selected_payload_names
        ).issubset(input_names):
            raise RootToolError(
                "deterministic transform selected invalid payload input names"
            )
        selected = set(selected_payload_names)
        payloads = {
            item.source_name: (
                self.artifacts.read(envelope.ref)
                if item.source_name in selected
                else b""
            )
            for item, envelope in zip(inputs, envelopes, strict=True)
        }
        try:
            outputs = adapter.transform(profile=profile, inputs=payloads)
        except Exception as error:
            raise RootToolError(f"deterministic transform failed: {error}") from error
        labels = tuple(output.label for output in outputs)
        if not outputs or "primary" not in labels or len(labels) != len(set(labels)):
            raise RootToolError(
                "deterministic transform must return unique outputs including primary"
            )

        fingerprint = canonical_sha256(
            {
                "operation": bound.compiled.spec.operation_id,
                "operation_version": bound.compiled.spec.version,
                "operation_digest": bound.compiled.digest,
                "profile": profile,
                "inputs": [
                    {"source_name": item.source_name, "artifact_ref": envelope.ref}
                    for item, envelope in zip(inputs, envelopes, strict=True)
                ],
            }
        )
        parent_refs = tuple(envelope.ref for envelope in envelopes)
        with self._create_lock:
            target = self._creation_target("artifact", name, fingerprint, on_conflict)
            registered = []
            for output in outputs:
                output_name = (
                    target.name
                    if output.label == "primary"
                    else _derived_name(target.name, output.label)
                )
                existing_id = self._optional("artifact", output_name)
                if existing_id is None:
                    envelope = self.artifacts.register(
                        output.content,
                        ArtifactRegistration(
                            kind=output.kind,
                            schema_id=output.schema,
                            payload_schema_version=output.payload_schema_version,
                            media_type=output.media_type,
                            creator=self.intake.creator,
                            parent_refs=parent_refs,
                            labels={
                                "transform_profile": profile,
                                "output_label": output.label,
                                "operation_invocation_fingerprint": fingerprint,
                                **(
                                    {"operation_output_port": output.port_name}
                                    if output.port_name is not None else {}
                                ),
                                **_operation_artifact_labels(bound),
                                **(
                                    {"scientific_claim_admissible": "false"}
                                    if derived_from_nonqualifying
                                    else {}
                                ),
                            },
                        ),
                        idempotency_key=(
                            "artifact-transform:"
                            + canonical_sha256(
                                {
                                    "instance": self._instance_id(),
                                    "name": output_name,
                                    "fingerprint": fingerprint,
                                    "label": output.label,
                                }
                            )
                        ),
                    )
                    if output.label == "primary":
                        binding = self._bind_target(
                            "artifact", target, envelope.artifact_id, fingerprint
                        )
                    else:
                        binding = self._bind(
                            "artifact",
                            output_name,
                            envelope.artifact_id,
                            request_fingerprint=fingerprint,
                        )
                else:
                    envelope = self.artifacts.get_by_id(existing_id)
                    if self.artifacts.read(envelope.ref) != output.content:
                        raise RootToolError(
                            "existing transform output differs from deterministic result"
                        )
                    binding = self._binding("artifact", output_name)
                registered.append(
                    {
                        "output_label": output.label,
                        "artifact_name": binding.name,
                        "kind": envelope.kind,
                        "schema": envelope.schema_id,
                        "media_type": envelope.media_type,
                        "size_bytes": envelope.size_bytes,
                    }
                )
        return {"name": target.name, "profile": profile, "outputs": registered}

    def _prepare_operation_call(
        self,
        *,
        name: str,
        operation_id: str,
        inputs: tuple[_OperationInputSelection, ...],
        instruction: str | None,
        parameters: dict[str, Any],
        on_conflict: str,
        resume_from: str | None = None,
    ) -> BoundOperationCall:
        del on_conflict
        try:
            compiled = self._operation_catalog.operation(operation_id)
        except KeyError as error:
            raise OperationInvocationError("operation_unknown") from error
        ports = tuple(item.port for item in inputs)
        if len(ports) != len(set(ports)):
            raise OperationInvocationError("input_port_duplicate")
        current_selections = tuple(
            self.bindings.scientific_selections(instance=self._instance_id())
        )
        current_lineages = {
            item.logical_name
            for item in current_selections
            if item.artifact_ref is None
        }
        current_refs = tuple(
            item.artifact_ref
            for item in current_selections
            if item.artifact_ref is not None
        )
        resolved: dict[str, tuple[InvocationArtifact, ...]] = {}
        for selection in inputs:
            try:
                port = next(
                    item for item in compiled.spec.inputs if item.name == selection.port
                )
            except StopIteration:
                resolved[selection.port] = ()
                continue
            artifacts: list[InvocationArtifact] = []
            for artifact_name in selection.artifact_names:
                try:
                    self._resolve("artifact", artifact_name)
                    artifact_id = self._resolve_input_artifact(
                        artifact_name,
                        allow_nonqualifying=True,
                    )
                    binding = self._binding("artifact", artifact_name)
                    envelope = self.artifacts.get_by_id(artifact_id)
                except Exception as error:
                    raise OperationInvocationError(
                        "input_artifact_unavailable", port=selection.port
                    ) from error
                signal = self._scheduler_signal_for_output(envelope.ref)
                artifacts.append(
                    InvocationArtifact(
                        artifact_name=artifact_name,
                        ref=envelope.ref,
                        schema_id=envelope.schema_id,
                        media_type=envelope.media_type,
                        size_bytes=envelope.size_bytes,
                        current=(
                            self.runs.input_is_current(
                                instance_id=self._instance_id(),
                                artifact_name=artifact_name,
                                artifact_ref=envelope.ref,
                            )
                            if self.runs is not None
                            else (
                                binding.logical_name in current_lineages
                                or self._artifact_descends_from(
                                    envelope.ref, current_refs
                                )
                            )
                        ),
                        parent_refs=envelope.parent_refs,
                        labels=tuple(sorted(envelope.labels.items())),
                        handoff_verdict=(signal.verdict if signal is not None else None),
                    )
                )
            resolved[selection.port] = tuple(artifacts)
        for port in compiled.spec.inputs:
            if port.min_items == 0:
                resolved.setdefault(port.name, ())
        bound = preflight_operation(
            compiled,
            name=name,
            artifacts_by_port=resolved,
            instruction=instruction,
            parameters=parameters,
        )
        if (
            self.runs is not None
            and compiled.spec.executor.kind == "agent"
            and not self.runs.backend.supports_operation(compiled)
        ):
            raise OperationInvocationError("runtime_backend_capability_missing")
        if (
            self.runs is not None
            and compiled.spec.executor.kind == "agent"
            and operation_local_worker_missing_tools(compiled)
        ):
            raise OperationInvocationError("runtime_backend_capability_missing")
        if resume_from is not None:
            if compiled.spec.executor.kind != "agent" or self.runs is None:
                raise OperationInvocationError("runtime_backend_capability_missing")
            try:
                source = self.runs.status(self._resolve("run", resume_from))
            except Exception as error:
                raise OperationInvocationError("recovery_source_unavailable") from error
            if source.state != "failed" or source.recovery_draft is None:
                raise OperationInvocationError("recovery_source_unavailable")
        self._validate_operation_input_admission(bound)
        if compiled.spec.executor.kind == "effect":
            return replace(
                bound, executor_plan=self._effect_operation_plan(bound)
            )
        return bound

    def _artifact_descends_from(
        self, reference: Any, anchors: tuple[Any, ...]
    ) -> bool:
        if not anchors:
            return False
        pending = [reference]
        seen = set()
        anchor_set = set(anchors)
        while pending:
            current = pending.pop()
            if current in anchor_set:
                return True
            if current in seen:
                continue
            seen.add(current)
            if len(seen) > 4096:
                raise OperationInvocationError("current_provenance_too_large")
            pending.extend(self.artifacts.catalog(current).parent_refs)
        return False

    def _validate_operation_input_admission(self, bound: BoundOperationCall) -> None:
        self._validate_producer_output_admission(bound)
        self._validate_operation_input_cohorts(bound)
        for item in bound.inputs:
            if (
                bound.compiled.spec.consequence != "explore"
                and item.usage == "claim_evidence"
                and not _claim_admissible(
                    dict(item.artifact.labels), item.artifact.handoff_verdict
                )
            ):
                raise OperationInvocationError(
                    "input_scientific_claim_forbidden", port=item.port_name
                )

    def _validate_operation_input_cohorts(self, bound: BoundOperationCall) -> None:
        """Apply compiled all-or-none and same-approval input facts generically."""

        actual = {item.port_name: item for item in bound.inputs}
        cohorts: dict[str, list[Any]] = {}
        for port in bound.compiled.spec.inputs:
            if port.cohort_id is not None:
                cohorts.setdefault(port.cohort_id, []).append(port)
        for cohort_id, ports in cohorts.items():
            present = [port for port in ports if port.name in actual]
            if not present:
                continue
            missing = next((port.name for port in ports if port.name not in actual), None)
            if missing is not None:
                raise OperationInvocationError("input_cohort_incomplete", port=missing)
            approval_ports = [port for port in ports if port.approval_kind is not None]
            if not approval_ports:
                continue
            contract = {
                (
                    port.approval_kind,
                    port.accepted_approval_options,
                    port.accepted_approval_operations,
                )
                for port in approval_ports
            }
            if len(contract) != 1:
                raise OperationInvocationError(
                    "input_cohort_contract_invalid", port=cohort_id
                )
            kind, options, _ = next(iter(contract))
            assert kind is not None
            refs = tuple(actual[port.name].artifact.ref for port in approval_ports)
            providers = bound.compiled.approval_providers.get(cohort_id, ())
            if not providers or self.approvals is None:
                raise OperationInvocationError(
                    "input_cohort_approval_missing", port=cohort_id
                )
            approved = self.approvals.are_subjects_approved_by_provider(
                    refs,
                    kind=kind,
                    accepted_options=options,
                    accepted_providers=tuple(
                        CompiledApprovalIdentity(
                            operation_id=provider.operation_id,
                            operation_version=provider.version,
                            operation_digest=provider.operation_digest,
                            approval_contract_digest=provider.approval_contract_digest,
                        )
                        for provider in providers
                    ),
                )
            if not approved:
                raise OperationInvocationError(
                    "input_cohort_approval_missing", port=cohort_id
                )

    def _validate_producer_output_admission(
        self,
        bound: BoundOperationCall,
    ) -> None:
        direct_revision = direct_revision_ports(bound.compiled)
        direct_base_port = (
            direct_revision[0].name if direct_revision is not None else None
        )
        change_requests = tuple(
            item for item in bound.inputs if item.usage == "change_request"
        )
        for item in bound.inputs:
            artifact = item.artifact
            usage = item.usage
            port_name = item.port_name
            policy = self._operation_output_policy(artifact)
            if policy is None:
                if port_name == direct_base_port:
                    raise OperationInvocationError(
                        "input_output_usage_forbidden", port=port_name
                    )
                continue
            allowed_usages, review = policy
            if usage not in allowed_usages:
                raise OperationInvocationError(
                    "input_output_usage_forbidden", port=port_name
                )
            if review is None:
                if port_name == direct_base_port:
                    self._validate_direct_revision_request(
                        bound,
                        base=artifact,
                        frozen_review=None,
                        change_requests=change_requests,
                    )
                continue
            if port_name == direct_base_port:
                self._validate_direct_revision_request(
                    bound,
                    base=artifact,
                    frozen_review=review,
                    change_requests=change_requests,
                )
                continue
            required_reviewer, reviewer_input_port, accepted_verdicts = review
            if (
                bound.compiled.spec.operation_id == required_reviewer
                and port_name == reviewer_input_port
            ):
                continue
            if not any(
                self._is_exact_reviewer_output(
                    candidate.ref,
                    reviewer_operation=required_reviewer,
                    reviewer_input_port=reviewer_input_port,
                    accepted_verdicts=accepted_verdicts,
                    subject_ref=artifact.ref,
                )
                for candidate in (value.artifact for value in bound.inputs)
                if candidate.ref != artifact.ref
            ):
                raise OperationInvocationError(
                    "input_independent_review_missing", port=port_name
                )

    def _validate_direct_revision_request(
        self,
        bound: BoundOperationCall,
        *,
        base: InvocationArtifact,
        frozen_review: tuple[str, str, tuple[str, ...]] | None,
        change_requests: tuple[Any, ...],
    ) -> None:
        declared = bound.compiled.spec.review
        assert declared is not None
        assert declared.reviewer_operation is not None
        assert declared.reviewer_input_port is not None
        direct_review = (
            declared.reviewer_operation,
            declared.reviewer_input_port,
            declared.accepted_verdicts,
        )
        if frozen_review is not None and frozen_review != direct_review:
            raise OperationInvocationError(
                "input_revision_review_contract_mismatch"
            )
        if not change_requests:
            return
        if frozen_review is None:
            raise OperationInvocationError("input_change_request_mismatch")
        reviewer_operation, reviewer_input_port, _ = frozen_review
        invalid = next(
            (
                item
                for item in change_requests
                if not self._is_exact_reviewer_output(
                    item.artifact.ref,
                    reviewer_operation=reviewer_operation,
                    reviewer_input_port=reviewer_input_port,
                    accepted_verdicts=None,
                    subject_ref=base.ref,
                )
            ),
            None,
        )
        if invalid is not None:
            raise OperationInvocationError(
                "input_change_request_mismatch", port=invalid.port_name
            )

    def _operation_output_policy(
        self, artifact: InvocationArtifact
    ) -> tuple[tuple[str, ...], tuple[str, str, tuple[str, ...]] | None] | None:
        envelope = self.artifacts.catalog(artifact.ref)
        operation_id = envelope.labels.get("operation_id")
        digest = envelope.labels.get("operation_digest")
        port_name = envelope.labels.get("operation_output_port")
        if operation_id is None and digest is None and port_name is None:
            return None
        try:
            compiled = self._operation_catalog.operation(str(operation_id))
        except KeyError as error:
            raise OperationInvocationError("input_producer_contract_unavailable") from error
        if compiled.digest != digest:
            raise OperationInvocationError("input_producer_contract_changed")
        try:
            port = next(value for value in compiled.spec.outputs if value.name == port_name)
        except StopIteration as error:
            raise OperationInvocationError("input_producer_port_unknown") from error
        declared = compiled.spec.review
        review = None
        if (
            declared is not None and declared.reviewer_operation is not None
            and port.name in declared.subject_outputs
        ):
            assert declared.reviewer_input_port is not None
            review = (
                declared.reviewer_operation,
                declared.reviewer_input_port,
                declared.accepted_verdicts,
            )
        return port.allowed_input_usages, review



__all__ = ["RootOperationRoutes"]
