"""Instance, inventory, and Artifact routes for the Root scheduler facade."""

from __future__ import annotations

import hashlib
from typing import Any

from ..schema.approval import ApprovalOption, HumanDecision
from ..schema.artifact import ArtifactRegistration
from ..schema.common import canonical_json, canonical_sha256
from ..service.scheduler_bindings import SchedulerBinding, SchedulerInstanceNotFound
from .mcp_root_shared import RootToolError, identity_word as _identity_word

class RootInstanceRoutes:
    def instance_prepare(
        self, *, name: str, title: str, objective: str
    ) -> dict[str, Any]:
        if self.session_key is None:
            raise RootToolError(
                "instance proposals require a transport-bound scheduler session"
            )
        with self._create_lock:
            proposal = self.bindings.prepare_instance_proposal(
                name=name,
                title=title,
                objective=objective,
                session_key=self.session_key,
            )
            if not self.approvals.has_request(proposal.approval_id):
                payload = canonical_json(
                    {
                        "schema_version": 1,
                        "name": proposal.name,
                        "title": proposal.title,
                        "objective": proposal.objective,
                        "authorization_effect": (
                            "用户确认后，控制面创建该 ResearchInstance，"
                            "并绑定发起草案的调度会话。"
                        ),
                        "non_effects": [
                            "不批准任何科学结论",
                            "不授权任何仿真执行",
                            "不修改其他 ResearchInstance",
                        ],
                    }
                )
                proposal_ref = self.artifacts.register(
                    payload,
                    ArtifactRegistration(
                        artifact_id=f"art_{proposal.proposal_id}",
                        kind="research_instance_proposal",
                        schema_id="scidiscovery.research-instance-proposal.v1",
                        payload_schema_version=1,
                        media_type="application/json",
                        creator=self.intake.creator,
                        labels={"semantic_name": proposal.name},
                        confidentiality="approval_only",
                    ),
                    idempotency_key=f"instance-proposal:{proposal.proposal_id}",
                ).ref
                self.approvals.create_request(
                    approval_id=proposal.approval_id,
                    kind="research_instance_registration",
                    subject_refs=(proposal_ref,),
                    question=(
                        f"是否创建研究实例“{proposal.title}”"
                        f"（{proposal.name}）？"
                    ),
                    options=(
                        ApprovalOption(
                            option_id="create_instance",
                            label="创建并进入该实例",
                            description=(
                                "按页面展示的名称、标题和目标创建独立研究实例。"
                            ),
                            requires_rationale=False,
                        ),
                        ApprovalOption(
                            option_id="revise_instance",
                            label="要求修改草案",
                            description="不创建实例，并说明需要修改的名称、目标或范围。",
                            requires_rationale=True,
                        ),
                        ApprovalOption(
                            option_id="cancel_instance",
                            label="取消创建",
                            description="关闭本次草案，不创建研究实例。",
                            requires_rationale=False,
                            terminal_state="cancelled_by_human",
                        ),
                    ),
                    requested_by=self.intake.creator,
                    idempotency_key=f"instance-approval:{proposal.proposal_id}",
                )
        return self.instance_status(name=name)

    def instance_status(self, *, name: str) -> dict[str, Any]:
        proposal = self.bindings.get_instance_proposal(name=name)
        approval = self.approvals.status(proposal.approval_id)
        if approval.decision_ref is not None and proposal.state == "pending":
            decision = HumanDecision.model_validate_json(
                self.approvals.artifacts.read(approval.decision_ref), strict=True
            )
            proposal = self.bindings.apply_instance_proposal_decision(
                approval_id=proposal.approval_id,
                selected_option=decision.selected_option,
            )
            if proposal is None:
                raise RootToolError("instance proposal ownership disappeared")
        result = {
            "name": proposal.name,
            "title": proposal.title,
            "objective": proposal.objective,
            "proposal_status": proposal.state,
            "selected_option": proposal.selected_option,
            "created_at": proposal.created_at,
            "resolved_at": proposal.resolved_at,
        }
        if proposal.state == "activated" and proposal.instance_id is not None:
            instance = self.bindings.get_instance(instance_id=proposal.instance_id)
            result["instance_state"] = instance.state
            if instance.state == "active" and (
                self.session_key is None or self.session_key == proposal.session_key
            ):
                self.instance = instance.instance_id
                self._persist_instance_selection()
        if approval.status == "pending" and self.approval_base_url is not None:
            result["review_url"] = self.approval_base_url.rstrip("/") + "/"
        return result

    def instance_select(self, *, name: str) -> dict[str, Any]:
        value = self.bindings.select_instance(name=name)
        if self.session_key is None:
            self.instance = value.instance_id
            return self._instance_value(value)
        current = self.bindings.session_instance(session_key=self.session_key)
        if current == value.instance_id:
            self.instance = current
            return self._instance_value(value)
        return self._prepare_session_binding_review(preferred_name=name)

    def instance_current(self) -> dict[str, Any]:
        if self.session_key is not None:
            bound = self.bindings.session_instance(session_key=self.session_key)
            if bound is None:
                try:
                    review = self._prepare_session_binding_review()
                except SchedulerInstanceNotFound as error:
                    raise RootToolError(str(error)) from error
                rebound = self.bindings.session_instance(session_key=self.session_key)
                if rebound is None:
                    self.instance = None
                    return review
                self.instance = rebound
        value = self.bindings.get_instance(instance_id=self._instance_id())
        return self._instance_value(value)

    def instance_list(self, *, state: str | None) -> dict[str, Any]:
        return {
            "instances": [
                self._instance_value(value)
                for value in self.bindings.list_instances(state=state)
            ]
        }

    def instance_close(self) -> dict[str, Any]:
        with self._create_lock:
            instance_id = self._instance_id()
            for binding in self.bindings.list(instance=instance_id, namespace="run"):
                if self.runs.status(binding.object_id).state in {"queued", "running"}:
                    raise RootToolError("research instance has an active scientific Run")
            for binding in self.bindings.list(instance=instance_id, namespace="approval"):
                if self.approvals.status(binding.object_id).status == "pending":
                    raise RootToolError("research instance has a pending human review")
            if self.bindings.instance_pending_binding_approval_ids(
                instance=instance_id
            ):
                raise RootToolError(
                    "research instance is named by a pending session-binding review"
                )
            for binding in self.bindings.list(
                instance=instance_id, namespace="execution"
            ):
                if self.executions.status(binding.object_id).state not in {
                    "collected",
                    "abandoned",
                }:
                    raise RootToolError(
                        "research instance has an unfinished or uncollected execution"
                    )
            value = self.bindings.close_instance(instance_id=instance_id)
            self.instance = None
            return self._instance_value(value)

    def scientific_current(self) -> dict[str, Any]:
        instance_id = self._instance_id()
        latest: dict[str, SchedulerBinding] = {}
        for binding in self.bindings.list(instance=instance_id, namespace="artifact"):
            previous = latest.get(binding.logical_name)
            if previous is None or binding.revision > previous.revision:
                latest[binding.logical_name] = binding
        return {
            "selections": [
                {
                    "kind": item.kind,
                    "artifact_name": next(
                        (
                            binding.name
                            for binding in self.bindings.list(
                                instance=instance_id, namespace="artifact"
                            )
                            if item.artifact_ref is not None
                            and binding.object_id == item.artifact_ref.artifact_id
                        ),
                        latest[item.logical_name].name,
                    ),
                    "selected_at": item.selected_at,
                }
                for item in self.bindings.scientific_selections(instance=instance_id)
                if item.logical_name in latest
            ]
        }

    def scientific_current_select(
        self, *, name: str, kind: str, expected_artifact_name: str | None
    ) -> dict[str, Any]:
        artifact_id = self._resolve_input_artifact(name)
        binding = self._binding("artifact", name)
        envelope = self.artifacts.get_by_id(artifact_id)
        if envelope.kind != kind:
            raise RootToolError(
                f"{name}: scientific object kind is {envelope.kind}, expected {kind}"
            )
        expected_ref = None
        if expected_artifact_name is not None:
            expected_id = self._resolve_input_artifact(expected_artifact_name)
            expected_ref = self.artifacts.get_by_id(expected_id).ref
        selected = self.bindings.select_scientific_object(
            instance=self._instance_id(),
            kind=kind,
            logical_name=binding.logical_name,
            artifact_ref=envelope.ref,
            expected_ref=expected_ref,
        )
        return {
            "kind": selected.kind,
            "artifact_name": binding.name,
            "selected_at": selected.selected_at,
        }

    def scientific_inventory(self) -> dict[str, Any]:
        """Return only latest scientific records and explicit current selections."""

        instance_id = self._instance_id()
        latest: dict[str, SchedulerBinding] = {}
        for binding in self.bindings.list(instance=instance_id, namespace="artifact"):
            previous = latest.get(binding.logical_name)
            if previous is None or binding.revision > previous.revision:
                latest[binding.logical_name] = binding
        selections = {
            item.kind: item.logical_name
            for item in self.bindings.scientific_selections(instance=instance_id)
        }
        objects = []
        for binding in sorted(latest.values(), key=lambda item: item.logical_name):
            envelope = self.artifacts.get_by_id(binding.object_id)
            signal = self._scheduler_signal_for_output(envelope.ref)
            objects.append(
                {
                    "artifact_name": binding.name,
                    "kind": envelope.kind,
                    "schema": envelope.schema_id,
                    "revision": binding.revision,
                    "selected_current": any(
                        logical_name == binding.logical_name
                        for logical_name in selections.values()
                    ),
                    "claim_admissible": (
                        envelope.labels.get("scientific_claim_admissible") != "false"
                    ),
                    "producer_handoff": (
                        signal.verdict if signal is not None else None
                    ),
                }
            )
        return {
            "objects": objects,
            "public_operations": self.operation_catalog(scope="public")["operations"],
            "current_selections": [
                {"kind": kind, "logical_name": logical_name}
                for kind, logical_name in sorted(selections.items())
            ],
        }

    def lifecycle_events(self) -> dict[str, Any]:
        """Read changed lifecycle states through a durable service-owned cursor."""

        instance_id = self._instance_id()
        states: list[tuple[str, str, str]] = []
        for binding in self.bindings.list(instance=instance_id, namespace="run"):
            states.append(("run", binding.name, self.runs.status(binding.object_id).state))
        for binding in self.bindings.list(instance=instance_id, namespace="approval"):
            states.append(
                ("approval", binding.name, self.approvals.status(binding.object_id).status)
            )
        for binding in self.bindings.list(instance=instance_id, namespace="execution"):
            states.append(
                ("execution", binding.name, self.executions.status(binding.object_id).state)
            )
        if len(states) > 1024:
            raise RootToolError("scheduler lifecycle inventory exceeds its bounded view")
        observer = self.session_key or f"facade:{instance_id}"
        changes = self.bindings.observe_state_changes(
            instance=instance_id,
            observer_key=observer,
            states=tuple(states),
        )
        return {
            "events": [
                {
                    "object_type": item.object_type,
                    "name": item.name,
                    "previous_state": item.previous_state,
                    "state": item.state,
                    "observed_at": item.observed_at,
                }
                for item in changes
            ]
        }

    def artifact_ingest_file(
        self,
        *,
        name: str,
        relative_path: str,
        media_type: str | None,
        on_conflict: str,
    ) -> dict[str, Any]:
        prepared = self.intake.prepare_file(
            relative_path=relative_path, media_type=media_type
        )
        fingerprint = canonical_sha256(
            {
                "operation": "artifact_ingest_file",
                "relative_path": prepared.relative_path,
                "media_type": prepared.media_type,
                "payload_sha256": hashlib.sha256(prepared.content).hexdigest(),
            }
        )
        with self._create_lock:
            target = self._creation_target(
                "artifact", name, fingerprint, on_conflict
            )
            if target.existing_object_id is None:
                reference = self.intake.ingest_prepared(prepared)
                binding = self._bind_target(
                    "artifact", target, reference.artifact_id, fingerprint
                )
            else:
                binding = self._binding("artifact", target.name)
        return {**self._binding_value(binding), "state": "bound"}

    def artifact_catalog(self, *, name: str) -> dict[str, Any]:
        binding = self._binding("artifact", name)
        envelope = self.artifacts.get_by_id(binding.object_id)
        labels = {
            key: value
            for key, value in envelope.labels.items()
            if not _identity_word(key)
        }
        return {
            **self._binding_value(binding),
            "kind": envelope.kind,
            "schema": envelope.schema_id,
            "payload_schema_version": envelope.payload_schema_version,
            "media_type": envelope.media_type,
            "size_bytes": envelope.size_bytes,
            "created_at": envelope.created_at,
            "labels": labels,
        }



__all__ = ["RootInstanceRoutes"]
