"""Semantic scheduler MCP with all control identity kept behind the service."""

from __future__ import annotations

import threading
from dataclasses import dataclass
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError

from ..execution_bridge import ExecutionBridge
from ..schema.approval import (
    ApprovalOption,
    HumanDecision,
)
from ..schema.artifact import ArtifactRegistration
from ..schema.common import canonical_json
from ..service.approvals import ApprovalService
from ..service.artifacts import ArtifactService
from ..service.executions import ExecutionService
from ..service.intake import SecureIntakeService
from ..service.scheduler_bindings import (
    SchedulerBinding,
    SchedulerBindingService,
    SchedulerInstanceNotFound,
    SchedulerNameConflict,
    SchedulerNameNotFound,
)
from ..service.runs import RunService
from ...operations.catalog import CompiledCatalog, compile_installed_catalog
from .mcp_root_shared import (
    CreationTarget as _CreationTarget,
    RootToolError,
)
from .mcp_root_approval_routes import RootApprovalRoutes
from .mcp_root_execution_routes import RootExecutionRoutes
from .mcp_root_instance_routes import RootInstanceRoutes
from .mcp_root_operation_routes import RootOperationRoutes
from .mcp_root_run_routes import RootRunRoutes


_NAME_PATTERN = r"^[A-Za-z0-9][A-Za-z0-9_.:/-]{0,255}$"
_SOURCE_NAME_PATTERN = r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$"
class RootToolInput(BaseModel):
    model_config = ConfigDict(extra="forbid")


class EmptyInput(RootToolInput):
    pass


class OperationCatalogInput(RootToolInput):
    scope: Literal["public", "support", "internal", "all"] = "public"


class NamedInput(RootToolInput):
    name: str = Field(pattern=_NAME_PATTERN)


class InstancePrepareInput(NamedInput):
    title: str = Field(min_length=1, max_length=512)
    objective: str = Field(min_length=1, max_length=8192)


class InstanceListInput(RootToolInput):
    state: Literal["active", "closed"] | None = None


class RevisionInput(RootToolInput):
    on_conflict: Literal["reject", "create_revision"] = "reject"


class IngestFileInput(NamedInput, RevisionInput):
    relative_path: str = Field(min_length=1, max_length=4096)
    media_type: str | None = Field(default=None, min_length=3, max_length=255)


class OperationInputSelection(RootToolInput):
    port: str = Field(pattern=_SOURCE_NAME_PATTERN)
    artifact_names: tuple[str, ...] = Field(max_length=256)


class OperationCallInput(NamedInput, RevisionInput):
    operation_id: str = Field(min_length=1, max_length=128)
    inputs: tuple[OperationInputSelection, ...] = Field(max_length=64)
    instruction: str | None = Field(default=None, max_length=65536)
    parameters: dict[str, Any] = Field(default_factory=dict, max_length=32)
    resume_from: str | None = Field(default=None, pattern=_NAME_PATTERN)


class ScientificCurrentSelectInput(NamedInput):
    kind: str = Field(pattern=_NAME_PATTERN)
    expected_artifact_name: str | None = Field(pattern=_NAME_PATTERN)


class RunListInput(RootToolInput):
    state: Literal["queued", "running", "completed", "failed"] | None = None
    limit: int = Field(default=50, ge=1, le=100)


class RunFailureInput(NamedInput):
    reason: str = Field(min_length=1, max_length=4096)
    expected_state: Literal["queued", "running"]
    expected_last_activity_at: str | None
    timed_out: bool = False


class ApprovalListInput(RootToolInput):
    status: Literal["pending", "decided", "expired", "cancelled_by_human"] | None = None
    limit: int = Field(default=50, ge=1, le=100)


class ExecutionCapabilitiesInput(RootToolInput):
    operation_id: str = Field(min_length=1, max_length=256)


class ExecutionCapabilityBindInput(NamedInput, RevisionInput):
    operation_id: str = Field(min_length=1, max_length=256)
    profile: str = Field(pattern=_NAME_PATTERN)


class ExecutionListInput(RootToolInput):
    state: Literal[
        "created",
        "authorized",
        "submitted",
        "running",
        "cancelling",
        "succeeded",
        "failed",
        "cancelled",
        "collected",
        "abandoned",
    ] | None = None
    limit: int = Field(default=50, ge=1, le=100)


@dataclass(frozen=True)
class RootTool:
    name: str
    description: str
    input_model: type[RootToolInput]

    def schema(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.input_model.model_json_schema(),
        }


ROOT_TOOLS = (
    RootTool("instance_prepare", "Freeze one research-instance proposal for direct local human review.", InstancePrepareInput),
    RootTool("instance_status", "Read one named instance proposal and its human-decision state.", NamedInput),
    RootTool("instance_select", "Request local human review before binding this MCP session to one existing instance.", NamedInput),
    RootTool("instance_current", "Read the bound research instance or prepare local human review for an unbound MCP session.", EmptyInput),
    RootTool("instance_list", "List research instances without exposing internal identity.", InstanceListInput),
    RootTool("instance_close", "Close the current research instance against further writes.", EmptyInput),
    RootTool("scientific_inventory", "List current immutable scientific objects without suggesting a workflow or capability.", EmptyInput),
    RootTool("scientific_current", "Read explicit current scientific-object selections for this research instance.", EmptyInput),
    RootTool("scientific_current_select", "Compare-and-set one immutable scientific object as the explicit current selection.", ScientificCurrentSelectInput),
    RootTool("lifecycle_events", "Return persistent semantic task, approval, and execution state changes for this scheduler process.", EmptyInput),
    RootTool("artifact_ingest_file", "Freeze and bind one project file under a semantic name.", IngestFileInput),
    RootTool("artifact_catalog", "Read sanitized metadata for one bound semantic input.", NamedInput),
    RootTool("operation_catalog", "List one view of installed compiled operations without implementation identity.", OperationCatalogInput),
    RootTool("operation_preflight", "Check one exact operation call without writing control state.", OperationCallInput),
    RootTool("operation_invoke", "Create one Agent, Transform, or Effect through the compiled operation catalog.", OperationCallInput),
    RootTool("run_list", "List minimal Runs in this research instance.", RunListInput),
    RootTool("run_status", "Read one minimal Run and its bounded completion signal.", NamedInput),
    RootTool("run_record_failure", "Record failure of one running minimal Run.", RunFailureInput),
    RootTool("approval_list", "List named reviews in this scheduler instance.", ApprovalListInput),
    RootTool("approval_status", "Read one named human-review state.", NamedInput),
    RootTool("execution_capabilities", "List sanitized execution capabilities for one compiled Effect operation.", ExecutionCapabilitiesInput),
    RootTool("execution_capability_bind", "Freeze one capability selected through a compiled Effect under a semantic artifact name.", ExecutionCapabilityBindInput),
    RootTool("execution_approval_request_create", "Create the local review for one named execution.", NamedInput),
    RootTool("execution_abandon", "Abandon one named unsubmitted execution.", NamedInput),
    RootTool("execution_cancel", "Request cancellation of one named submitted execution.", NamedInput),
    RootTool("execution_list", "List named executions in this scheduler instance.", ExecutionListInput),
    RootTool("execution_status", "Read one named execution state.", NamedInput),
    RootTool("execution_outputs", "Bind and list logical outputs from one named execution.", NamedInput),
    RootTool("execution_start", "Submit one named execution after its exact local review authorizes it.", NamedInput),
    RootTool("execution_sync", "Synchronize one named submitted execution.", NamedInput),
)


def root_tools_for_backend(worker_backend: str) -> tuple[RootTool, ...]:
    if worker_backend in {"local", "hardened"}:
        return ROOT_TOOLS
    raise ValueError("worker backend is invalid")


class RootToolFacade(
    RootInstanceRoutes,
    RootOperationRoutes,
    RootRunRoutes,
    RootApprovalRoutes,
    RootExecutionRoutes,
):
    def __init__(
        self,
        artifacts: ArtifactService,
        intake: SecureIntakeService,
        *,
        runs: RunService,
        approvals: ApprovalService,
        executions: ExecutionService,
        bindings: SchedulerBindingService,
        instance: str | None,
        session_key: str | None = None,
        creation_lock: threading.RLock | None = None,
        execution_bridge: ExecutionBridge | None = None,
        approval_base_url: str | None = None,
        operation_catalog: CompiledCatalog | None = None,
    ) -> None:
        self.artifacts = artifacts
        self.intake = intake
        self.runs = runs
        self.approvals = approvals
        self.executions = executions
        self.bindings = bindings
        self.instance = instance
        self.session_key = session_key
        self.execution_bridge = execution_bridge
        self.approval_base_url = approval_base_url
        self._operation_catalog = operation_catalog or compile_installed_catalog()
        self._create_lock = creation_lock or threading.RLock()

    def _bind(
        self,
        namespace: str,
        name: str,
        object_id: str,
        *,
        request_fingerprint: str | None = None,
    ) -> SchedulerBinding:
        return self.bindings.bind(
            instance=self._instance_id(),
            namespace=namespace,
            name=name,
            object_id=object_id,
            request_fingerprint=request_fingerprint,
        )

    def _resolve(self, namespace: str, name: str) -> str:
        return self.bindings.resolve(
            instance=self._instance_id(), namespace=namespace, name=name
        )

    def _resolve_input_artifact(
        self, name: str, *, allow_nonqualifying: bool = False
    ) -> str:
        try:
            artifact_id = self._resolve("artifact", name)
        except SchedulerNameNotFound:
            suffix = ".output"
            if not name.endswith(suffix):
                raise
            run_name = name[: -len(suffix)]
            run_id = self._resolve("run", run_name)
            status = self.runs.status(run_id)
            if status.output_ref is None:
                raise
            artifact_id = status.output_ref.artifact_id
        del allow_nonqualifying
        return artifact_id

    def _scheduler_signal_for_output(self, reference: Any) -> Any:
        return self.runs.signal_for_output(reference)

    def _is_exact_reviewer_output(self, reference: Any, **values: Any) -> bool:
        return self.runs.is_exact_reviewer_output(reference, **values)

    def _binding(self, namespace: str, name: str) -> SchedulerBinding:
        return self.bindings.get_binding(
            instance=self._instance_id(), namespace=namespace, name=name
        )

    def _optional(self, namespace: str, name: str) -> str | None:
        try:
            return self._resolve(namespace, name)
        except SchedulerNameNotFound:
            return None

    def _creation_target(
        self,
        namespace: str,
        requested_name: str,
        request_fingerprint: str,
        on_conflict: str,
    ) -> _CreationTarget:
        try:
            existing = self._binding(namespace, requested_name)
        except SchedulerNameNotFound:
            return _CreationTarget(requested_name, requested_name, 1, None)
        if existing.request_fingerprint == request_fingerprint:
            return _CreationTarget(
                existing.name,
                existing.logical_name,
                existing.revision,
                existing.object_id,
            )
        if on_conflict != "create_revision":
            detail = (
                "legacy binding has no verifiable request fingerprint"
                if existing.request_fingerprint is None
                else "semantic name already represents different immutable content"
            )
            raise SchedulerNameConflict(
                f"{namespace} name requires an explicit revision: "
                f"{requested_name} ({detail})"
            )
        logical_name = existing.logical_name
        matched = self.bindings.find_revision(
            instance=self._instance_id(),
            namespace=namespace,
            logical_name=logical_name,
            request_fingerprint=request_fingerprint,
        )
        if matched is not None:
            return _CreationTarget(
                matched.name,
                matched.logical_name,
                matched.revision,
                matched.object_id,
            )
        revision_name, revision = self.bindings.next_revision(
            instance=self._instance_id(),
            namespace=namespace,
            logical_name=logical_name,
        )
        return _CreationTarget(revision_name, logical_name, revision, None)

    def _bind_target(
        self,
        namespace: str,
        target: _CreationTarget,
        object_id: str,
        request_fingerprint: str,
    ) -> SchedulerBinding:
        return self.bindings.bind(
            instance=self._instance_id(),
            namespace=namespace,
            name=target.name,
            logical_name=target.logical_name,
            revision=target.revision,
            object_id=object_id,
            request_fingerprint=request_fingerprint,
        )

    def _instance_id(self) -> str:
        if self.session_key is not None:
            bound = self.bindings.session_instance(session_key=self.session_key)
            if bound is not None:
                self.bindings.require_active_instance(instance_id=bound)
                self.instance = bound
                return bound
            self.instance = None
            try:
                review = self._prepare_session_binding_review()
            except SchedulerInstanceNotFound as error:
                raise RootToolError(str(error)) from error
            rebound = self.bindings.session_instance(session_key=self.session_key)
            if rebound is not None:
                self.bindings.require_active_instance(instance_id=rebound)
                self.instance = rebound
                return rebound
            review_url = review.get("review_url")
            suffix = f" Review: {review_url}" if review_url else ""
            raise RootToolError(
                "this MCP session is not bound to a research instance; "
                f"local human confirmation is required.{suffix}"
            )
        if self.instance is None:
            raise RootToolError("no research instance is selected")
        return self.instance

    def _prepare_session_binding_review(
        self, *, preferred_name: str | None = None
    ) -> dict[str, Any]:
        if self.session_key is None:
            raise RootToolError(
                "session binding requires a transport-bound scheduler session"
            )
        with self._create_lock:
            request, candidates = self.bindings.prepare_session_binding_request(
                session_key=self.session_key,
                preferred_name=preferred_name,
            )
            if not self.approvals.has_request(request.approval_id):
                payload = canonical_json(
                    {
                        "schema_version": 1,
                        "authorization_effect": (
                            "把当前 MCP 进程独占绑定到用户选择的研究实例；"
                            "该实例原有进程绑定同时作废。"
                        ),
                        "candidates": [
                            {
                                "option_id": candidate.option_id,
                                "name": candidate.instance.name,
                                "title": candidate.instance.title,
                                "objective": candidate.instance.objective,
                                "state": candidate.instance.state,
                            }
                            for candidate in candidates
                        ],
                        "non_effects": [
                            "不创建新的研究实例",
                            "不批准任何科学结论",
                            "不授权或启动任何仿真",
                        ],
                    }
                )
                subject_ref = self.artifacts.register(
                    payload,
                    ArtifactRegistration(
                        artifact_id=f"art_{request.request_id}",
                        kind="research_session_binding_proposal",
                        schema_id="scidiscovery.session-binding-proposal.v1",
                        payload_schema_version=1,
                        media_type="application/json",
                        creator=self.intake.creator,
                        labels={"semantic_name": "research_session_binding"},
                        confidentiality="approval_only",
                    ),
                    idempotency_key=f"session-binding-subject:{request.request_id}",
                ).ref
                options = tuple(
                    ApprovalOption(
                        option_id=candidate.option_id,
                        label=f"进入 {candidate.instance.title}",
                        description=(
                            f"绑定到 {candidate.instance.name}，并撤销该实例的旧进程绑定。"
                        ),
                        requires_rationale=False,
                    )
                    for candidate in candidates
                ) + (
                    ApprovalOption(
                        option_id="cancel_binding",
                        label="暂不绑定",
                        description="保持当前 MCP 进程未绑定，不进入任何研究实例。",
                        requires_rationale=False,
                        terminal_state="cancelled_by_human",
                    ),
                )
                self.approvals.create_request(
                    approval_id=request.approval_id,
                    kind="research_session_binding",
                    subject_refs=(subject_ref,),
                    question="当前 MCP 进程要进入哪个研究实例？",
                    options=options,
                    requested_by=self.intake.creator,
                    idempotency_key=f"session-binding-approval:{request.request_id}",
                )

            approval = self.approvals.status(request.approval_id)
            if approval.decision_ref is not None and request.state == "pending":
                decision = HumanDecision.model_validate_json(
                    self.approvals.artifacts.read(approval.decision_ref), strict=True
                )
                request = self.bindings.apply_session_binding_decision(
                    approval_id=request.approval_id,
                    selected_option=decision.selected_option,
                )
                if request is None:
                    raise RootToolError("session-binding request disappeared")
            result: dict[str, Any] = {
                "binding_status": request.state,
                "candidate_names": [
                    candidate.instance.name for candidate in candidates
                ],
            }
            if approval.status == "pending" and self.approval_base_url is not None:
                result["review_url"] = self.approval_base_url.rstrip("/") + "/"
            if request.state == "activated" and request.instance_id is not None:
                self.instance = request.instance_id
                result["instance"] = self._instance_value(
                    self.bindings.get_instance(instance_id=request.instance_id)
                )
            return result

    def _persist_instance_selection(self) -> None:
        if self.session_key is not None:
            self.bindings.bind_session(
                session_key=self.session_key,
                instance_id=self._instance_id(),
            )

    @staticmethod
    def _binding_value(binding: SchedulerBinding) -> dict[str, Any]:
        return {
            "name": binding.name,
            "logical_name": binding.logical_name,
            "revision": binding.revision,
        }

    @staticmethod
    def _instance_value(value: Any) -> dict[str, Any]:
        return {
            "name": value.name,
            "title": value.title,
            "objective": value.objective,
            "state": value.state,
            "created_at": value.created_at,
            "closed_at": value.closed_at,
        }


class RootMCPRouter:
    def __init__(self, facade: RootToolFacade) -> None:
        self.facade = facade
        tools = root_tools_for_backend("local")
        self._ordered_tools = tools
        self._tools = {tool.name: tool for tool in tools}

    def list_tools(self) -> list[dict[str, Any]]:
        return [tool.schema() for tool in self._ordered_tools]

    def call_tool(self, name: str, arguments: dict[str, Any] | None) -> Any:
        try:
            tool = self._tools[name]
        except KeyError as error:
            raise RootToolError(f"unknown root tool: {name}") from error
        try:
            parsed = tool.input_model.model_validate(arguments or {}, strict=False)
        except ValidationError as error:
            raise RootToolError(f"invalid arguments for {name}: {error}") from error
        values = {field: getattr(parsed, field) for field in type(parsed).model_fields}
        return getattr(self.facade, name)(**values)


__all__ = [
    "ROOT_TOOLS",
    "RootMCPRouter",
    "RootTool",
    "RootToolError",
    "RootToolFacade",
    "root_tools_for_backend",
]
