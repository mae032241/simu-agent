"""Minimal Run lifecycle routes for the Root scheduler facade."""

from __future__ import annotations

from typing import Any

class RootRunRoutes:
    def run_list(self, *, state: str | None, limit: int) -> dict[str, Any]:
        if self.runs is None:
            return {"runs": []}
        items = []
        for binding in self.bindings.list(instance=self._instance_id(), namespace="run"):
            value = self.runs.status(binding.object_id)
            if state is not None and value.state != state:
                continue
            items.append(self._run_status_value(binding.name, value))
            if len(items) >= limit:
                break
        return {"runs": items}

    def run_status(self, *, name: str) -> dict[str, Any]:
        if self.runs is None:
            raise RuntimeError("minimal Run service is unavailable")
        return self._run_status_value(
            name, self.runs.status(self._resolve("run", name))
        )

    def run_record_failure(
        self,
        *,
        name: str,
        reason: str,
        expected_state: str,
        expected_last_activity_at: str | None,
        timed_out: bool,
    ) -> dict[str, Any]:
        if self.runs is None:
            raise RuntimeError("minimal Run service is unavailable")
        self.runs.record_failure(
            self._resolve("run", name),
            reason=reason,
            expected_state=expected_state,
            expected_last_activity_at=expected_last_activity_at,
            timed_out=timed_out,
        )
        return self.run_status(name=name)

    def _run_status_value(self, name: str, value: Any) -> dict[str, Any]:
        binding = self._binding("run", name)
        return {
            **self._binding_value(binding),
            "operation_id": value.operation_id,
            "agent_type": value.agent_type,
            "backend": value.backend_id,
            "state": value.state,
            "output_artifact_name": (
                value.output_binding_name if value.output_ref is not None else None
            ),
            "scheduler_signal": (
                value.signal.model_dump(mode="json") if value.signal is not None else None
            ),
            "reason": value.reason,
            "created_at": value.created_at,
            "started_at": value.started_at,
            "deadline_at": value.deadline_at,
            "completed_at": value.completed_at,
            "last_activity_at": value.last_activity_at,
            "candidate_accepted": value.accepted_candidate_digest is not None,
            "head_advance": (
                None
                if value.completion_receipt is None
                else value.completion_receipt.head_advance
            ),
            "recovery_available": value.recovery_draft is not None,
        }


__all__ = ["RootRunRoutes"]
