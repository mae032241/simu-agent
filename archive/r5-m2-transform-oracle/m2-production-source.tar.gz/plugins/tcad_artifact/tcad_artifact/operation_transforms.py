"""Operation components for the existing deterministic TCAD transforms."""

from __future__ import annotations

import json
from types import MappingProxyType
from typing import Any, Mapping

from scidiscovery.artifact_agent.schema.comparison import (
    RealizationSnapshot,
    StudyControlEquivalenceReport,
)
from scidiscovery.artifact_agent.schema.experiment import (
    ComparisonContract,
    ExperimentPortfolio,
)
from scidiscovery.operations.spec import (
    CallableComponent,
    CollectionSpec,
    ComponentRef,
    ComponentSpec,
    ExecutorRef,
    InputPortSpec,
    LimitsSpec,
    OperationDescription,
    OperationSpec,
    OutputPortSpec,
)

from .project_packager import (
    DeckProjectDraft,
    DeckReviewReport,
    ReviewedDeckPackage,
    RuntimeAttestation,
    TCADRuntimeManifest,
)
from .transform_adapter import (
    CONTROL_EQUIVALENCE_PROFILE,
    DECK_COMPARE_PROFILE,
    DECK_REVIEW_VALIDATION_PROFILE,
    REALIZATION_SNAPSHOT_PROFILE,
    REVIEWED_DECK_PACKAGE_PROFILE,
    RUNTIME_ATTESTATION_PROFILE,
    TCADProjectTransformAdapter,
)


def _schema(model: type[Any], schema_id: str) -> str:
    value = model.model_json_schema(mode="validation")
    value["$id"] = schema_id
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def _object_schema(schema_id: str) -> str:
    return json.dumps(
        {"$id": schema_id, "type": "object"},
        separators=(",", ":"),
        sort_keys=True,
    )


def _one(values: Mapping[str, tuple[bytes, ...]], name: str) -> bytes:
    items = values.get(name, ())
    if len(items) != 1:
        raise ValueError(f"TCAD transform input {name} must contain exactly one item")
    return items[0]


def _legacy(
    profile: str,
    inputs: Mapping[str, bytes],
) -> tuple[Any, ...]:
    return TCADProjectTransformAdapter().transform(profile=profile, inputs=inputs)


def compare(values: Mapping[str, tuple[bytes, ...]]) -> dict[str, tuple[bytes, ...]]:
    outputs = _legacy(
        DECK_COMPARE_PROFILE,
        {
            "base_project": _one(values, "base_project"),
            "revised_project": _one(values, "revised_project"),
        },
    )
    return {"project_diff": (outputs[0].content,)}


def validate_review(
    values: Mapping[str, tuple[bytes, ...]],
) -> dict[str, tuple[bytes, ...]]:
    outputs = _legacy(
        DECK_REVIEW_VALIDATION_PROFILE,
        {"project": _one(values, "project"), "review": _one(values, "review")},
    )
    return {"review_attestation": (outputs[0].content,)}


def package(values: Mapping[str, tuple[bytes, ...]]) -> dict[str, tuple[bytes, ...]]:
    inputs = {
        name: _one(values, name)
        for name in ("project", "review", "capability", "experiment_plan")
    }
    outputs = _legacy(REVIEWED_DECK_PACKAGE_PROFILE, inputs)
    return {"reviewed_package": (outputs[0].content,)}


def attest_runtime(
    values: Mapping[str, tuple[bytes, ...]],
) -> dict[str, tuple[bytes, ...]]:
    manifest_raw = _one(values, "runtime_manifest")
    manifest = TCADRuntimeManifest.model_validate_json(manifest_raw, strict=True)
    payloads = values.get("runtime_outputs", ())
    if len(payloads) != len(manifest.outputs):
        raise ValueError("runtime output collection differs from its exact manifest")
    inputs = {
        "reviewed_package": _one(values, "reviewed_package"),
        "runtime_manifest": manifest_raw,
        **{
            f"output__{record.name}": payload
            for record, payload in zip(manifest.outputs, payloads, strict=True)
        },
    }
    outputs = _legacy(RUNTIME_ATTESTATION_PROFILE, inputs)
    return {"runtime_attestation": (outputs[0].content,)}


def materialize_realization(
    values: Mapping[str, tuple[bytes, ...]],
) -> dict[str, tuple[bytes, ...]]:
    outputs = _legacy(
        REALIZATION_SNAPSHOT_PROFILE,
        {
            "comparison_contract": _one(values, "comparison_contract"),
            "reviewed_package": _one(values, "reviewed_package"),
            "case": _one(values, "case"),
        },
    )
    return {"realization_snapshot": (outputs[0].content,)}


def control_equivalence(
    values: Mapping[str, tuple[bytes, ...]],
) -> dict[str, tuple[bytes, ...]]:
    packages = values.get("reviewed_packages", ())
    if not packages:
        raise ValueError("control equivalence requires at least one reviewed package")
    legacy_inputs = {"experiment_plan": _one(values, "experiment_plan")}
    for index, raw in enumerate(packages):
        name = "reviewed_package" if len(packages) == 1 else f"reviewed_package__{index:04d}"
        legacy_inputs[name] = raw
    outputs = _legacy(CONTROL_EQUIVALENCE_PROFILE, legacy_inputs)
    report = tuple(item.content for item in outputs if item.label == "primary")
    snapshots = tuple(item.content for item in outputs if item.label.startswith("snapshot_"))
    audit = tuple(item.content for item in outputs if item.label == "audit")
    return {
        "control_equivalence": report,
        "realization_snapshots": snapshots,
        "control_audit": audit,
    }


def _has_parent(child: Any, parent: Any) -> bool:
    return parent.artifact.ref in child.artifact.parent_refs


def package_parentage(inputs: tuple[Any, ...], parameters: Mapping[str, Any]) -> bool:
    del parameters
    by_port = {item.port_name: item for item in inputs}
    review = by_port["review"]
    if not all(
        _has_parent(review, by_port[name])
        for name in ("project", "capability", "experiment_plan")
    ):
        return False
    return True


def runtime_parentage(inputs: tuple[Any, ...], parameters: Mapping[str, Any]) -> bool:
    del parameters
    by_port: dict[str, list[Any]] = {}
    for item in inputs:
        by_port.setdefault(item.port_name, []).append(item)
    package = by_port["reviewed_package"][0]
    manifest = by_port["runtime_manifest"][0]
    if not _has_parent(manifest, package):
        return False
    execution_parents = manifest.artifact.parent_refs
    return all(
        item.artifact.parent_refs == execution_parents
        for item in by_port.get("runtime_outputs", ())
    )


COMPARE_COMPONENT = CallableComponent("transform", compare)
REVIEW_VALIDATION_COMPONENT = CallableComponent("transform", validate_review)
PACKAGE_COMPONENT = CallableComponent("transform", package)
RUNTIME_ATTEST_COMPONENT = CallableComponent("transform", attest_runtime)
REALIZATION_COMPONENT = CallableComponent("transform", materialize_realization)
CONTROL_EQUIVALENCE_COMPONENT = CallableComponent("transform", control_equivalence)
PACKAGE_PARENTAGE_GUARD = CallableComponent("guard", package_parentage)
RUNTIME_PARENTAGE_GUARD = CallableComponent("guard", runtime_parentage)

PROJECT_DIFF_SCHEMA = _object_schema("tcad.deck-project-diff.v1")
REVIEW_ATTESTATION_SCHEMA = _object_schema("tcad.deck-review-attestation.v1")
REVIEWED_PACKAGE_SCHEMA = _schema(ReviewedDeckPackage, "tcad.reviewed-deck-package.v2")
COMPARISON_CONTRACT_SCHEMA = _schema(
    ComparisonContract, "scidiscovery.comparison-contract.v1"
)
CASE_BINDING_SCHEMA = _object_schema("tcad.realization-case-binding.v1")
REALIZATION_SCHEMA = _schema(RealizationSnapshot, "tcad.realization-snapshot.v1")
CONTROL_EQUIVALENCE_SCHEMA = _schema(
    StudyControlEquivalenceReport, "tcad.study-control-equivalence.v1"
)
CONTROL_AUDIT_SCHEMA = _object_schema("tcad.control-equivalence-audit.v1")
REVIEWED_PACKAGE_INPUT_SCHEMA = REVIEWED_PACKAGE_SCHEMA


def _ref(name: str) -> ComponentRef:
    return ComponentRef(name)


def _input(
    name: str,
    schema: str,
    resource: str,
    *,
    min_items: int = 1,
    max_items: int = 1,
    max_bytes: int = 32 * 1024 * 1024,
    usage: str = "claim_evidence",
    exposure: str = "full",
    media_types: tuple[str, ...] = ("application/json",),
) -> InputPortSpec:
    return InputPortSpec(
        name=name,
        description=f"Exact deterministic TCAD transform input: {name}.",
        schema=schema,
        media_types=media_types,
        codec=_ref("json_codec" if media_types == ("application/json",) else "opaque_codec"),
        schema_resource=_ref(resource),
        min_items=min_items,
        max_items=max_items,
        max_item_bytes=max_bytes,
        usage=usage,
        exposure=exposure,
    )


def _output(
    name: str,
    kind: str,
    schema: str,
    resource: str,
    *,
    min_items: int = 1,
    max_items: int = 1,
    max_bytes: int = 32 * 1024 * 1024,
    collection_bytes: int | None = None,
    payload_schema_version: int = 1,
) -> OutputPortSpec:
    return OutputPortSpec(
        name=name,
        description=f"Deterministic TCAD transform output: {name}.",
        schema=schema,
        media_types=("application/json",),
        codec=_ref("json_codec"),
        schema_resource=_ref(resource),
        min_items=min_items,
        max_items=max_items,
        max_item_bytes=max_bytes,
        kind=kind,
        payload_schema_version=payload_schema_version,
        collection=(
            CollectionSpec(max_total_bytes=collection_bytes)
            if collection_bytes is not None
            else None
        ),
        allowed_input_usages=("prior_signal",),
    )


def _operation(
    operation_id: str,
    component: str,
    purpose: str,
    inputs: tuple[InputPortSpec, ...],
    outputs: tuple[OutputPortSpec, ...],
    *,
    guards: tuple[ComponentRef, ...] = (),
    max_input_bytes: int = 256 * 1024 * 1024,
    max_output_bytes: int = 64 * 1024 * 1024,
    max_files: int = 8,
) -> OperationSpec:
    return OperationSpec(
        operation_id=operation_id,
        version="1",
        catalog_scope="support",
        description=OperationDescription(
            purpose=purpose,
            applies_when="All declared immutable inputs are available.",
            not_for="Open-ended scientific judgment or external execution.",
        ),
        executor=ExecutorRef(kind="transform", component=_ref(component)),
        inputs=inputs,
        outputs=outputs,
        consequence="scientific",
        guards=guards,
        limits=LimitsSpec(
            timeout_seconds=300,
            max_input_bytes=max_input_bytes,
            max_output_bytes=max_output_bytes,
            max_files=max_files,
        ),
    )


COMPONENT_SPECS = (
    ComponentSpec("deck_compare", "transform", "tcad_artifact.operation_transforms:COMPARE_COMPONENT"),
    ComponentSpec("review_validate", "transform", "tcad_artifact.operation_transforms:REVIEW_VALIDATION_COMPONENT"),
    ComponentSpec("reviewed_package", "transform", "tcad_artifact.operation_transforms:PACKAGE_COMPONENT"),
    ComponentSpec("runtime_attest", "transform", "tcad_artifact.operation_transforms:RUNTIME_ATTEST_COMPONENT"),
    ComponentSpec("realization_materialize", "transform", "tcad_artifact.operation_transforms:REALIZATION_COMPONENT"),
    ComponentSpec("control_equivalence", "transform", "tcad_artifact.operation_transforms:CONTROL_EQUIVALENCE_COMPONENT"),
    ComponentSpec("package_parentage", "guard", "tcad_artifact.operation_transforms:PACKAGE_PARENTAGE_GUARD"),
    ComponentSpec("runtime_parentage", "guard", "tcad_artifact.operation_transforms:RUNTIME_PARENTAGE_GUARD"),
    *tuple(
        ComponentSpec(name, "resource", f"tcad_artifact.operation_transforms:{attribute}")
        for name, attribute in (
            ("project_diff_schema", "PROJECT_DIFF_SCHEMA"),
            ("review_attestation_schema", "REVIEW_ATTESTATION_SCHEMA"),
            ("reviewed_package_schema", "REVIEWED_PACKAGE_SCHEMA"),
            ("comparison_contract_schema", "COMPARISON_CONTRACT_SCHEMA"),
            ("case_binding_schema", "CASE_BINDING_SCHEMA"),
            ("realization_schema", "REALIZATION_SCHEMA"),
            ("control_equivalence_schema", "CONTROL_EQUIVALENCE_SCHEMA"),
            ("control_audit_schema", "CONTROL_AUDIT_SCHEMA"),
        )
    ),
)


OPERATIONS = (
    _operation(
        DECK_COMPARE_PROFILE,
        "deck_compare",
        "Compare two exact TCAD project revisions deterministically.",
        (_input("base_project", "tcad.deck-project.v1", "project_schema"), _input("revised_project", "tcad.deck-project.v1", "project_schema")),
        (_output("project_diff", "tcad_project_diff", "tcad.deck-project-diff.v1", "project_diff_schema"),),
    ),
    _operation(
        DECK_REVIEW_VALIDATION_PROFILE,
        "review_validate",
        "Validate one independent TCAD review against its exact project.",
        (_input("project", "tcad.deck-project.v1", "project_schema"), _input("review", "tcad.deck-review-report.v1", "review_schema", usage="prior_signal")),
        (_output("review_attestation", "tcad_deck_review_attestation", "tcad.deck-review-attestation.v1", "review_attestation_schema"),),
    ),
    _operation(
        REVIEWED_DECK_PACKAGE_PROFILE,
        "reviewed_package",
        "Package one qualified reviewed TCAD project for controlled execution.",
        (
            _input("project", "tcad.deck-project.v1", "project_schema"),
            _input("review", "tcad.deck-review-report.v1", "review_schema", usage="prior_signal"),
            _input("capability", "tcad.solver-capability.v2", "capability_schema", usage="prior_signal"),
            _input("experiment_plan", "scidiscovery.experiment-portfolio.v1", "experiment_schema"),
        ),
        (_output(
            "reviewed_package",
            "packaged_project",
            "tcad.reviewed-deck-package.v2",
            "reviewed_package_schema",
            max_bytes=64 * 1024 * 1024,
            payload_schema_version=2,
        ),),
        guards=(_ref("package_parentage"),),
    ),
    _operation(
        RUNTIME_ATTESTATION_PROFILE,
        "runtime_attest",
        "Attest raw execution outputs against one exact reviewed TCAD package.",
        (
            _input("reviewed_package", "tcad.reviewed-deck-package.v2", "reviewed_package_schema", usage="prior_signal", max_bytes=64 * 1024 * 1024),
            _input(
                "runtime_manifest",
                "opaque",
                "opaque_schema",
                usage="prior_signal",
                media_types=("application/json",),
            ),
            _input(
                "runtime_outputs",
                "opaque",
                "opaque_schema",
                min_items=0,
                max_items=4096,
                max_bytes=256 * 1024 * 1024,
                usage="evidence_inventory",
                media_types=(
                    "application/octet-stream",
                    "application/x-synopsys-plx",
                    "application/json",
                    "text/plain",
                    "text/csv",
                    "image/png",
                ),
            ),
        ),
        (_output("runtime_attestation", "runtime_attestation", "tcad.runtime-attestation.v1", "runtime_attestation_schema"),),
        guards=(_ref("runtime_parentage"),),
        max_input_bytes=512 * 1024 * 1024,
    ),
    _operation(
        REALIZATION_SNAPSHOT_PROFILE,
        "realization_materialize",
        "Materialize one exact TCAD case realization from a reviewed package.",
        (
            _input("comparison_contract", "scidiscovery.comparison-contract.v1", "comparison_contract_schema"),
            _input("reviewed_package", "tcad.reviewed-deck-package.v2", "reviewed_package_schema", usage="prior_signal", max_bytes=64 * 1024 * 1024),
            _input("case", "tcad.realization-case-binding.v1", "case_binding_schema", usage="prior_signal"),
        ),
        (_output("realization_snapshot", "realization_snapshot", "tcad.realization-snapshot.v1", "realization_schema"),),
    ),
    _operation(
        CONTROL_EQUIVALENCE_PROFILE,
        "control_equivalence",
        "Evaluate study controls over one or more reviewed TCAD packages.",
        (
            _input("experiment_plan", "scidiscovery.experiment-portfolio.v1", "experiment_schema"),
            _input("reviewed_packages", "tcad.reviewed-deck-package.v2", "reviewed_package_schema", min_items=1, max_items=4096, max_bytes=64 * 1024 * 1024, usage="prior_signal"),
        ),
        (
            _output("control_equivalence", "control_equivalence_report", "tcad.study-control-equivalence.v1", "control_equivalence_schema", max_bytes=16 * 1024 * 1024),
            _output("realization_snapshots", "realization_snapshot", "tcad.realization-snapshot.v1", "realization_schema", min_items=0, max_items=4096, max_bytes=1024 * 1024, collection_bytes=256 * 1024 * 1024),
            _output("control_audit", "control_equivalence_audit", "tcad.control-equivalence-audit.v1", "control_audit_schema", max_bytes=4 * 1024 * 1024),
        ),
        max_input_bytes=512 * 1024 * 1024,
        max_output_bytes=276 * 1024 * 1024,
        max_files=4098,
    ),
)


__all__ = ["COMPONENT_SPECS", "OPERATIONS"]
