"""Single TCAD plugin declaration for Agent operations and their narrow parts."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable

from pydantic import BaseModel, ConfigDict, Field

from scidiscovery.artifact_agent.schema.cognitive import EvidenceAudit
from scidiscovery.artifact_agent.schema.common import canonical_json
from .device_parameters import (
    DeviceParameterCoverageReport,
    DeviceParameterRequirementSet,
    DeviceParameterSet,
    EvidenceSourceCatalog,
    ParameterUncertaintyProjection,
)
from scidiscovery.artifact_agent.schema.experiment import ExperimentPortfolio
from scidiscovery.artifact_agent.schema.execution import ExecutionRequest
from scidiscovery.artifact_agent.schema.research_cycle import ScientificReview
from scidiscovery.artifact_agent.schema.scientific_foundation import ScientificFoundation
from scidiscovery.operations.spec import (
    PLUGIN_PROTOCOL_VERSION,
    ApprovalContract,
    ApprovalOption,
    CallableComponent,
    ComponentRef,
    ComponentSpec,
    ExecutorRef,
    InputPortSpec,
    LimitsSpec,
    NativeToolPolicy,
    OperationDescription,
    OperationSpec,
    OutputPortSpec,
    PluginDefinition,
    PluginDependency,
    ReviewSpec,
    WorkspaceContract,
)
from scidiscovery.operations.tooling import WorkerToolDefinition
from scidiscovery.artifact_agent.operation_tool_context import OperationToolContext

from .execution_control import SolverCapabilitySnapshot
from .debug_contract import TCADDebugError
from .project_packager import (
    DeckProjectDraft,
    DeckReviewReport,
    RuntimeAttestation,
    validate_deck_author_task_output,
    validate_deck_project_output,
    validate_deck_review_report,
    validate_deck_review_task_output,
)
from .operation_transforms import COMPONENT_SPECS as TRANSFORM_COMPONENT_SPECS
from .operation_transforms import OPERATIONS as TRANSFORM_OPERATIONS
from .parameter_operations import COMPONENT_SPECS as PARAMETER_COMPONENT_SPECS
from .parameter_operations import OPERATIONS as PARAMETER_OPERATIONS
from .curve_operations import COMPONENT_SPECS as CURVE_COMPONENT_SPECS
from .curve_operations import OPERATIONS as CURVE_OPERATIONS


def _schema(model: type[BaseModel], schema_id: str) -> str:
    value = model.model_json_schema(mode="validation")
    value["$id"] = schema_id
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def _json_codec(raw: bytes) -> bytes:
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ValueError("TCAD schema-bound JSON must be an object")
    return canonical_json(value)


def _opaque_codec(raw: bytes) -> bytes:
    return raw


def _payload_validator(function: Callable[[dict[str, object]], Any]) -> Callable[[bytes], None]:
    def validate(raw: bytes) -> None:
        value = json.loads(raw)
        if not isinstance(value, dict):
            raise ValueError("TCAD payload must be an object")
        function(value)

    return validate


def _author_context(
    payload: dict[str, object], sources: dict[str, bytes], handoff: dict[str, object]
) -> None:
    _validate_parameter_uncertainty(sources)
    validate_deck_author_task_output(payload, sources, handoff)


def _runtime_author_context(
    payload: dict[str, object], sources: dict[str, bytes], handoff: dict[str, object]
) -> None:
    attestation = RuntimeAttestation.model_validate_json(
        sources["runtime_attestation"], strict=True
    )
    if attestation.verdict != "fail":
        raise ValueError("runtime-failure revision requires a failing attestation")
    _validate_parameter_uncertainty(sources)
    validate_deck_author_task_output(payload, sources, handoff)


def _review_context(
    payload: dict[str, object], sources: dict[str, bytes], handoff: dict[str, object]
) -> None:
    _validate_parameter_uncertainty(sources)
    validate_deck_review_task_output(payload, sources, handoff)


def _author_agent() -> None:
    return None


def _reviewer_agent() -> None:
    return None


class TCADDebugInput(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)
    run_name: str = Field(min_length=1, max_length=128, pattern=r"^[A-Za-z0-9][A-Za-z0-9_.-]*$")
    mode: str = Field(pattern=r"^(preflight|smoke|initialization)$")


def _validate_parameter_uncertainty(sources: dict[str, bytes]) -> None:
    raw = sources.get("parameter_uncertainty")
    if raw is None:
        return
    projection = ParameterUncertaintyProjection.model_validate_json(raw, strict=True)
    if projection.status != "ready":
        raise ValueError("blocking-unbounded parameters cannot enter TCAD authoring")


_PARAMETER_COHORT_PORTS = (
    "scientific_foundation",
    "parameter_requirements",
    "device_parameters",
    "source_catalog",
    "parameter_coverage",
    "parameter_audit",
    "parameter_uncertainty",
)


def _parameter_cohort_guard(inputs: tuple[Any, ...], parameters: dict[str, object]) -> bool:
    del parameters
    by_port = {item.port_name: item.artifact for item in inputs}
    present = set(_PARAMETER_COHORT_PORTS).intersection(by_port)
    if not present:
        return True
    if present != set(_PARAMETER_COHORT_PORTS):
        return True
    reviewed = {
        by_port[name].ref
        for name in _PARAMETER_COHORT_PORTS
        if name not in {
            "scientific_foundation",
            "parameter_audit",
            "parameter_uncertainty",
        }
    }
    if not reviewed.issubset(set(by_port["parameter_audit"].parent_refs)):
        return False
    if by_port["parameter_audit"].ref not in set(
        by_port["scientific_foundation"].parent_refs
    ):
        return False
    expected_projection_parents = (
        by_port["parameter_requirements"].ref,
        by_port["device_parameters"].ref,
        by_port["parameter_coverage"].ref,
    )
    return by_port["parameter_uncertainty"].parent_refs == expected_projection_parents


def _debug_tool(
    request: BaseModel, context: OperationToolContext
) -> dict[str, object]:
    if not isinstance(request, TCADDebugInput):
        raise ValueError("TCAD debug request has the wrong type")
    service = context.require_service("tcad.development_debug")
    run = getattr(service, "run", None)
    if not callable(run):
        raise RuntimeError("TCAD development debug service has no run method")
    try:
        return run(context, run_name=request.run_name, mode=request.mode)
    except TCADDebugError as error:
        return {
            "state": "rejected",
            "diagnostic": str(error)[:4096],
            "scientific_claim_admissible": False,
        }


_ROLE_ROOT = Path(__file__).with_name("roles")
AUTHOR_PROMPT = "\n\n".join(
    (_ROLE_ROOT / name).read_text(encoding="utf-8")
    for name in (
        "tcad_deck_author.md",
        "sentaurus_author_contract.md",
        "sentaurus_sdevice_contract.md",
    )
)
REVIEWER_PROMPT = "\n\n".join(
    (_ROLE_ROOT / name).read_text(encoding="utf-8")
    for name in (
        "tcad_deck_reviewer.md",
        "sentaurus_review_contract.md",
        "sentaurus_sdevice_contract.md",
    )
)
SEMANTIC_CONTRACT = json.dumps(
    {
        "rules": (
            "The payload must satisfy the exact TCAD schema and validator.",
            "Every contextual claim must remain consistent with the explicitly bound inputs.",
            "A completed author result still requires the registered independent review.",
        )
    },
    separators=(",", ":"),
    sort_keys=True,
)
OPAQUE_SCHEMA = '{"$id":"opaque","type":["string","object","array"]}'
CHANGE_REQUEST_SCHEMA = _schema(DeckReviewReport, "tcad.deck-review-report.v1")


AUTHOR_COMPONENT = CallableComponent("agent", _author_agent)
REVIEWER_COMPONENT = CallableComponent("agent", _reviewer_agent)
JSON_CODEC_COMPONENT = CallableComponent("codec", _json_codec)
OPAQUE_CODEC_COMPONENT = CallableComponent("codec", _opaque_codec)
PROJECT_VALIDATOR_COMPONENT = CallableComponent(
    "validator", _payload_validator(validate_deck_project_output)
)
AUTHOR_CONTEXT_COMPONENT = CallableComponent("validator", _author_context)
RUNTIME_AUTHOR_CONTEXT_COMPONENT = CallableComponent(
    "validator", _runtime_author_context
)
REVIEW_VALIDATOR_COMPONENT = CallableComponent(
    "validator", _payload_validator(validate_deck_review_report)
)
REVIEW_CONTEXT_COMPONENT = CallableComponent("validator", _review_context)
DEBUG_TOOL = WorkerToolDefinition(
    name="worker_tcad_debug_run",
    description=(
        "Submit or poll one bounded control-selected TCAD development diagnostic; "
        "the result is never scientific evidence."
    ),
    input_model=TCADDebugInput,
    capability="tcad.development_debug",
    contextual_handler=_debug_tool,
    required_services=("tcad.development_debug",),
)
PARAMETER_COHORT_GUARD = CallableComponent("guard", _parameter_cohort_guard)
TCAD_WORKSPACE = WorkspaceContract()


def _ref(name: str, plugin_id: str | None = None) -> ComponentRef:
    return ComponentRef(name, plugin_id=plugin_id)


def _input(
    name: str,
    schema_id: str,
    schema_resource: str,
    *,
    usage: str = "claim_evidence",
    exposure: str = "full",
    media_types: tuple[str, ...] = ("application/json",),
    max_bytes: int = 16 * 1024 * 1024,
    min_items: int = 1,
    cohort_id: str | None = None,
    approval_kind: str | None = None,
    accepted_approval_options: tuple[str, ...] = (),
    accepted_approval_operations: tuple[str, ...] = (),
    schema_plugin: str | None = None,
) -> InputPortSpec:
    return InputPortSpec(
        name=name,
        description=f"Exact TCAD input: {name}.",
        schema=schema_id,
        media_types=media_types,
        codec=_ref("json_codec" if media_types == ("application/json",) else "opaque_codec"),
        schema_resource=_ref(schema_resource, schema_plugin),
        usage=usage,
        exposure=exposure,
        min_items=min_items,
        max_item_bytes=max_bytes,
        cohort_id=cohort_id,
        approval_kind=approval_kind,
        accepted_approval_options=accepted_approval_options,
        accepted_approval_operations=accepted_approval_operations,
    )


def _output(
    name: str,
    kind: str,
    schema_id: str,
    schema_resource: str,
    validator: str,
    context_validator: str,
    context_sources: tuple[str, ...],
    *,
    max_bytes: int,
    allowed_input_usages: tuple[str, ...] = ("claim_evidence",),
) -> OutputPortSpec:
    return OutputPortSpec(
        name=name,
        description=f"Validated TCAD output: {name}.",
        schema=schema_id,
        media_types=("application/json",),
        codec=_ref("json_codec"),
        schema_resource=_ref(schema_resource),
        kind=kind,
        validator=_ref(validator),
        semantic_contract=_ref("semantic_contract"),
        context_validator=_ref(context_validator),
        context_sources=context_sources,
        max_item_bytes=max_bytes,
        allowed_input_usages=allowed_input_usages,
    )


_FILE_TOOLS = (
    _ref("file_write_begin_tool", "builtin"),
    _ref("file_write_chunk_tool", "builtin"),
    _ref("file_write_commit_tool", "builtin"),
)
_AUTHOR_TOOLS = _FILE_TOOLS + (
    _ref("file_apply_patch_tool", "general_science"),
    _ref("file_json_patch_tool"),
    _ref("file_delete_tool"),
    _ref("file_move_tool"),
    _ref("debug_tool"),
)
_REVIEW_TOOLS = _FILE_TOOLS + (
    _ref("file_apply_patch_tool", "general_science"),
)


def _author_operation(
    operation_id: str,
    description: OperationDescription,
    inputs: tuple[InputPortSpec, ...],
    context_validator: str,
) -> OperationSpec:
    names = tuple(item.name for item in inputs)
    return OperationSpec(
        operation_id=operation_id,
        version="1",
        catalog_scope="public",
        description=description,
        executor=ExecutorRef(
            kind="agent",
            component=_ref("author_agent"),
            workspace=_ref("deck_workspace"),
            tools=_AUTHOR_TOOLS,
            prompt=_ref("author_prompt"),
            model="gpt-5.4",
            native_tools=NativeToolPolicy(shell="inherited_prototype"),
        ),
        inputs=inputs,
        outputs=(
            _output(
                "project",
                "tcad_project",
                "tcad.deck-project.v1",
                "project_schema",
                "project_validator",
                context_validator,
                names,
                max_bytes=512 * 1024,
                allowed_input_usages=("claim_evidence", "revision_base"),
            ),
        ),
        consequence="scientific",
        review=ReviewSpec(
            reviewer_operation="tcad.deck.review.v1",
            reviewer_input_port="project",
            subject_outputs=("project",),
        ),
        guards=(_ref("parameter_cohort_guard"),),
        limits=LimitsSpec(
            timeout_seconds=1200,
            max_input_bytes=64 * 1024 * 1024,
            max_output_bytes=512 * 1024,
            max_files=1,
            max_attempts=2,
        ),
    )


_PARAMETER_APPROVAL_PROVIDERS = (
    "science.parameters.qualify.pass.v1",
    "science.parameters.qualify.exception.v1",
)


INITIAL_INPUTS = (
    _input("execution_capability", "tcad.solver-capability.v2", "capability_schema", max_bytes=64 * 1024),
    _input("experiment_plan", "scidiscovery.experiment-portfolio.v1", "experiment_schema", max_bytes=2 * 1024 * 1024),
    _input("curve_contract", "scidiscovery.curve-experiment-contract.v1", "curve_contract_schema", schema_plugin="curve_score", usage="prior_signal", max_bytes=2 * 1024 * 1024, min_items=0),
    _input("experiment_review", "scidiscovery.scientific-review.v1", "scientific_review_schema", usage="prior_signal", exposure="handoff_only", max_bytes=512 * 1024, min_items=0),
    _input("curve_contract_review", "scidiscovery.scientific-review.v1", "scientific_review_schema", usage="prior_signal", exposure="handoff_only", max_bytes=512 * 1024, min_items=0),
    _input("scientific_foundation", "scidiscovery.scientific-foundation.v1", "foundation_schema", exposure="on_demand", max_bytes=1024 * 1024, min_items=0, cohort_id="approved_parameters", approval_kind="scientific_foundation", accepted_approval_options=("approve", "approve_with_exception"), accepted_approval_operations=_PARAMETER_APPROVAL_PROVIDERS),
    _input("parameter_requirements", "scidiscovery.device-parameter-requirements.v1", "parameter_requirements_schema", exposure="on_demand", max_bytes=2 * 1024 * 1024, min_items=0, cohort_id="approved_parameters", approval_kind="scientific_foundation", accepted_approval_options=("approve", "approve_with_exception"), accepted_approval_operations=_PARAMETER_APPROVAL_PROVIDERS),
    _input("device_parameters", "scidiscovery.device-parameter-set.v1", "device_parameters_schema", max_bytes=2 * 1024 * 1024, min_items=0, cohort_id="approved_parameters", approval_kind="scientific_foundation", accepted_approval_options=("approve", "approve_with_exception"), accepted_approval_operations=_PARAMETER_APPROVAL_PROVIDERS),
    _input("source_catalog", "scidiscovery.evidence-source-catalog.v1", "source_catalog_schema", exposure="on_demand", max_bytes=1024 * 1024, min_items=0, cohort_id="approved_parameters", approval_kind="scientific_foundation", accepted_approval_options=("approve", "approve_with_exception"), accepted_approval_operations=_PARAMETER_APPROVAL_PROVIDERS),
    _input("parameter_coverage", "scidiscovery.device-parameter-coverage.v1", "parameter_coverage_schema", usage="prior_signal", max_bytes=2 * 1024 * 1024, min_items=0, cohort_id="approved_parameters", approval_kind="scientific_foundation", accepted_approval_options=("approve", "approve_with_exception"), accepted_approval_operations=_PARAMETER_APPROVAL_PROVIDERS),
    _input("parameter_audit", "scidiscovery.evidence-audit.v1", "evidence_audit_schema", usage="prior_signal", exposure="on_demand", max_bytes=512 * 1024, min_items=0, cohort_id="approved_parameters", approval_kind="scientific_foundation", accepted_approval_options=("approve", "approve_with_exception"), accepted_approval_operations=_PARAMETER_APPROVAL_PROVIDERS),
    _input("parameter_uncertainty", "scidiscovery.parameter-uncertainty.v1", "parameter_uncertainty_schema", usage="prior_signal", max_bytes=512 * 1024, min_items=0, cohort_id="approved_parameters"),
)
REVISION_INPUTS = (
    _input("prior_project", "tcad.deck-project.v1", "project_schema", usage="revision_base"),
    _input("change_request", "tcad.deck-review-report.v1", "review_schema", usage="change_request", max_bytes=512 * 1024),
    *INITIAL_INPUTS,
)
RUNTIME_INPUTS = (
    _input("prior_project", "tcad.deck-project.v1", "project_schema", usage="revision_base"),
    _input("runtime_attestation", "tcad.runtime-attestation.v1", "runtime_attestation_schema", usage="prior_signal", max_bytes=512 * 1024),
    _input("solver_log", "opaque", "opaque_schema", usage="prior_signal", media_types=("text/plain",), max_bytes=32 * 1024 * 1024),
    *INITIAL_INPUTS,
)
REVIEW_INPUTS = (
    _input("project", "tcad.deck-project.v1", "project_schema"),
    *INITIAL_INPUTS,
)


PLUGIN = PluginDefinition(
    plugin_id="tcad_artifact",
    version="0.2.0",
    protocol_version=PLUGIN_PROTOCOL_VERSION,
    dependencies=(
        PluginDependency("builtin", "0.1.0"),
        PluginDependency("general_science", "0.1.0"),
        PluginDependency("curve_score", "0.2.0"),
    ),
    configuration_schema=_ref("runtime_configuration_schema"),
    runtime_factory=_ref("runtime_factory"),
    components=(
        ComponentSpec("author_agent", "agent", "tcad_artifact.plugin:AUTHOR_COMPONENT"),
        ComponentSpec("reviewer_agent", "agent", "tcad_artifact.plugin:REVIEWER_COMPONENT"),
        ComponentSpec("json_codec", "codec", "tcad_artifact.plugin:JSON_CODEC_COMPONENT"),
        ComponentSpec("opaque_codec", "codec", "tcad_artifact.plugin:OPAQUE_CODEC_COMPONENT"),
        ComponentSpec("semantic_contract", "resource", "tcad_artifact.plugin:SEMANTIC_CONTRACT"),
        ComponentSpec("author_prompt", "resource", "tcad_artifact.plugin:AUTHOR_PROMPT"),
        ComponentSpec("reviewer_prompt", "resource", "tcad_artifact.plugin:REVIEWER_PROMPT"),
        ComponentSpec("project_schema", "resource", "tcad_artifact.plugin:PROJECT_SCHEMA"),
        ComponentSpec("review_schema", "resource", "tcad_artifact.plugin:REVIEW_SCHEMA"),
        ComponentSpec("capability_schema", "resource", "tcad_artifact.plugin:CAPABILITY_SCHEMA"),
        ComponentSpec("experiment_schema", "resource", "tcad_artifact.plugin:EXPERIMENT_SCHEMA"),
        ComponentSpec("runtime_attestation_schema", "resource", "tcad_artifact.plugin:RUNTIME_ATTESTATION_SCHEMA"),
        ComponentSpec("scientific_review_schema", "resource", "tcad_artifact.plugin:SCIENTIFIC_REVIEW_SCHEMA"),
        ComponentSpec("foundation_schema", "resource", "tcad_artifact.plugin:FOUNDATION_SCHEMA"),
        ComponentSpec("parameter_requirements_schema", "resource", "tcad_artifact.plugin:PARAMETER_REQUIREMENTS_SCHEMA"),
        ComponentSpec("device_parameters_schema", "resource", "tcad_artifact.plugin:DEVICE_PARAMETERS_SCHEMA"),
        ComponentSpec("source_catalog_schema", "resource", "tcad_artifact.plugin:SOURCE_CATALOG_SCHEMA"),
        ComponentSpec("parameter_coverage_schema", "resource", "tcad_artifact.plugin:PARAMETER_COVERAGE_SCHEMA"),
        ComponentSpec("evidence_audit_schema", "resource", "tcad_artifact.plugin:EVIDENCE_AUDIT_SCHEMA"),
        ComponentSpec("parameter_uncertainty_schema", "resource", "tcad_artifact.plugin:PARAMETER_UNCERTAINTY_SCHEMA"),
        ComponentSpec("opaque_schema", "resource", "tcad_artifact.plugin:OPAQUE_SCHEMA"),
        ComponentSpec("project_validator", "validator", "tcad_artifact.plugin:PROJECT_VALIDATOR_COMPONENT", resources=(_ref("semantic_contract"),)),
        ComponentSpec("author_context", "validator", "tcad_artifact.plugin:AUTHOR_CONTEXT_COMPONENT", resources=(_ref("semantic_contract"),)),
        ComponentSpec("runtime_author_context", "validator", "tcad_artifact.plugin:RUNTIME_AUTHOR_CONTEXT_COMPONENT", resources=(_ref("semantic_contract"),)),
        ComponentSpec("review_validator", "validator", "tcad_artifact.plugin:REVIEW_VALIDATOR_COMPONENT", resources=(_ref("semantic_contract"),)),
        ComponentSpec("review_context", "validator", "tcad_artifact.plugin:REVIEW_CONTEXT_COMPONENT", resources=(_ref("semantic_contract"),)),
        ComponentSpec("parameter_cohort_guard", "guard", "tcad_artifact.plugin:PARAMETER_COHORT_GUARD", configuration_identity="tcad.approved-parameter-cohort.v1"),
        ComponentSpec("workspace_materializer", "workspace_materializer", "tcad_artifact.operation_workspace:MATERIALIZER_COMPONENT", configuration_identity="tcad.workspace-materializer.v2"),
        ComponentSpec("workspace_file_policy", "workspace_file_policy", "tcad_artifact.operation_workspace:FILE_POLICY_COMPONENT", configuration_identity="tcad.workspace-file-policy.v1"),
        ComponentSpec("workspace_finalizer", "workspace_finalizer", "tcad_artifact.operation_workspace:FINALIZER_COMPONENT", configuration_identity="tcad.workspace-finalizer.v2"),
        ComponentSpec("workspace_snapshotter", "workspace_snapshotter", "tcad_artifact.operation_workspace:SNAPSHOTTER_COMPONENT", configuration_identity="tcad.workspace-snapshotter.v2"),
        ComponentSpec(
            "deck_workspace",
            "workspace",
            "tcad_artifact.plugin:TCAD_WORKSPACE",
            resources=(
                _ref("workspace_materializer"),
                _ref("workspace_file_policy"),
                _ref("workspace_finalizer"),
                _ref("workspace_snapshotter"),
            ),
            configuration_identity="tcad.deck-workspace.v2",
        ),
        ComponentSpec(
            "review_workspace",
            "workspace",
            "tcad_artifact.plugin:TCAD_WORKSPACE",
            resources=(_ref("workspace_materializer"),),
            configuration_identity="tcad.deck-review-workspace.v2",
        ),
        ComponentSpec("file_json_patch_tool", "worker_tool", "scidiscovery.artifact_agent.interfaces.mcp_worker_protocol:FILE_JSON_PATCH_TOOL"),
        ComponentSpec("file_delete_tool", "worker_tool", "scidiscovery.artifact_agent.interfaces.mcp_worker_protocol:FILE_DELETE_TOOL"),
        ComponentSpec("file_move_tool", "worker_tool", "scidiscovery.artifact_agent.interfaces.mcp_worker_protocol:FILE_MOVE_TOOL"),
        ComponentSpec("debug_tool", "worker_tool", "tcad_artifact.plugin:DEBUG_TOOL", configuration_identity="tcad.debug-tool.v2:service=tcad.development_debug"),
        ComponentSpec("runtime_configuration_schema", "resource", "tcad_artifact.runtime_plugin:CONFIGURATION_SCHEMA"),
        ComponentSpec("runtime_factory", "runtime_factory", "tcad_artifact.runtime_plugin:RUNTIME_FACTORY", configuration_identity="tcad.runtime-factory.v3:run-local-tool-service"),
        ComponentSpec("study_execute", "effect", "tcad_artifact.runtime_plugin:EXECUTE_EFFECT", configuration_identity="tcad.execution-adapter:tcad:reviewed-deck-package.v2"),
        ComponentSpec("execution_projector", "projector", "tcad_artifact.runtime_plugin:EXECUTION_PROJECTOR"),
        ComponentSpec("execution_request_schema", "resource", "tcad_artifact.plugin:EXECUTION_REQUEST_SCHEMA"),
        *PARAMETER_COMPONENT_SPECS,
        *TRANSFORM_COMPONENT_SPECS,
        *CURVE_COMPONENT_SPECS,
    ),
    operations=(
        *PARAMETER_OPERATIONS,
        *CURVE_OPERATIONS,
        _author_operation(
            "tcad.deck.author.initial.v1",
            OperationDescription(
                purpose="Author one new TCAD solver project from an exact experiment plan.",
                applies_when="A reviewed plan and solver capability are available.",
                not_for="Postprocessing, scientific diagnosis, or external execution.",
            ),
            INITIAL_INPUTS,
            "author_context",
        ),
        _author_operation(
            "tcad.deck.author.revise.v1",
            OperationDescription(
                purpose="Apply one bounded independently requested TCAD source revision.",
                applies_when="One exact prior project and review request are available.",
                not_for="Redesigning the scientific experiment.",
            ),
            REVISION_INPUTS,
            "author_context",
        ),
        _author_operation(
            "tcad.deck.author.runtime-failure.v1",
            OperationDescription(
                purpose="Correct one concrete TCAD runtime failure without changing the study.",
                applies_when="A failing runtime attestation and exact solver log are available.",
                not_for="Hypothesis changes or broad deck redesign.",
            ),
            RUNTIME_INPUTS,
            "runtime_author_context",
        ),
        OperationSpec(
            operation_id="tcad.deck.review.v1",
            version="1",
            catalog_scope="public",
            description=OperationDescription(
                purpose="Independently review an exact TCAD project for physical and code fidelity.",
                applies_when="A complete author project, plan, and capability are available.",
                not_for="Editing the project or running a solver.",
            ),
            executor=ExecutorRef(
                kind="agent",
                component=_ref("reviewer_agent"),
                workspace=_ref("review_workspace"),
                tools=_REVIEW_TOOLS,
                prompt=_ref("reviewer_prompt"),
                model="gpt-5.4",
                native_tools=NativeToolPolicy(shell="inherited_prototype"),
            ),
            inputs=REVIEW_INPUTS,
            outputs=(
                _output(
                    "review",
                    "tcad_project_review",
                    "tcad.deck-review-report.v1",
                    "review_schema",
                    "review_validator",
                    "review_context",
                    tuple(item.name for item in REVIEW_INPUTS),
                    max_bytes=128 * 1024,
                    allowed_input_usages=("change_request", "prior_signal"),
                ),
            ),
            consequence="scientific",
            guards=(_ref("parameter_cohort_guard"),),
            limits=LimitsSpec(
                timeout_seconds=600,
                max_input_bytes=32 * 1024 * 1024,
                max_output_bytes=128 * 1024,
                max_files=1,
            ),
        ),
        *TRANSFORM_OPERATIONS,
        OperationSpec(
            operation_id="tcad.study.execute",
            version="1",
            catalog_scope="public",
            description=OperationDescription(
                purpose="Create one controlled execution request for an exact reviewed TCAD package.",
                applies_when="A packaged project and configured TCAD runtime are available.",
                not_for="Development debugging, unreviewed projects, or scientific interpretation.",
            ),
            executor=ExecutorRef(kind="effect", component=_ref("study_execute")),
            inputs=(
                _input(
                    "reviewed_package",
                    "tcad.reviewed-deck-package.v2",
                    "reviewed_package_schema",
                    usage="prior_signal",
                    max_bytes=64 * 1024 * 1024,
                ),
            ),
            outputs=(
                OutputPortSpec(
                    name="execution_request",
                    description="Controlled request for one exact TCAD execution.",
                    schema="scidiscovery.execution-request",
                    media_types=("application/json",),
                    codec=_ref("json_codec"),
                    schema_resource=_ref("execution_request_schema"),
                    kind="execution_request",
                    max_item_bytes=64 * 1024,
                    allowed_input_usages=("prior_signal",),
                ),
            ),
            consequence="external",
            review=ReviewSpec(
                approval=ApprovalContract(
                    subject_ports=("execution_request", "reviewed_package"),
                    question="是否授权执行这个已审查的 TCAD 工程？",
                    options=(
                        ApprovalOption("授权执行", "accept"),
                        ApprovalOption("拒绝执行", "reject"),
                    ),
                    projector=_ref("execution_projector"),
                )
            ),
            limits=LimitsSpec(
                timeout_seconds=300,
                max_input_bytes=64 * 1024 * 1024,
                max_output_bytes=64 * 1024,
                max_files=1,
            ),
        ),
    ),
)


PROJECT_SCHEMA = _schema(DeckProjectDraft, "tcad.deck-project.v1")
REVIEW_SCHEMA = _schema(DeckReviewReport, "tcad.deck-review-report.v1")
CAPABILITY_SCHEMA = _schema(SolverCapabilitySnapshot, "tcad.solver-capability.v2")
EXPERIMENT_SCHEMA = _schema(ExperimentPortfolio, "scidiscovery.experiment-portfolio.v1")
RUNTIME_ATTESTATION_SCHEMA = _schema(RuntimeAttestation, "tcad.runtime-attestation.v1")
SCIENTIFIC_REVIEW_SCHEMA = _schema(ScientificReview, "scidiscovery.scientific-review.v1")
FOUNDATION_SCHEMA = _schema(ScientificFoundation, "scidiscovery.scientific-foundation.v1")
PARAMETER_REQUIREMENTS_SCHEMA = _schema(DeviceParameterRequirementSet, "scidiscovery.device-parameter-requirements.v1")
DEVICE_PARAMETERS_SCHEMA = _schema(DeviceParameterSet, "scidiscovery.device-parameter-set.v1")
SOURCE_CATALOG_SCHEMA = _schema(EvidenceSourceCatalog, "scidiscovery.evidence-source-catalog.v1")
PARAMETER_COVERAGE_SCHEMA = _schema(DeviceParameterCoverageReport, "scidiscovery.device-parameter-coverage.v1")
EVIDENCE_AUDIT_SCHEMA = _schema(EvidenceAudit, "scidiscovery.evidence-audit.v1")
PARAMETER_UNCERTAINTY_SCHEMA = _schema(ParameterUncertaintyProjection, "scidiscovery.parameter-uncertainty.v1")
EXECUTION_REQUEST_SCHEMA = _schema(ExecutionRequest, "scidiscovery.execution-request")


__all__ = ["PLUGIN"]
