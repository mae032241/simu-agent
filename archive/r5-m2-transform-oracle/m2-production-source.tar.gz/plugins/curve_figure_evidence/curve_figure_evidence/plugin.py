"""Single registration entry for optional paper-figure evidence Operations."""

from curve_score.figure_science_operations import (
    COMPONENT_SPECS as FIGURE_COMPONENT_SPECS,
    OPERATIONS as FIGURE_OPERATIONS,
)
from scidiscovery.operations.spec import (
    PLUGIN_PROTOCOL_VERSION,
    ComponentRef,
    ComponentSpec,
    PluginDefinition,
    PluginDependency,
)


SHARED_IMPLEMENTATION_COMPONENTS = (
    ComponentSpec(
        "figure_semantic_contract",
        "resource",
        "curve_score.science_operations:Resources.figure_semantic_contract",
    ),
    ComponentSpec(
        "figure_manifest_schema",
        "resource",
        "curve_score.operation_transforms:FIGURE_MANIFEST_SCHEMA",
    ),
    ComponentSpec(
        "figure_report_schema",
        "resource",
        "curve_score.operation_transforms:FIGURE_REPORT_SCHEMA",
    ),
    ComponentSpec(
        "nonempty_validator",
        "validator",
        "curve_score.science_operations:_NONEMPTY_COMPONENT",
        resources=(ComponentRef("figure_semantic_contract"),),
    ),
)


PLUGIN = PluginDefinition(
    plugin_id="curve_figure_evidence",
    version="0.1.0",
    protocol_version=PLUGIN_PROTOCOL_VERSION,
    dependencies=(
        PluginDependency("builtin", "0.1.0"),
        PluginDependency("general_science", "0.1.0"),
        PluginDependency("curve_score", "0.2.0"),
    ),
    components=SHARED_IMPLEMENTATION_COMPONENTS + FIGURE_COMPONENT_SPECS,
    operations=FIGURE_OPERATIONS,
)


__all__ = ["PLUGIN"]
