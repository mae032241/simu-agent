# Optional paper-figure evidence plugin

This plugin registers paper-figure extraction and independent review through
the single `scidiscovery.plugins` entry point. It reuses deterministic
digitization, calibration, validation, and curve-normalization algorithms from
`curve_score`; the default TCAD installation does not include it. Run v1 does
not support Agent collection submissions, so extraction remains visible only
in the diagnostic `all` view on the current backend.
