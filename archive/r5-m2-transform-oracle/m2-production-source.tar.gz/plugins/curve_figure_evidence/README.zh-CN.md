# 可选论文图证据插件

本插件通过唯一的 `scidiscovery.plugins` 入口注册两个公开 Operation：

- `science.evidence.extract.figure.v1`：从具有显式坐标、颜色和可见身份锚点的栅格图生成可追溯附件包；
- `science.evidence.audit.figure.v1`：独立审查完整附件包及其精确来源。

插件不复制曲线算法，而是依赖 `curve_score` 中的确定性数字化、校准、验证和转曲线包实现。默认 TCAD
安装不包含本插件。当前 Run v1 不支持 Agent 集合提交，因此提取 Operation 只出现在 `all` 诊断视图，
不会进入当前后端的 `public` 调度视图；这项限制不会通过增加第二提交协议来规避。
