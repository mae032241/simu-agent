"""Pure deterministic raster-to-curve evidence conversion for the curve plugin."""

from __future__ import annotations

import csv
import hashlib
import io
import math
from typing import Annotated, Literal

from PIL import Image, ImageDraw
from pydantic import BaseModel, ConfigDict, Field, model_validator

from scidiscovery.artifact_agent.schema.common import canonical_json

from .figure_evidence import (
    FigurePanelAxisCalibration,
    MAX_FORMAL_RGB_DISTANCE,
    validate_figure_evidence_manifest,
)
from .figure_evidence_validation import build_figure_evidence_validation_report


FigureKey = Annotated[
    str,
    Field(min_length=1, max_length=128, pattern=r"^[A-Za-z0-9][A-Za-z0-9._-]*$"),
]

class _DigitizationModel(BaseModel):
    model_config = ConfigDict(
        allow_inf_nan=False,
        extra="forbid",
        frozen=True,
        strict=True,
    )


class FigureDigitizationSeries(_DigitizationModel):
    series_key: FigureKey
    label: Annotated[str, Field(min_length=1, max_length=4096)]
    color: Annotated[str, Field(pattern=r"^#[0-9a-f]{6}$")]
    color_tolerance: Annotated[
        float, Field(ge=0.0, le=MAX_FORMAL_RGB_DISTANCE)
    ] = 24.0
    line_style: Literal["solid", "dashed", "dotted"] = "solid"
    binding_source: Literal["legend", "annotation", "caption"]
    visible_label: Annotated[str, Field(min_length=1, max_length=4096)]
    min_points: Annotated[int, Field(ge=2, le=100_000)] = 3
    min_visible_fraction: Annotated[float, Field(gt=0.0, le=1.0)] = 0.2
    max_vertical_spread_px: Annotated[float, Field(ge=0.0, le=100.0)] = 4.0
    uncertainty_px: Annotated[float, Field(ge=0.0, le=100.0)] = 0.5


class FigureDigitizationRequest(_DigitizationModel):
    schema_version: Literal["scidiscovery.curve-figure-digitization-request.v1"]
    figure_key: FigureKey
    panel_key: FigureKey
    page: Annotated[int, Field(ge=1, le=100_000)]
    figure: Annotated[str, Field(min_length=1, max_length=4096)]
    citation: Annotated[str, Field(min_length=1, max_length=4096)]
    axis_calibration: FigurePanelAxisCalibration
    series: Annotated[
        tuple[FigureDigitizationSeries, ...], Field(min_length=1, max_length=32)
    ]

    @model_validator(mode="after")
    def _series_are_distinct(self) -> FigureDigitizationRequest:
        keys = tuple(item.series_key for item in self.series)
        colors = tuple(item.color for item in self.series)
        if len(keys) != len(set(keys)):
            raise ValueError("digitization series keys must be unique")
        if len(colors) != len(set(colors)):
            raise ValueError("digitization series colors must be unique")
        return self


def _axis_value(axis: object, pixel: float) -> float:
    fraction = (pixel - axis.pixel_min) / (axis.pixel_max - axis.pixel_min)
    if axis.scale == "linear":
        return axis.value_min + fraction * (axis.value_max - axis.value_min)
    low = math.log10(axis.value_min)
    high = math.log10(axis.value_max)
    return 10 ** (low + fraction * (high - low))


def _axis_uncertainty(axis: object, pixel: float, uncertainty_px: float) -> float:
    total = uncertainty_px + axis.reprojection_error_px
    center = _axis_value(axis, pixel)
    return max(
        abs(center - _axis_value(axis, pixel - total)),
        abs(_axis_value(axis, pixel + total) - center),
    )


def _png_bytes(image: Image.Image) -> bytes:
    stream = io.BytesIO()
    image.save(stream, format="PNG", optimize=False, compress_level=9)
    return stream.getvalue()


def _open_source_image(content: bytes) -> tuple[Image.Image, str, str]:
    try:
        with Image.open(io.BytesIO(content)) as source:
            source_format = source.format
            source.verify()
        with Image.open(io.BytesIO(content)) as source:
            if source.width * source.height > 25_000_000:
                raise ValueError("source panel exceeds the bounded pixel budget")
            image = source.convert("RGB")
    except (OSError, Image.DecompressionBombError) as error:
        raise ValueError("paper_source is not a valid bounded raster image") from error
    try:
        suffix, media_type = {
            "PNG": ("png", "image/png"),
            "JPEG": ("jpg", "image/jpeg"),
            "WEBP": ("webp", "image/webp"),
        }[source_format]
    except KeyError as error:
        raise ValueError("paper_source raster format is unsupported") from error
    return image, suffix, media_type


def _extract_series(
    image: Image.Image,
    request: FigureDigitizationRequest,
    series: FigureDigitizationSeries,
) -> list[tuple[int, float, float]]:
    x_axis = request.axis_calibration.x
    y_axis = request.axis_calibration.y
    if (
        min(x_axis.pixel_min, x_axis.pixel_max) < 0.0
        or max(x_axis.pixel_min, x_axis.pixel_max) >= image.width
        or min(y_axis.pixel_min, y_axis.pixel_max) < 0.0
        or max(y_axis.pixel_min, y_axis.pixel_max) >= image.height
    ):
        raise ValueError("axis calibration exceeds the source panel")
    left = math.ceil(min(x_axis.pixel_min, x_axis.pixel_max))
    right = math.floor(max(x_axis.pixel_min, x_axis.pixel_max))
    top = math.ceil(min(y_axis.pixel_min, y_axis.pixel_max))
    bottom = math.floor(max(y_axis.pixel_min, y_axis.pixel_max))
    target = tuple(int(series.color[index : index + 2], 16) for index in (1, 3, 5))
    threshold = series.color_tolerance * series.color_tolerance
    pixels = image.load()
    points: list[tuple[int, float, float]] = []
    for x in range(left, right + 1):
        matches = [
            y
            for y in range(top, bottom + 1)
            if sum((pixels[x, y][index] - target[index]) ** 2 for index in range(3))
            <= threshold
        ]
        if not matches:
            continue
        if any(right_y != left_y + 1 for left_y, right_y in zip(matches, matches[1:])):
            raise ValueError(
                f"series {series.series_key} has discontinuous same-column support"
            )
        if matches[-1] - matches[0] > series.max_vertical_spread_px:
            continue
        y = (matches[0] + matches[-1]) / 2.0
        uncertainty = max(
            series.uncertainty_px,
            (matches[-1] - matches[0] + 1) / 2.0,
        )
        points.append((x, y, uncertainty))
    visible_fraction = len(points) / (right - left + 1)
    if len(points) < series.min_points or visible_fraction < series.min_visible_fraction:
        raise ValueError(f"series {series.series_key} has insufficient visible support")
    return points


def _curve_csv(
    request: FigureDigitizationRequest,
    series: FigureDigitizationSeries,
    points: list[tuple[int, float, float]],
) -> bytes:
    fields = (
        "panel_key", "series_key", "point_index", "pixel_x_raw", "pixel_y_raw",
        "pixel_x_subpixel", "pixel_y_subpixel", "x_value", "y_value",
        "uncertainty_px", "x_uncertainty", "y_uncertainty", "observed",
        "quantitative_measurement_claim_eligible",
    )
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=fields, lineterminator="\n")
    writer.writeheader()
    first_x = points[0][0]
    for x, y, uncertainty in points:
        writer.writerow({
            "panel_key": request.panel_key,
            "series_key": series.series_key,
            "point_index": x - first_x,
            "pixel_x_raw": x,
            "pixel_y_raw": int(math.floor(y + 0.5)),
            "pixel_x_subpixel": format(float(x), ".17g"),
            "pixel_y_subpixel": format(y, ".17g"),
            "x_value": format(_axis_value(request.axis_calibration.x, x), ".17g"),
            "y_value": format(_axis_value(request.axis_calibration.y, y), ".17g"),
            "uncertainty_px": format(uncertainty, ".17g"),
            "x_uncertainty": format(
                _axis_uncertainty(request.axis_calibration.x, x, uncertainty), ".17g"
            ),
            "y_uncertainty": format(
                _axis_uncertainty(request.axis_calibration.y, y, uncertainty), ".17g"
            ),
            "observed": 1,
            "quantitative_measurement_claim_eligible": 1,
        })
    return stream.getvalue().encode("utf-8")


def _support_overlay(
    image: Image.Image,
    series_points: list[
        tuple[FigureDigitizationSeries, list[tuple[int, float, float]]]
    ],
) -> bytes:
    overlay = image.copy()
    draw = ImageDraw.Draw(overlay)
    highlights = ("#00ffff", "#ff00ff", "#ffb000", "#00ff60")
    for index, (_, points) in enumerate(series_points):
        color = highlights[index % len(highlights)]
        for x, y, _ in points:
            rounded_y = int(math.floor(y + 0.5))
            draw.rectangle((x - 1, rounded_y - 1, x + 1, rounded_y + 1), outline=color)
    return _png_bytes(overlay)


def _sha256(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def build_digitized_figure_bundle(
    source_content: bytes,
    request_content: bytes,
) -> tuple[dict[str, tuple[bytes, str]], dict[str, object]]:
    """Build and mechanically validate one bounded raster evidence bundle in memory."""

    request = FigureDigitizationRequest.model_validate_json(request_content, strict=True)
    image, source_suffix, source_media_type = _open_source_image(source_content)
    series_points = [
        (series, _extract_series(image, request, series)) for series in request.series
    ]
    claimed_pixels: set[tuple[int, int]] = set()
    for _, points in series_points:
        pixels = {(x, int(math.floor(y + 0.5))) for x, y, _ in points}
        if claimed_pixels.intersection(pixels):
            raise ValueError("series pixel support overlaps and is therefore ambiguous")
        claimed_pixels.update(pixels)
    siblings: dict[str, tuple[bytes, str]] = {
        f"source_panels/{request.panel_key}.{source_suffix}": (
            source_content, source_media_type
        ),
        f"audit_overlays/{request.panel_key}--observed-support.png": (
            _support_overlay(image, series_points), "image/png"
        ),
    }
    total_columns = (
        math.floor(max(request.axis_calibration.x.pixel_min, request.axis_calibration.x.pixel_max))
        - math.ceil(min(request.axis_calibration.x.pixel_min, request.axis_calibration.x.pixel_max))
        + 1
    )
    domain_left = math.ceil(
        min(request.axis_calibration.x.pixel_min, request.axis_calibration.x.pixel_max)
    )
    domain_right = math.floor(
        max(request.axis_calibration.x.pixel_min, request.axis_calibration.x.pixel_max)
    )
    manifest_series = []
    for series, points in series_points:
        item = f"curve_tables/{request.panel_key}--{series.series_key}.csv"
        siblings[item] = (_curve_csv(request, series, points), "text/csv")
        gaps = [
            points[0][0] - domain_left,
            domain_right - points[-1][0],
            *(right[0] - left[0] - 1 for left, right in zip(points, points[1:])),
        ]
        manifest_series.append({
            "series_key": series.series_key,
            "label": series.label,
            "primitive_kind": "line",
            "descriptor": {
                "color": series.color,
                "color_tolerance": series.color_tolerance,
                "line_style": series.line_style,
            },
            "data_item": item,
            "binding": {
                "source": series.binding_source,
                "visible_label": series.visible_label,
                "status": "matched",
                "confidence": 1.0,
                "alternatives": [],
            },
            "point_count": len(points),
            "visible_fraction": len(points) / total_columns,
            "max_gap_px": max(gaps, default=0),
            "uncertainty_px": max(point[2] for point in points),
        })
    manifest = {
        "schema_version": "scidiscovery.figure-evidence-manifest.v1",
        "figure_key": request.figure_key,
        "status": "qualified",
        "source": {
            "source_name": "paper_source", "page": request.page,
            "figure": request.figure, "image_sha256": _sha256(source_content),
            "width": image.width, "height": image.height,
        },
        "panels": [{
            "panel_key": request.panel_key,
            "citation": request.citation,
            "axis_calibration": request.axis_calibration.model_dump(mode="json"),
            "series": manifest_series,
        }],
        "metrics": {
            "panel_count": 1,
            "series_count": len(manifest_series),
            "qualified_series_count": len(manifest_series),
            "total_point_count": sum(len(points) for _, points in series_points),
            "minimum_visible_fraction": min(
                item["visible_fraction"] for item in manifest_series
            ),
        },
        "ambiguities": [],
        "provenance": {
            "spec_sha256": _sha256(canonical_json(request.model_dump(mode="json"))),
            "output_artifacts": [
                {
                    "collection": name.split("/", 1)[0],
                    "data_item": name,
                    "sha256": _sha256(content),
                    "bytes": len(content),
                    "media_type": media_type,
                }
                for name, (content, media_type) in sorted(siblings.items())
            ],
        },
    }
    manifest_raw = canonical_json(validate_figure_evidence_manifest(manifest))
    report = build_figure_evidence_validation_report(
        manifest_data_item="figure_manifest/evidence.json",
        manifest_content=manifest_raw,
        sibling_files=siblings,
    )
    files = {
        "figure_manifest/evidence.json": (manifest_raw, "application/json"),
        **siblings,
        "validation_reports/validation_report.json": (
            canonical_json(report), "application/json"
        ),
    }
    return files, report


__all__ = ["FigureDigitizationRequest", "build_digitized_figure_bundle"]
