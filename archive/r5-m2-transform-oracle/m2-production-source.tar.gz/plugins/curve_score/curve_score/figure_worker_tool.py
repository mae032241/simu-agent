"""Operation-scoped Worker adapters for deterministic curve-figure tools."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

from pydantic import BaseModel, ConfigDict

from scidiscovery.artifact_agent.schema.common import canonical_json
from scidiscovery.artifact_agent.operation_tool_context import OperationToolContext
from scidiscovery.artifact_agent.schema.output_bundle import (
    OutputBundle,
    OutputBundleItem,
)
from scidiscovery.operations.tooling import WorkerToolDefinition

from .figure_digitization import build_digitized_figure_bundle
from .figure_evidence_validation import build_figure_evidence_validation_report


class FigureDigitizationToolInput(BaseModel):
    """The exact scientific request is read from the bound figure_request input."""

    model_config = ConfigDict(extra="forbid", frozen=True)


class FigureBundleValidationRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


def _commit_bundle(output: Path, files: dict[str, tuple[bytes, str]]) -> None:
    bundle_path = output / "bundle.json"
    destinations = tuple(output / "collections" / name for name in sorted(files))
    if bundle_path.exists() or any(path.exists() for path in destinations):
        raise ValueError("figure output already contains a bundle item")
    items = tuple(
        OutputBundleItem(
            collection=name.split("/", 1)[0],
            item=name.split("/", 1)[1],
            media_type=media_type,
            relative_path=f"collections/{name}",
        )
        for name, (_, media_type) in sorted(files.items())
    )
    staged = Path(tempfile.mkdtemp(prefix=".figure-digitize.", dir=output))
    try:
        for name, (content, _) in files.items():
            destination = staged / "collections" / name
            destination.parent.mkdir(parents=True, mode=0o700, exist_ok=True)
            destination.write_bytes(content)
            os.chmod(destination, 0o600)
        staged_bundle = staged / "bundle.json"
        staged_bundle.write_bytes(canonical_json(OutputBundle(items=items)))
        os.chmod(staged_bundle, 0o600)
        for name in sorted(files):
            destination = output / "collections" / name
            destination.parent.mkdir(parents=True, mode=0o700, exist_ok=True)
            os.replace(staged / "collections" / name, destination)
        os.replace(staged_bundle, bundle_path)
    finally:
        for path in sorted(
            staged.rglob("*"), key=lambda item: len(item.parts), reverse=True
        ):
            if path.is_file():
                path.unlink(missing_ok=True)
            elif path.is_dir():
                path.rmdir()
        staged.rmdir()


def _digitize(request: BaseModel, context: OperationToolContext) -> dict[str, object]:
    if not isinstance(request, FigureDigitizationToolInput):
        raise ValueError("figure digitization request has the wrong type")
    raw_request = context.read_input("figure_request")
    prior = context.state.get("request")
    if prior is not None:
        if prior != raw_request:
            raise ValueError("figure digitization already ran with different inputs")
        response = context.state.get("response")
        if not isinstance(response, dict):
            raise RuntimeError("figure digitization cache is incomplete")
        return response
    try:
        required = {
            "figure_manifest", "source_panels", "audit_overlays",
            "curve_tables", "validation_reports",
        }
        if not required.issubset(context.output_collections):
            raise ValueError("figure digitization output collections are unavailable")
        files, report = build_digitized_figure_bundle(
            context.read_input("paper_source"), raw_request
        )
        if any(len(content) > 16 * 1024 * 1024 for content, _ in files.values()):
            raise ValueError("figure digitization produced an oversized item")
        output = context.output_directory
        _commit_bundle(output, files)
    except Exception:
        context.record_activity("deterministic_analysis_rejected")
        raise
    response: dict[str, object] = {
        "bundle_fingerprint_sha256": report["bundle_fingerprint_sha256"],
        "validated_artifact_count": report["validated_artifact_count"],
        "metrics": report["metrics"],
    }
    context.record_activity("deterministic_analysis_completed")
    context.state["request"] = raw_request
    context.state["response"] = response
    return response


def _regular_files(directory: Path) -> tuple[Path, ...]:
    if not directory.is_dir() or directory.is_symlink():
        return ()
    values = tuple(sorted(directory.iterdir(), key=lambda item: item.name))
    if any(not item.is_file() or item.is_symlink() for item in values):
        raise ValueError("figure collection contains a non-regular item")
    return values


def _media_type(path: Path) -> str:
    try:
        return {
            ".csv": "text/csv", ".jpeg": "image/jpeg", ".jpg": "image/jpeg",
            ".png": "image/png", ".webp": "image/webp",
        }[path.suffix.lower()]
    except KeyError as error:
        raise ValueError(f"unsupported figure bundle item: {path.name}") from error


def _validate(request: BaseModel, context: OperationToolContext) -> dict[str, object]:
    if not isinstance(request, FigureBundleValidationRequest):
        raise ValueError("figure validation request has the wrong type")
    output = context.output_directory
    root = output / "collections"
    manifests = _regular_files(root / "figure_manifest")
    if len(manifests) != 1:
        raise ValueError("figure validation requires exactly one staged manifest")
    siblings: dict[str, tuple[bytes, str]] = {}
    for collection in ("source_panels", "audit_overlays", "curve_tables"):
        for path in _regular_files(root / collection):
            siblings[f"{collection}/{path.name}"] = (
                path.read_bytes(), _media_type(path)
            )
    report = build_figure_evidence_validation_report(
        manifest_data_item=f"figure_manifest/{manifests[0].name}",
        manifest_content=manifests[0].read_bytes(),
        sibling_files=siblings,
    )
    context.record_activity("deterministic_analysis_completed")
    return report


FIGURE_DIGITIZATION_TOOL = WorkerToolDefinition(
    name="worker_curve_figure_digitize",
    description=(
        "Deterministically digitize the exact bound raster panel using the "
        "explicit calibration, color, and identity anchors in figure_request."
    ),
    input_model=FigureDigitizationToolInput,
    capability="analysis.curve_figure",
    contextual_handler=_digitize,
)

FIGURE_BUNDLE_VALIDATION_TOOL = WorkerToolDefinition(
    name="worker_curve_figure_validate",
    description=(
        "Compute the exact deterministic validation report for the currently "
        "staged curve-figure manifest and attachments."
    ),
    input_model=FigureBundleValidationRequest,
    capability="analysis.curve_figure",
    contextual_handler=_validate,
)


__all__ = [
    "FIGURE_BUNDLE_VALIDATION_TOOL",
    "FIGURE_DIGITIZATION_TOOL",
    "FigureBundleValidationRequest",
    "FigureDigitizationToolInput",
]
