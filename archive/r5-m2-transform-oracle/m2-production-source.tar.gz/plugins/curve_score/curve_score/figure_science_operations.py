"""Curve-figure evidence Operations owned entirely by the curve plugin."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from typing import Any

from scidiscovery.artifact_agent.schema.common import canonical_json
from scidiscovery.operation_declaration import (
    OPERATION_AGENT_PREAMBLE,
    payload_validator,
    scientific_agent_operation,
)
from scidiscovery.operations.spec import (
    CallableComponent,
    CollectionSpec,
    ComponentRef,
    ComponentSpec,
    InputPortSpec,
    OutputPortSpec,
    ReviewSpec,
)

from .figure_evidence import (
    validate_figure_evidence_manifest,
    validate_figure_evidence_validation_report,
)
from .figure_digitization import build_digitized_figure_bundle
from .figure_evidence_validation import (
    FigureEvidenceBundleError,
    build_figure_evidence_validation_report,
)


GENERAL = "general_science"
BUILTIN = "builtin"


def _general(name: str) -> ComponentRef:
    return ComponentRef(name, plugin_id=GENERAL)


BASE_TOOLS = tuple(
    ComponentRef(name, plugin_id=BUILTIN)
    for name in (
        "file_write_begin_tool",
        "file_write_chunk_tool",
        "file_write_commit_tool",
    )
) + (
    _general("file_apply_patch_tool"),
)

AUDIT_TOOLS = BASE_TOOLS + (_general("pdf_extract_tool"),)


FIGURE_PROMPT = OPERATION_AGENT_PREAMBLE + """Return the exact primary envelope
and declared attachment bundle required by assignment.json. Digitize only
visible, calibrated series in the supplied raster panel. Confirm that the exact
figure_request contains explicit axis, color, and visible identity anchors;
never infer identity from color, order, proximity, or an expected scientific
result. Call worker_curve_figure_digitize to produce the complete versioned
bundle, then call worker_curve_figure_validate and require the same fingerprint.
Do not use temporary analysis code to create formal curve evidence. Write the
primary envelope with that fingerprint, validate the complete exact bundle and
finalize it; mechanical success does not itself establish a scientific claim.
"""

def _figure_bundle_validator(
    primary_envelope: dict[str, Any],
    items: dict[str, bytes],
    validation_context: object,
) -> None:
    if not isinstance(validation_context, Mapping):
        raise ValueError("figure bundle validation context is unavailable")
    inputs = validation_context.get("inputs")
    successful_tools = validation_context.get("successful_worker_tools")
    if (
        not isinstance(inputs, Mapping)
        or not isinstance(successful_tools, tuple)
        or "worker_curve_figure_digitize" not in successful_tools
    ):
        raise ValueError("figure bundle requires its registered digitizer receipt")
    paper_sources = inputs.get("paper_source")
    figure_requests = inputs.get("figure_request")
    if (
        not isinstance(paper_sources, tuple)
        or len(paper_sources) != 1
        or not isinstance(figure_requests, tuple)
        or len(figure_requests) != 1
    ):
        raise ValueError("figure bundle requires its exact bound source and request")
    expected_files, _ = build_digitized_figure_bundle(
        paper_sources[0], figure_requests[0]
    )
    expected_items = {
        name: content for name, (content, _) in expected_files.items()
    }
    if items != expected_items:
        raise ValueError("figure bundle differs from the registered digitizer replay")
    manifests = {
        name: raw for name, raw in items.items()
        if name.startswith("figure_manifest/")
    }
    reports = {
        name: raw for name, raw in items.items()
        if name.startswith("validation_reports/")
    }
    siblings = {
        name: raw
        for name, raw in items.items()
        if name.startswith(("source_panels/", "audit_overlays/", "curve_tables/"))
    }
    if len(manifests) != 1 or set(reports) != {
        "validation_reports/validation_report.json"
    }:
        raise ValueError("figure bundle requires one manifest and one canonical report")
    manifest_name, manifest_raw = next(iter(manifests.items()))
    try:
        manifest = json.loads(manifest_raw)
        declared = {
            row["data_item"]: row
            for row in manifest["provenance"]["output_artifacts"]
        }
    except (UnicodeDecodeError, json.JSONDecodeError, KeyError, TypeError) as error:
        raise ValueError("figure manifest provenance is unavailable") from error
    if set(declared) != set(siblings):
        raise ValueError("figure manifest must exactly enumerate sibling outputs")
    media_types: dict[str, str] = {}
    for name, raw in siblings.items():
        media_type = {
            "csv": "text/csv",
            "jpeg": "image/jpeg",
            "jpg": "image/jpeg",
            "png": "image/png",
            "webp": "image/webp",
        }.get(name.rsplit(".", 1)[-1].lower())
        if media_type is None:
            raise ValueError(f"unsupported figure bundle item: {name}")
        row = declared[name]
        if (
            row["bytes"] != len(raw)
            or row["sha256"] != hashlib.sha256(raw).hexdigest()
            or row["media_type"].strip().lower() != media_type
        ):
            raise ValueError(f"figure manifest provenance differs from {name}")
        media_types[name] = media_type
    try:
        report = build_figure_evidence_validation_report(
            manifest_data_item=manifest_name,
            manifest_content=manifest_raw,
            sibling_files={
                name: (raw, media_types[name]) for name, raw in siblings.items()
            },
        )
        normalized = validate_figure_evidence_validation_report(report)
    except (FigureEvidenceBundleError, ValueError) as error:
        raise ValueError(f"figure bundle validation failed: {error}") from error
    if reports["validation_reports/validation_report.json"] != canonical_json(normalized):
        raise ValueError("figure validation report is not the deterministic report")
    try:
        handoff = primary_envelope["handoff"]
        fingerprint = normalized["bundle_fingerprint_sha256"]
    except (KeyError, TypeError) as error:
        raise ValueError("figure handoff is unavailable") from error
    if handoff.get("evidence_bundle_fingerprint_sha256") != fingerprint:
        raise ValueError("figure handoff fingerprint differs from the validated bundle")
    if any(
        handoff.get(name)
        for name in ("assumptions", "missing_inputs", "next_actions")
    ):
        raise ValueError("figure handoff must leave projected scientific lists empty")


FIGURE_MANIFEST_VALIDATOR = CallableComponent(
    "validator", payload_validator(validate_figure_evidence_manifest)
)
FIGURE_REPORT_VALIDATOR = CallableComponent(
    "validator", payload_validator(validate_figure_evidence_validation_report)
)
FIGURE_BUNDLE_VALIDATOR = CallableComponent("validator", _figure_bundle_validator)


COMPONENT_SPECS = (
    ComponentSpec(
        "figure_digitization_tool",
        "worker_tool",
        "curve_score.figure_worker_tool:FIGURE_DIGITIZATION_TOOL",
    ),
    ComponentSpec(
        "figure_bundle_validation_tool",
        "worker_tool",
        "curve_score.figure_worker_tool:FIGURE_BUNDLE_VALIDATION_TOOL",
    ),
    ComponentSpec(
        "figure_manifest_validator",
        "validator",
        "curve_score.figure_science_operations:FIGURE_MANIFEST_VALIDATOR",
        resources=(ComponentRef("figure_semantic_contract"),),
    ),
    ComponentSpec(
        "figure_report_validator",
        "validator",
        "curve_score.figure_science_operations:FIGURE_REPORT_VALIDATOR",
        resources=(ComponentRef("figure_semantic_contract"),),
    ),
    ComponentSpec(
        "figure_bundle_validator",
        "validator",
        "curve_score.figure_science_operations:FIGURE_BUNDLE_VALIDATOR",
        resources=(ComponentRef("figure_semantic_contract"),),
    ),
    ComponentSpec(
        "figure_prompt",
        "resource",
        "curve_score.figure_science_operations:FIGURE_PROMPT",
    ),
)

def _schema_ref(schema: str) -> ComponentRef:
    if schema == "scidiscovery.figure-evidence-manifest.v1":
        return ComponentRef("figure_manifest_schema")
    if schema == "scidiscovery.figure-evidence-validation-report.v1":
        return ComponentRef("figure_report_schema")
    return _general(
        {
            "opaque": "opaque_schema",
            "scidiscovery.scientific-intake.v1": "scientific_intake_schema",
            "scidiscovery.evidence-audit.v1": "evidence_audit_schema",
        }[schema]
    )


def _input(
    name: str,
    description: str,
    schema: str,
    *,
    media_types: tuple[str, ...] = ("application/json",),
    min_items: int = 1,
    max_items: int = 1,
    max_item_bytes: int = 1024 * 1024,
    exposure: str = "full",
    usage: str = "claim_evidence",
) -> InputPortSpec:
    return InputPortSpec(
        name=name,
        description=description,
        schema=schema,
        media_types=media_types,
        codec=_general("opaque_codec" if schema == "opaque" else "json_codec"),
        schema_resource=_schema_ref(schema),
        min_items=min_items,
        max_items=max_items,
        max_item_bytes=max_item_bytes,
        exposure=exposure,
        usage=usage,
    )


def _output(
    name: str,
    description: str,
    kind: str,
    schema: str,
    validator: ComponentRef,
    *,
    max_item_bytes: int,
    media_types: tuple[str, ...] = ("application/json",),
    min_items: int = 1,
    max_items: int = 1,
    collection: CollectionSpec | None = None,
    context_validator: ComponentRef | None = None,
    context_sources: tuple[str, ...] = (),
) -> OutputPortSpec:
    figure_schema = schema.startswith("scidiscovery.figure-evidence-")
    return OutputPortSpec(
        name=name,
        description=description,
        kind=kind,
        schema=schema,
        media_types=media_types,
        codec=_general("opaque_codec" if schema == "opaque" else "json_codec"),
        schema_resource=_schema_ref(schema),
        min_items=min_items,
        max_items=max_items,
        max_item_bytes=max_item_bytes,
        validator=validator,
        semantic_contract=(
            ComponentRef("figure_semantic_contract")
            if figure_schema or schema == "opaque"
            else _general("intake_semantic_contract")
            if schema == "scidiscovery.scientific-intake.v1"
            else _general("evidence_audit_semantic_contract")
        ),
        collection=collection,
        context_validator=context_validator,
        context_sources=context_sources,
        evidence_paths=("/scientific_foundation/evidence",)
        if schema == "scidiscovery.scientific-intake.v1"
        else ("/evidence",)
        if schema == "scidiscovery.evidence-audit.v1"
        else (),
        allowed_input_usages=(
            "change_request", "prior_signal", "evidence_inventory"
        ),
    )


INTAKE_OUTPUT = _output(
    "scientific_intake",
    "Concise problem frame and source-bound scientific foundation.",
    "scientific_intake",
    "scidiscovery.scientific-intake.v1",
    _general("intake_validator"),
    max_item_bytes=64 * 1024,
)

FIGURE_OUTPUTS = (
    INTAKE_OUTPUT,
    _output(
        "figure_manifest", "One canonical figure-evidence manifest.",
        "figure_evidence_manifest", "scidiscovery.figure-evidence-manifest.v1",
        ComponentRef("figure_manifest_validator"), max_item_bytes=1024 * 1024,
        collection=CollectionSpec(
            max_total_bytes=1024 * 1024,
            bundle_validator=ComponentRef("figure_bundle_validator"),
        ),
    ),
    _output(
        "source_panels", "Exact source-panel raster images.",
        "figure_source_panel", "opaque", ComponentRef("nonempty_validator"),
        max_item_bytes=16 * 1024 * 1024,
        media_types=("image/png", "image/jpeg", "image/webp"), min_items=1,
        max_items=16, collection=CollectionSpec(max_total_bytes=64 * 1024 * 1024),
    ),
    _output(
        "audit_overlays", "Pixel-level audit overlays.",
        "figure_audit_overlay", "opaque", ComponentRef("nonempty_validator"),
        max_item_bytes=16 * 1024 * 1024, media_types=("image/png",),
        min_items=1, max_items=32,
        collection=CollectionSpec(max_total_bytes=128 * 1024 * 1024),
    ),
    _output(
        "curve_tables", "Per-series traceable curve tables.",
        "digitized_curve_table", "opaque", ComponentRef("nonempty_validator"),
        max_item_bytes=8 * 1024 * 1024, media_types=("text/csv",),
        min_items=1, max_items=128,
        collection=CollectionSpec(max_total_bytes=64 * 1024 * 1024),
    ),
    _output(
        "validation_reports", "Deterministic exact-bundle validation report.",
        "figure_evidence_validation_report",
        "scidiscovery.figure-evidence-validation-report.v1",
        ComponentRef("figure_report_validator"), max_item_bytes=1024 * 1024,
        collection=CollectionSpec(max_total_bytes=1024 * 1024),
    ),
)


def _agent(
    operation_id: str,
    purpose: str,
    applies_when: str,
    not_for: str,
    *,
    agent: ComponentRef,
    prompt: ComponentRef,
    inputs: tuple[InputPortSpec, ...],
    outputs: tuple[OutputPortSpec, ...],
    timeout: int,
    max_input_bytes: int,
    max_output_bytes: int,
    max_files: int,
    review: ReviewSpec | None = None,
    tools: tuple[ComponentRef, ...] = BASE_TOOLS,
) -> Any:
    return scientific_agent_operation(
        operation_id, purpose, applies_when, not_for,
        agent=agent, workspace=_general("workspace"), prompt=prompt,
        tools=tools, inputs=inputs, outputs=outputs, timeout=timeout,
        max_input_bytes=max_input_bytes, max_output_bytes=max_output_bytes,
        max_files=max_files, native_view_image=True, review=review,
    )


AUDIT_INPUTS = (
    _input("scientific_intake", "Provisional intake for the figure bundle.",
           "scidiscovery.scientific-intake.v1", usage="prior_signal"),
    _input("paper_source", "Exact source paper or panel container.", "opaque",
           media_types=("application/pdf", "image/png", "image/jpeg", "image/webp"),
           max_item_bytes=32 * 1024 * 1024),
    _input("figure_request", "Frozen calibration and identity anchors.", "opaque",
           media_types=("application/json", "text/plain", "text/plain; charset=utf-8"),
           max_item_bytes=1024 * 1024, usage="evidence_inventory"),
    _input("figure_manifest", "Exact mechanically validated manifest.",
           "scidiscovery.figure-evidence-manifest.v1", usage="evidence_inventory"),
    _input("validation_report", "Exact deterministic validation report.",
           "scidiscovery.figure-evidence-validation-report.v1", usage="evidence_inventory"),
    _input("source_panels", "Exact source-panel raster attachments.", "opaque",
           media_types=("image/png", "image/jpeg", "image/webp"), max_items=16,
           max_item_bytes=16 * 1024 * 1024, exposure="on_demand", usage="evidence_inventory"),
    _input("audit_overlays", "Exact pixel-level audit overlays.", "opaque",
           media_types=("image/png",), max_items=32,
           max_item_bytes=16 * 1024 * 1024, exposure="on_demand", usage="evidence_inventory"),
    _input("curve_tables", "Exact per-series curve tables.", "opaque",
           media_types=("text/csv",), max_items=128,
           max_item_bytes=8 * 1024 * 1024, exposure="on_demand", usage="evidence_inventory"),
)

AUDIT_OUTPUT = _output(
    "evidence_audit", "Independent evidence and provenance audit.",
    "evidence_audit", "scidiscovery.evidence-audit.v1", _general("audit_validator"),
    max_item_bytes=32 * 1024,
    context_validator=_general("evidence_audit_context"),
    context_sources=tuple(port.name for port in AUDIT_INPUTS),
)

OPERATIONS = (
    _agent(
        "science.evidence.audit.figure.v1",
        "Audit one complete mechanically validated figure-evidence bundle.",
        "A provisional figure extraction and every exact sibling attachment exist.",
        "Digitizing the figure or qualifying the evidence.",
        agent=_general("auditor_agent"), prompt=_general("auditor_prompt"),
        inputs=AUDIT_INPUTS, outputs=(AUDIT_OUTPUT,), timeout=600,
        max_input_bytes=293 * 1024 * 1024, max_output_bytes=32 * 1024,
        max_files=1, tools=AUDIT_TOOLS,
    ),
    _agent(
        "science.evidence.extract.figure.v1",
        "Digitize one quantitative paper figure into a traceable evidence bundle.",
        "A supplied paper figure has explicit calibration and identity anchors.",
        "OCR-only extraction or resolving ambiguous identity by inference.",
        agent=_general("evidence_agent"), prompt=ComponentRef("figure_prompt"),
        inputs=(
            _input("paper_source", "Exact source-panel raster image.", "opaque",
                   media_types=("image/png", "image/jpeg", "image/webp"),
                   max_item_bytes=32 * 1024 * 1024, usage="evidence_inventory"),
            _input("figure_request", "Frozen calibration and identity anchors.", "opaque",
                   media_types=("application/json", "text/plain", "text/plain; charset=utf-8"),
                   max_item_bytes=1024 * 1024, usage="evidence_inventory"),
        ),
        outputs=FIGURE_OUTPUTS, timeout=900,
        max_input_bytes=33 * 1024 * 1024,
        max_output_bytes=259 * 1024 * 1024, max_files=179,
        tools=BASE_TOOLS + (
            ComponentRef("figure_digitization_tool"),
            ComponentRef("figure_bundle_validation_tool"),
        ),
        review=ReviewSpec(
            reviewer_operation="science.evidence.audit.figure.v1",
            reviewer_input_port="scientific_intake",
            subject_outputs=("scientific_intake",),
        ),
    ),
)


__all__ = ["COMPONENT_SPECS", "OPERATIONS"]
