"""Evidence-bound study validation and physical interpretation."""

from __future__ import annotations

from typing import Annotated, Any, Literal

from pydantic import Field, model_validator

from .common import ContractDiagnostic, Identifier, SchemaModel, canonical_json
from .validation import (
    HypothesisAssessment,
    RecommendedTaskMode,
    ValidationEvidence,
)


GateStatus = Literal[
    "pass", "fail", "inconclusive", "not_evaluable", "not_applicable"
]


class ScientificGateResult(SchemaModel):
    status: GateStatus
    summary: Annotated[str, Field(min_length=1, max_length=4096)]
    evidence_keys: Annotated[tuple[Identifier, ...], Field(max_length=64)] = ()
    findings: Annotated[tuple[str, ...], Field(max_length=128)] = ()

    @model_validator(mode="after")
    def _decisive_gate_has_evidence(self) -> ScientificGateResult:
        if self.status in {"pass", "fail"} and not self.evidence_keys:
            raise ValueError("passing or failing gate requires evidence_keys")
        if len(self.evidence_keys) != len(set(self.evidence_keys)):
            raise ValueError("gate evidence_keys must be unique")
        return self


class ScientificGateSequence(SchemaModel):
    evidence_identity: ScientificGateResult
    implementation_fidelity: ScientificGateResult
    numerical_validity: ScientificGateResult
    control_equivalence: ScientificGateResult
    observation: ScientificGateResult
    physical_interpretation: ScientificGateResult

    @property
    def prerequisite_status(self) -> Literal["pass", "invalid"]:
        return (
            "pass"
            if all(
                item.status in {"pass", "not_applicable"}
                for item in (
                    self.evidence_identity,
                    self.implementation_fidelity,
                    self.numerical_validity,
                    self.control_equivalence,
                )
            )
            else "invalid"
        )

    @property
    def first_failed_gate(self) -> str | None:
        for name in (
            "evidence_identity",
            "implementation_fidelity",
            "numerical_validity",
            "control_equivalence",
        ):
            if getattr(self, name).status not in {"pass", "not_applicable"}:
                return name
        return None


class ObjectiveDiagnosisAssessment(SchemaModel):
    """A diagnosis of the approved objective, separate from numerical checks."""

    objective_key: Identifier
    status: Literal["pass", "fail", "inconclusive", "not_evaluable"]
    comparison_keys: Annotated[tuple[Identifier, ...], Field(max_length=256)] = ()
    summary: Annotated[str, Field(min_length=1, max_length=4096)]
    evidence_keys: Annotated[tuple[Identifier, ...], Field(max_length=64)] = ()

    @model_validator(mode="after")
    def _references_are_unique(self) -> ObjectiveDiagnosisAssessment:
        if len(self.comparison_keys) != len(set(self.comparison_keys)):
            raise ValueError("objective assessment comparison_keys must be unique")
        if len(self.evidence_keys) != len(set(self.evidence_keys)):
            raise ValueError("objective assessment evidence_keys must be unique")
        if self.status in {"pass", "fail"} and not self.evidence_keys:
            from ...operation_contract import declared_violation
            raise declared_violation("passing or failing objective assessment requires evidence_keys", path="$.evidence_keys")
        return self


class CalculationAttemptReference(SchemaModel):
    manifest_alias: Identifier
    attempt_key: Identifier
    proof_kind: Literal["current", "recovery"] = "current"


class CalculationRecord(SchemaModel):
    """Bounded, replayable calculation evidence; never a scientific verdict."""

    record_key: Identifier
    input_digests: Annotated[dict[str, str], Field(max_length=40)]
    request: dict[str, Any]
    algorithm_version: Annotated[str, Field(min_length=1, max_length=128)]
    status: Literal["computed", "unavailable", "unsupported", "error"]
    result: dict[str, Any] | None = None
    reason_code: Identifier | None = None
    attempt: CalculationAttemptReference | None = None
    diagnostics: tuple[ContractDiagnostic, ...] = Field(default=(), max_length=8)

    @model_validator(mode="after")
    def _bounded_status(self) -> CalculationRecord:
        if len(canonical_json(self)) > 32 * 1024:
            raise ValueError("calculation record exceeds 32 KiB")
        if self.status == "computed":
            if self.result is None or self.reason_code is not None:
                raise ValueError("computed record requires result and no reason")
        elif self.result is not None or self.reason_code is None:
            raise ValueError("noncomputed record requires reason and no numeric result")
        return self


class CaseMappingEvidence(SchemaModel):
    input_alias: Identifier
    locator: Annotated[str, Field(min_length=1, max_length=256)]


class CaseMappingBasis(SchemaModel):
    kind: Literal["declared", "evidence"]
    evidence_refs: tuple[CaseMappingEvidence, ...] = Field(default=(), max_length=8)
    rationale: Annotated[str, Field(min_length=1, max_length=2048)]


class AnalysisSourceReference(SchemaModel):
    """Explicit evidence locator; bound identity is checked by the domain validator."""

    source_key: Identifier
    input_alias: Annotated[str, Field(min_length=1, max_length=256)]
    case_mapping_basis: CaseMappingBasis | None = None
    output_name: Annotated[str, Field(min_length=1, max_length=256)] | None = None
    experiment_key: Identifier | None = None
    case_key: Identifier | None = None

    @model_validator(mode="after")
    def _case_identity_is_paired(self) -> AnalysisSourceReference:
        if (self.experiment_key is None) != (self.case_key is None):
            raise ValueError("source experiment_key and case_key must be declared together")
        return self


class LayeredDiagnosisReport(SchemaModel):
    study_kind: Literal["scientific", "engineering"] = "scientific"
    experiment_key: Identifier
    plan_key: Identifier
    summary: Annotated[str, Field(min_length=1, max_length=8192)]
    evidence: Annotated[tuple[ValidationEvidence, ...], Field(max_length=256)] = ()
    source_references: Annotated[tuple[AnalysisSourceReference, ...], Field(max_length=64)] = ()
    gates: ScientificGateSequence
    overall_verdict: Literal["pass", "fail", "inconclusive", "invalid_study"]
    claim_allowed: bool
    objective_assessment: ObjectiveDiagnosisAssessment | None = None
    hypothesis_assessments: Annotated[
        tuple[HypothesisAssessment, ...], Field(max_length=32)
    ] = ()
    remaining_contradiction: Annotated[str, Field(min_length=1, max_length=8192)]
    next_action: Annotated[str, Field(min_length=1, max_length=4096)]
    recommended_task_mode: RecommendedTaskMode | None = None
    calculation_records: Annotated[tuple[CalculationRecord, ...], Field(max_length=8)] = ()
    analysis_method: Annotated[str, Field(min_length=1, max_length=4096)] | None = None
    method_changes: Annotated[tuple[str, ...], Field(max_length=16)] = ()

    @model_validator(mode="after")
    def _verdict_and_assessments_follow_the_gates(self) -> LayeredDiagnosisReport:
        issues = diagnosis_consistency_issues(self)
        if issues:
            from ...operation_contract import SemanticRuleViolation, declared_violation
            # These messages and paths are emitted only by the mechanical checks below.
            details = tuple(detail for item in issues for detail in declared_violation(
                item["message"], path="$" + "".join(
                    f"[{part}]" if part.isdigit() else "." + part
                    for part in item["path"].split("/")[1:])).details)
            raise SemanticRuleViolation("; ".join(item["message"] for item in issues), details=details)
        return self


def diagnosis_consistency_issues(report: LayeredDiagnosisReport) -> tuple[dict[str, Any], ...]:
    """Return mechanical inconsistencies without deriving or rewriting science."""
    issues = []
    def issue(path, message, **suggestion):
        issues.append({"path": path, "message": message, **suggestion})
    record_keys = tuple(item.record_key for item in report.calculation_records)
    if len(record_keys) != len(set(record_keys)):
        issue("/calculation_records", "calculation record keys must be unique")
    if sum(len(canonical_json(item)) for item in report.calculation_records) > 96 * 1024:
        issue("/calculation_records", "calculation records exceed report replay budget")
    source_keys = tuple(item.source_key for item in report.evidence)
    if len(source_keys) != len(set(source_keys)):
        issue("/evidence", "diagnosis evidence source_key values must be unique")
    known = set(source_keys)
    gate_names = ("evidence_identity", "implementation_fidelity", "numerical_validity",
                  "control_equivalence", "observation", "physical_interpretation")
    gates = tuple(getattr(report.gates, name) for name in gate_names)
    for name, gate in zip(gate_names, gates):
        if not set(gate.evidence_keys).issubset(known):
            issue("/gates/" + name, "diagnosis gate references undeclared evidence")
    objective = report.objective_assessment
    if objective is not None and not set(objective.evidence_keys).issubset(known):
        issue("/objective_assessment", "objective assessment references undeclared evidence")
    if report.study_kind == "scientific":
        if any(item.status == "not_applicable" for item in gates):
            issue("/gates", "scientific diagnosis cannot skip a required gate")
    elif report.hypothesis_assessments:
        issue("/hypothesis_assessments", "engineering diagnosis cannot assess physical hypotheses")
    complete = all(item.status in {"pass", "not_applicable"} for item in gates)
    complete = complete and (objective is None or objective.status == "pass")
    if report.overall_verdict == "pass" and not complete:
        issue("/overall_verdict", "overall pass requires every required gate and objective assessment to pass",
              suggested_value="inconclusive")
    if report.claim_allowed and not (report.study_kind == "scientific"
            and report.overall_verdict == "pass" and complete):
        issue("/claim_allowed", "claim_allowed is true only for a passing scientific study", suggested_value=False)
    assessment_keys = tuple(item.hypothesis_key for item in report.hypothesis_assessments)
    if len(assessment_keys) != len(set(assessment_keys)):
        issue("/hypothesis_assessments", "a diagnosis may assess each hypothesis once")
    physical = report.gates.physical_interpretation
    for index, assessment in enumerate(report.hypothesis_assessments):
        path = f"/hypothesis_assessments/{index}"
        if not set(assessment.evidence_keys).issubset(known):
            issue(path, "hypothesis assessment references undeclared evidence")
        expected = {"supports": "pass", "contradicts": "fail"}.get(assessment.outcome)
        if expected is not None and (physical.status != expected
                or not set(assessment.evidence_keys).intersection(physical.evidence_keys)):
            issue(path, "decisive hypothesis assessment requires matching physical interpretation evidence",
                  suggested_outcome="inconclusive")
    return tuple(issues)


def validate_layered_diagnosis(value: dict[str, object]) -> dict[str, object]:
    return LayeredDiagnosisReport.model_validate_json(
        canonical_json(value), strict=True
    ).model_dump(mode="json")



__all__ = [
    "GateStatus",
    "LayeredDiagnosisReport",
    "ObjectiveDiagnosisAssessment",
    "ScientificGateResult",
    "ScientificGateSequence",
    "diagnosis_consistency_issues",
    "validate_layered_diagnosis",
]
