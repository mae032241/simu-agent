"""Pure input admission on bounded, explicitly bound bytes; never a submit hook."""
from __future__ import annotations

import hashlib
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any, Callable, Mapping

from scidiscovery.artifact_agent.schema.refs import ArtifactRef
from .spec import CompiledOperation


class OperationInvocationError(ValueError):
    def __init__(self, reason_code: str, *, port: str | None = None, field: str | None = None) -> None:
        self.reason_code = reason_code
        self.port = port
        self.field = field
        super().__init__(f"{reason_code}: {port or 'operation'}{(' ' + field) if field else ''}")

@dataclass(frozen=True, slots=True)
class InputBindingDescriptor:
    source_name: str
    port_name: str
    artifact_ref: ArtifactRef
    media_type: str
    size_bytes: int
    sha256: str
    output_name: str | None = None
    parent_refs: tuple[ArtifactRef, ...] = ()
    labels: tuple[tuple[str, str], ...] = ()


class ValidationSources(dict[str, bytes]):
    """Legacy byte mapping with an immutable projection of exact Run bindings."""

    __slots__ = ("__binding_descriptors", "__validation_deadline")

    def __init__(
        self,
        sources: Mapping[str, bytes],
        binding_descriptors: Mapping[str, InputBindingDescriptor],
        validation_deadline: float | None = None,
    ) -> None:
        super().__init__(sources)
        self.__binding_descriptors = MappingProxyType(dict(binding_descriptors))
        self.__validation_deadline = validation_deadline

    @property
    def binding_descriptors(self) -> Mapping[str, InputBindingDescriptor]:
        return self.__binding_descriptors


    @property
    def validation_deadline(self) -> float | None:
        """Monotonic deadline for optional bounded domain replay; never persisted."""
        return self.__validation_deadline


def read_validation_sources(
    compiled: CompiledOperation,
    inputs: tuple[Any, ...],
    read_artifact: Callable[[ArtifactRef], bytes] | None,
) -> ValidationSources:
    """Budget metadata before any read, then verify exact byte identity."""
    if sum(item.artifact.size_bytes for item in inputs) > compiled.spec.limits.max_input_bytes:
        raise OperationInvocationError("input_total_too_large")
    if read_artifact is None:
        raise OperationInvocationError("input_content_reader_missing")
    contents = {}
    descriptors = {}
    for item in inputs:
        artifact = item.artifact
        try:
            raw = read_artifact(artifact.ref)
        except Exception as error:
            raise OperationInvocationError("input_content_unavailable", port=item.port_name) from error
        if (not isinstance(raw, bytes) or len(raw) != artifact.size_bytes
                or hashlib.sha256(raw).hexdigest() != artifact.ref.sha256):
            raise OperationInvocationError("input_content_integrity_failure", port=item.port_name)
        contents[item.source_name] = raw
        descriptors[item.source_name] = InputBindingDescriptor(
            source_name=item.source_name, port_name=item.port_name,
            artifact_ref=artifact.ref, media_type=artifact.media_type,
            size_bytes=artifact.size_bytes, sha256=artifact.ref.sha256,
            output_name=dict(artifact.labels).get("logical_name"),
            parent_refs=artifact.parent_refs, labels=artifact.labels,
        )
    return ValidationSources(contents, descriptors)


def validate_operation_inputs(compiled: CompiledOperation, sources: ValidationSources) -> None:
    """Execute only the declared input checker; no output or storage authority."""
    validation = compiled.spec.input_validation
    if validation is None:
        return
    reference = validation.validator
    key = f"{reference.plugin_id or compiled.plugin_id}:{reference.component_id}"
    try:
        result = compiled.implementations[key](sources)
        if result is not None:
            raise OperationInvocationError("input_checker_result_invalid")
    except OperationInvocationError:
        raise
    except Exception as error:
        raise OperationInvocationError("input_checker_failed") from error


class BoundSourceError(ValueError):
    """Parsing an already accepted frozen source exposed an admission defect."""


def parse_bound_json(model: Any, raw: bytes, *, strict: bool = True) -> Any:
    from pydantic import ValidationError
    try:
        return model.model_validate_json(raw, strict=strict)
    except (ValidationError, UnicodeError) as error:
        raise BoundSourceError("bound_source_schema_invalid") from error
