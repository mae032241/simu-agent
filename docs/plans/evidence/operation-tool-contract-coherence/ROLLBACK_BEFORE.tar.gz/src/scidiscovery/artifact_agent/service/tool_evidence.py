"""Run-owned, opt-in evidence obtained by registered tools (never mutable inputs)."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
from ...operations.tooling import tool_evidence_ports
from ..schema.artifact import ArtifactRegistration
from ..schema.common import canonical_json
from ..schema.refs import ArtifactRef
from .run_outputs import InputBindingDescriptor, RunCheckerError
from .run_records import RunStateConflict


class ToolEvidenceMixin:
    def tool_evidence(self, run_id: str) -> list[dict]:
        with self._connect() as connection:
            rows = connection.execute("SELECT record_json FROM run_tool_evidence WHERE run_id=? ORDER BY ordinal", (run_id,)).fetchall()
        return [json.loads(row[0]) for row in rows]

    def evidence_sources(self, run_id: str, only_alias: str | None = None):
        contents = {}; descriptors = {}
        for record in self.tool_evidence(run_id):
            if only_alias is not None and record['alias'] != only_alias:
                continue
            ref = ArtifactRef.model_validate(record['artifact_ref'])
            try:
                raw = self.artifacts.read(ref)
                envelope = self.artifacts.catalog(ref)
            except Exception as error:
                raise RunCheckerError('tool evidence is unavailable', category='integrity_failure') from error
            alias = record['alias']
            if hashlib.sha256(raw).hexdigest() != ref.sha256:
                raise RunCheckerError('tool evidence changed', category='integrity_failure')
            contents[alias] = raw
            descriptors[alias] = InputBindingDescriptor(source_name=alias, port_name='tool_evidence', artifact_ref=ref,
                media_type=envelope.media_type, size_bytes=len(raw), sha256=ref.sha256,
                output_name=record['metadata'].get('output_name'))
        return contents, descriptors

    def read_tool_evidence(self, value, alias):
        contents, _ = self.evidence_sources(value.run_id, only_alias=alias)
        if alias in contents:
            return contents[alias]
        # A historical alias is usable only for the same explicitly bound raw Artifact.
        for item in value.inputs:
            if item.port_name != 'recovery_manifest':
                continue
            manifest = json.loads(self.artifacts.read(item.artifact_ref))
            for record in manifest.get('records', ()):
                if record['alias'] != alias:
                    continue
                match = next((i for i in value.inputs if i.port_name == 'solver_outputs'
                              and i.artifact_ref.model_dump(mode='json') == record['artifact_ref']), None)
                if match is not None:
                    raw = self.artifacts.read(match.artifact_ref)
                    if hashlib.sha256(raw).hexdigest() != match.artifact_ref.sha256:
                        raise RunCheckerError('historical evidence changed', category='integrity_failure')
                    return raw
        raise ValueError('unknown controlled evidence alias')

    def accept_tool_evidence(self, run_id: str, *, tool_name: str, allowed_ports: tuple[str, ...],
                             raw: bytes, media_type: str, metadata: dict, source_alias: str = 'execution_result') -> dict:
        value = self._require_running(run_id)
        compiled = self._compiled(value)
        ports = tool_evidence_ports(compiled)
        if 'tool_evidence' not in allowed_ports or 'tool_evidence' not in ports:
            raise ValueError('tool evidence capability is not declared')
        source = next((item for item in value.inputs if item.source_name == source_alias), None)
        if source is None or source.artifact_ref.schema_id != 'scidiscovery.execution-result':
            raise ValueError('tool evidence needs the bound execution result')
        port = ports['tool_evidence']
        if len(raw) > min(port.max_item_bytes, 32 * 1024 * 1024):
            raise ValueError('file_bytes')
        if len(canonical_json(metadata)) > 8192:
            raise ValueError('metadata_bytes')
        key = hashlib.sha256(canonical_json({'sha256':hashlib.sha256(raw).hexdigest(), 'metadata':metadata, 'source':source.artifact_ref.model_dump(mode='json')})).hexdigest()
        with self._connect() as connection:
            connection.execute('BEGIN IMMEDIATE')
            row = self._row(connection, run_id)
            if row['state'] != 'running' or row['accepted_candidate_digest'] is not None:
                raise RunStateConflict('Run no longer accepts tool evidence')
            existing = connection.execute('SELECT record_json FROM run_tool_evidence WHERE run_id=? AND evidence_key=?',(run_id,key)).fetchone()
            if existing:
                return json.loads(existing[0])
            records = [json.loads(r[0]) for r in connection.execute('SELECT record_json FROM run_tool_evidence WHERE run_id=?',(run_id,))]
            if len(records) >= min(port.max_items,32) or sum(r['size_bytes'] for r in records)+len(raw) > min(port.collection.max_total_bytes,256*1024*1024):
                raise ValueError('evidence_budget')
            if metadata.get('output_name') and any(r['metadata'].get('output_name')==metadata['output_name'] for r in records):
                raise ValueError('ambiguous_mapping')
            reserved = {r['alias'] for r in records}
            for item in value.inputs:
                if item.port_name == 'recovery_manifest':
                    reserved.update(r['alias'] for r in json.loads(self.artifacts.read(item.artifact_ref)).get('records', ()))
            ordinal=len(records)+1
            number=ordinal
            while f'tool_evidence_{number:03d}' in reserved:
                number+=1
            alias=f'tool_evidence_{number:03d}'
            artifact=self.artifacts.register(raw,ArtifactRegistration(kind=port.kind,schema_id=port.schema_id,
                payload_schema_version=1,media_type=media_type,creator=self.service_actor,
                parent_refs=tuple(item.artifact_ref for item in value.inputs),
                labels={'operation_id':value.operation_id,'operation_digest':value.operation_digest,'operation_version':value.operation_version,
                        'operation_output_port':'tool_evidence','tool_name':tool_name,'tool_producer_run':run_id,
                        **({'logical_name':metadata['output_name']} if metadata.get('output_name') else {})},confidentiality='run_private'),
                idempotency_key=f'run:{run_id}:tool:{key}').ref
            record={'alias':alias,'artifact_ref':artifact.model_dump(mode='json'),'source_ref':source.artifact_ref.model_dump(mode='json'),
                    'media_type':media_type,'size_bytes':len(raw),'metadata':metadata,'tool_name':tool_name}
            connection.execute('INSERT INTO run_tool_evidence VALUES (?,?,?,?,?)',(run_id,ordinal,key,canonical_json(record),alias))
        self._refresh_evidence_schema(run_id)
        return record

    def _refresh_evidence_schema(self, run_id):
        from .run_assignment import result_schema_json
        value=self.status(run_id); compiled=self._compiled(value)
        workspace=self.backend.open(run_id)
        # The schema is a generated projection, never a replacement for the input bindings.
        mapping = self.validation_source_ports(value)
        schema=result_schema_json(compiled,input_source_ports=mapping)
        from .local_workspace import write_control_workspace_file
        write_control_workspace_file(workspace.root, Path('schema/result.schema.json'), schema, replace=True, mode=0o400)

    def _evidence_snapshot(self, run_id):
        return canonical_json({'schema_version':1,'records':self.tool_evidence(run_id)})

    def _prepare_evidence_snapshot(self, run_id):
        value=self.status(run_id)
        if not tool_evidence_ports(self._compiled(value)):
            return
        workspace=self.backend.open(run_id)
        raw=self._evidence_snapshot(run_id)
        if len(raw)>1024*1024:
            raise RunCheckerError('tool evidence manifest exceeds limit')
        from .local_workspace import write_control_workspace_file
        path=Path('output/tool-evidence.json')
        write_control_workspace_file(workspace.root, path, raw, replace=(workspace.root/path).exists(), mode=0o400)

    def _evidence_manifest(self, value):
        records=self.tool_evidence(value.run_id)
        if not records:
            return None
        compiled=self._compiled(value); port=tool_evidence_ports(compiled)['recovery_manifest_output']
        return self.artifacts.register(self._evidence_snapshot(value.run_id),ArtifactRegistration(
            kind=port.kind,schema_id=port.schema_id,payload_schema_version=1,media_type='application/json',creator=self.service_actor,
            parent_refs=tuple(item.artifact_ref for item in value.inputs)+tuple(ArtifactRef.model_validate(r['artifact_ref']) for r in records),
            labels={'operation_id':value.operation_id,'operation_digest':value.operation_digest,'operation_version':value.operation_version,
                    'operation_output_port':'recovery_manifest_output','tool_producer_run':value.run_id},confidentiality='run_private'),
            idempotency_key=f'run:{value.run_id}:tool-manifest:{hashlib.sha256(self._evidence_snapshot(value.run_id)).hexdigest()}').ref

    def evidence_output_refs(self, value):
        if value.state!='completed' or value.output_ref is None:
            return []
        refs=[(r['alias'],ArtifactRef.model_validate(r['artifact_ref'])) for r in self.tool_evidence(value.run_id)]
        # Read the registered parent rather than rebuilding it with a new installed contract.
        for ref in self.artifacts.catalog(value.output_ref).parent_refs:
            if (ref.schema_id=='scidiscovery.tool-evidence-manifest.v1'
                    and self.artifacts.catalog(ref).labels.get('tool_producer_run') == value.run_id):
                refs.append(('recovery_manifest',ref))
        return refs

    def tool_io_budget(self, run_id, *, used_bytes=0, used_seconds=0.0, reserve=False):
        from datetime import datetime, timezone
        self._require_running(run_id)
        with self._connect() as connection:
            connection.execute('BEGIN IMMEDIATE')
            rows = connection.execute("SELECT activity FROM run_activity WHERE run_id=? AND activity LIKE 'evidence_io:%'", (run_id,)).fetchall()
            consumed_bytes = sum(int(r[0].split(':')[1]) for r in rows)
            consumed_ms = sum(int(r[0].split(':')[2]) for r in rows)
            remaining = {'remaining_bytes': max(0, 256*1024*1024-consumed_bytes),
                         'remaining_seconds': max(0, 120-consumed_ms/1000)}
            if reserve:
                # Reserve before remote I/O. A crashed call conservatively spends its
                # reservation; another process cannot concurrently borrow that budget.
                used_bytes = remaining['remaining_bytes']
                used_seconds = remaining['remaining_seconds']
            if used_bytes or used_seconds:
                connection.execute('INSERT INTO run_activity(run_id,activity,recorded_at,diagnostic_json) VALUES (?,?,?,?)',
                    (run_id, 'evidence_io:%d:%d' % (used_bytes, round(used_seconds*1000)),
                     datetime.now(timezone.utc).isoformat(), None))
        return remaining if reserve else {
            'remaining_bytes': max(0, remaining['remaining_bytes']-used_bytes),
            'remaining_seconds': max(0, remaining['remaining_seconds']-used_seconds)}

    def adopt_tool_evidence(self, run_id):
        value=self.status(run_id)
        if not tool_evidence_ports(self._compiled(value)):
            return
        with self._connect() as connection:
            source_id=value.draft_from_run_id or self._row(connection,run_id)["resume_from_run_id"]
        if not source_id:
            return
        source=self.status(source_id)
        previous=self.tool_evidence(source_id)
        if not previous:
            return
        original=next((i.artifact_ref for i in source.inputs if i.port_name=='execution_result'),None)
        current=next((i.artifact_ref for i in value.inputs if i.port_name=='execution_result'),None)
        if original is None or original!=current or source.instance_id!=value.instance_id:
            raise RunCheckerError('preserved tool evidence belongs to another execution',category='integrity_failure')
        for record in previous:
            ref=ArtifactRef.model_validate(record['artifact_ref'])
            try:
                raw=self.artifacts.read(ref)
            except Exception as error:
                raise RunCheckerError('preserved evidence bytes unavailable', category='integrity_failure') from error
            if hashlib.sha256(raw).hexdigest()!=ref.sha256:
                raise RunCheckerError('preserved evidence bytes changed',category='integrity_failure')
            self.accept_tool_evidence(run_id,tool_name=record['tool_name'],allowed_ports=('tool_evidence',),
                raw=raw,media_type=record['media_type'],metadata=record['metadata'])

    def validation_source_ports(self, value):
        """Expected source wiring comes from bindings/receipts, never descriptors."""
        ports={item.source_name:item.port_name for item in value.inputs}
        records=self.tool_evidence(value.run_id)
        ports.update({r['alias']:'tool_evidence' for r in records})
        if records:
            ports['tool_recovery_manifest']='tool_evidence'
        for item in value.inputs:
            if item.port_name!='recovery_manifest':
                continue
            manifest=json.loads(self.artifacts.read(item.artifact_ref))
            for record in manifest.get('records',()):
                match=next((i for i in value.inputs if i.port_name=='solver_outputs' and i.artifact_ref.model_dump(mode='json')==record['artifact_ref']),None)
                if match is not None:
                    ports[record['alias']]=match.port_name
        return ports
