# 校验职责边界修订计划 R3

日期：2026-09-10。状态：计划修订完成，未实施、未运行测试、未获独立计划复审通过。
本版按 reviews/INPUT_VALIDATION_PHASE_REPAIR_PLAN_R2_INDEPENDENT_REVIEW.zh-CN.md 修复 F1—F4；R2 审查原文快照见 reviews/INPUT_VALIDATION_PHASE_REPAIR_PLAN_R2_REVIEWED_SNAPSHOT.zh-CN.md。本版尚未经独立复审。
本版替代 R1 的“提交重跑输入校验”方案。R1 原文保存在 reviews/INPUT_VALIDATION_PHASE_REPAIR_PLAN_R1_SUPERSEDED.zh-CN.md；原独立根因审查不等于本版计划的审查。

## 第一准则

**preflight 负责输入准入；输出校验只负责输出。框架不得在交付时重新裁决已经接受的输入前提，也不得将自己的准入漏检转嫁给作者。**

输出校验允许读取绑定证据来核对输出，例如输出是否引用正确案例、计算是否与原始数据一致。它不得检查“这些输入本来应不应该被接受”。运行完整性由控制层保护，不归科学输出校验器负责。

此原则适用于当前安装可发现的全部 Operation，不限于 TCAD。目标不是删除身份防护或保证任何输出通过，而是使合法交付可完成、不合法输出能定位纠错、框架故障能够保留交付并返回责任层。

## 1. 责任模型与错误处理

| 责任 | 检查对象与时机 | 拒绝/故障的归属 |
| --- | --- | --- |
| 输入准入 | 创建 Run 前：输入结构、确定性跨文件关系、来源、绑定和准入政策 | 不创建任务，返回稳定输入规则/端口/原因；调度者调整绑定或任务 |
| 输出验收 | 候选输出及其相对冻结证据的真实性、声明的交付格式 | 只有能通过修改输出解决的错误才返回可修拒绝 |
| 运行完整性 | 控制层：冻结文件和绑定被改动、丢失，执行合同无法匹配 | 工程故障，保存交付和恢复记录，不要求改稿 |
| 科学判断 | 科学 Agent 与独立审查 | 证据不足、方法争议、有限结论按已有科学结果/缺口表达，不追加硬前提 |

输入已接受后 current/资格的变化不得变成输出写错；之后的资格授予、晋升或外部执行仍可依法检查其当时所需条件，但不得因此丢弃交付或指责作者。安全取消/撤权沿既有控制机制显式处置，不能隐藏在输出 validator 内。

输入未变却在输出阶段发现原有矛盾，归为 admission_defect。不再运行全套输入 checker 来主动寻找此类矛盾；若输出验证依赖的解析实际暴露了它，报告框架缺陷，保存候选成果，不返回可修输出错误。不自动判定科学通过；修复框架后由新受控 Run 使用恢复材料验证，原 Run 保留失败事实。

## 2. P0：完成当前校验面的职责盘点

实施先从启动编译目录的 all 投影及组件可达关系枚举所有已注册输出 validator、context_validator、语义规则和受控提交入口，同时检查默认及已支持可选插件组合。只读盘点 internal 组件不代表允许调度 internal Operation。

在本计划配套实施证据中建立一张有限迁移表：Operation、规则编号、实现文件/符号、所依赖的数据、模型可见条款、当前执行阶段、正确归属、迁移/保留及验收用例。动态注册实现必须纳入，不能只搜索 TCAD 文件或给一个示例通过。

逐项判别：

- 条件只取决于冻结输入：属于准入；从输出检查移除。
- 条件取决于候选输出如何引用或使用输入：属于输出验收，保留。
- 条件属于字节/存储/绑定完整性：收敛到控制层既有保护。
- 条件要求可选工具、尚未产生的结果、完整总体目标或有争议的科学选择：不能机械前移；转科学审查/有限结果，保留必要的防虚假声明检查。

完成标准：当前可达输出检查均已分类，所有确认的职责越界都有处理项；不得以“以后插件会用新接口”为由保留当前已知越界。无需批量重写正确的 validator。迁移表确定实际改动文件，超出职责修正的功能需求另立任务。

## 3. P1：只在准入路径接入纯输入检查

### 单一声明

在 operations/spec.py 的 OperationSpec 增加可选 input_validation 值对象（validator ComponentRef、稳定 rule_id、模型可见 description）。一个 Operation 一个组合检查函数，不新增规则引擎、独立注册表或状态实体。复用现有 validator 组件注册；operation_declaration.py 传递字段；catalog.py 验证引用与可达组件身份。

输入规则 `(sources) -> None` 只取得显式绑定的受控字节和必要描述符，不取得候选输出、不读取任意存储、不执行副作用。输入异常使用稳定 code/port/field；不使用表示作者可修错误的 SemanticRuleViolation。

输入声明以 input_validation 字段投影，阶段语义为输入准入；不得覆盖现有 SchedulerOperationView.input_admission（InputAdmissionSpec，cohort/批准政策）。输出 validator/语义合同仍投影到 output_validation。在 operations/spec.py::SchedulerOperationView 和 scheduler_operation_view 增加 input_validation 的派生投影，沿 catalog → Root _operation_catalog_item 生成真实目录；operation_contract.py 用同一个规则描述投影 helper 生成 Worker 合同/schema，run_assignment.py 引用它。目录给调度者规则、端口与阶段说明，Worker 给冻结后的同源规则和交付合同，不手写第二份提示。输出组件引用、规则版本和可见合同一起纳入 Run 的冻结身份；不能运行新规则验收旧任务。

单一声明不能数学证明任意 Python 实现符合文本：P0 语义审查和真实交接测试是必需证据，不宣称仅加字段便杜绝语义冲突。

### 调用边界

- operations/invoke.py::preflight_operation 是共享输入准入路径；Root 的 operation_preflight 和 operation_invoke 都通过 _prepare_operation_call 使用它，invoke 不依赖用户先做预检。preflight_operation 只是共享内容/绑定检查层；_prepare_operation_call 随后的 _validate_operation_input_admission 仍独占现有 cohort、approval、claim、review、revision 政策，不将这些政策复制进 schedule。
- RunService.schedule 在任何 Run/工作区持久副作用前，用权威 Artifact 记录执行同一准入检查，覆盖直接服务调用，不能相信手造 BoundOperationCall 的标签。创建边界是准入防绕过，不是提交时的第二道输入门。
- 元数据总预算在读取前检查，真实字节按既有摘要与大小核验。复用读取器和描述符，不新增“已验证”数据库状态或准入 token。
- 新增 operations/input_validation.py 存放共享调用；若共享 ValidationSources/InputBindingDescriptor 会形成导入环，将其移到该低层模块并保留旧导出，不复制类型或另写同义检查。异常定义仅在依赖关系需要时迁移，保持旧导入兼容。

**禁止 validate_run_output、validate_candidate、submit 调用 input_validation。** 不把它以 integrity_recheck 名义重新挂回输出链。

## 4. P2：输出验收与控制层完整性分离

service/run_outputs.py 只运行候选格式、输出语义及相对绑定证据的检查；迁走 P0 确认的纯输入规则。上下文构建可解析冻结证据，但不能暗中重验其准入资格、必需条件或清单合法性。解析问题归框架故障，不能套 $.payload 的可修错误。

service/runs.py::_validation_inputs 复用现有受控读取与精确绑定核验，按冻结引用验证字节/身份是否改变；不调用领域 input_validation，不重新查询当前输入可执行资格。它是运行完整性保护，其错误与输出字段错误分别处理。运行合同不匹配在进入科学验收前显式报告，保留恢复材料。

SemanticRuleViolation/RunOutputError 只表达修改候选能解决的问题；RunCheckerError 表达控制/校验实现故障，提供稳定安全类别以区分 integrity_failure、admission_defect、checker_failure。优先沿用已有异常和 details，不为每个分类建立新异常树。

可修错误继续 rejected/running；框架故障沿现有 failed 与恢复机制结束。validate_candidate 与正式 submit 的故障归属一致，但预览不创建 accepted candidate，不改变成功提交幂等与 CAS。

## 5. P3：先保全交付，再报告框架故障

复用 runs.py::_validated_candidate 中已有 seal、record_failure、_finish_failed_workspace、recovery_candidate_digest/recovery_draft_json。保全候选文件不等于设置 accepted_candidate_digest，也不等于科学输出完成。

确认并补齐以下顺序：在规定输出预算内封存候选；进行完整性/输出验证；若框架故障，保留该候选对应的可恢复文件、失败类别和冻结合同关联，再完成隔离清理。已有封存可用时直接复用，避免故障路径重新快照失败丢失已交付版本。snapshot/discard 异常必须明确显示恢复未完成，不得宣称成果已保存后删除唯一副本。

覆盖无 snapshotter 的一般 Operation 和有 snapshotter 的 author 两条现有路径。通过下述两种严格区分的既有入口扩展将材料绑定给新 Run；Root 不读取未通过科学验收的草稿内容，用户看到的是保存状态与故障摘要。需确认实际接收 Operation 能通过现有恢复路径接手；缺口在同一 P3 补齐最小连接，不新增通用草稿发布服务。

恢复不改原 Run、不复用原科学通过资格、不要求作者再次从头生成。科学证据不足本身仍应尽可能交付有限结果，不作为工程故障处理。

### P3a：同合同 resume 与修复后草稿接续分别处理（F1）

保留 resume_from、validate_resume、_recovery_digest 的精确 Operation digest/全部输入比较，绝不放宽原恢复含义。增加与 resume_from 互斥的可选 draft_from 参数，作为 operation_preflight/operation_invoke 已有请求的受控起始材料绑定，不新增工具。Root 只接受本实例的失败 Run 语义名称，由 _prepare_operation_call 解析来源；请求不得接收任意路径或外来摘要。

新增 validate_draft_source 的窄检查：同实例、同 Operation ID（允许版本/digest 改变）、同 backend 身份与版本、有受控保全文件且摘要可验证。该检查不依赖源 Run 的 _compiled，不要求旧输入与新输入相同。新 Run 的真正科学输入仍全部明确绑定并走新目录完整准入；draft 不是科学证据、不是资格或旧成功结果。原文件内容可能过时，assignment 明示必须根据新输入重新核对，不能继承结论。

Root 的 _agent_call/_agent_invocation_request 及既有请求指纹、RunService.schedule 传递 draft_from：不可变请求包含来源 Run 和由控制读取的 draft_digest；相同名字换来源必须触发冲突或明确修订。runs 表仅追加可空 draft_from_run_id；原 resume_from_run_id 不改含义。run_records.py 和 Root 只投影起始材料来源/可用性，不暴露草稿科学内容。内部关联仍在新 Run 管理。

复用现有 recovery-draft 只读复制、run_assignment 的非证据提示和 author materializer 的 provisional_roots，不另外发布草稿 Artifact。创建时重新核对来源与摘要，在事务内核算次数；_recovery_root_id 与次数查询把 resume/draft 两类边纳入同一无环祖先链，沿用目标 max_attempts，并以原链起点冻结的次数上限约束，防止换绑定或换版本重置预算。旧记录缺冻结上限时仅可在旧匹配合同仍可用时取得原值；否则保留文件并明确报告次数边界不可恢复，不猜新值放行。实例、后端、未知摘要、超限、互斥参数负例都必须覆盖。

### P3b：合同不可用时仍可保全（F2）

RunService.schedule 新建 Run 时冻结最小 recovery_policy_json：Operation 原身份、backend 身份、max_files/max_output_bytes/max_attempts；快照 hook 的既有独立上限如适用也记录。这是失败保全所需的原运行预算，不存完整目录、不新增状态机。使用可空追加列、run_records.py 解析，旧记录不伪造预算。

将 _compiled 的“缺失/版本变化”与一般 RunStateConflict 区分成窄的控制错误（可用 RunStateConflict 子类），submit 和 validate_candidate 只对这一明确原因进入故障保全，不吞掉并发冲突、超时、重复完成或未知提交状态。

合同匹配时沿原 finalizer → seal 路径；已有封存候选先复用。合同不可用时，保全路径只用冻结预算、Run 绑定和 backend 的通用隔离/封存能力，不调用新合同的 finalizer、snapshotter 或 validator。record_failure/_finish_failed_workspace 的此分支不再要求 _compiled 成功。后台操作失败仍保留 CAS 与终态 fencing；已 failed 但未完成隔离的记录可重启补救，不因再次找不到合同直接返回假成功。

旧记录若无冻结预算且旧合同不可获取，禁止猜预算导出、禁止 discard 唯一原件：保留隔离工作区，记录 recovery_pending/明确原因作为现有 failed 的工程恢复信息（不是第五种 Run 状态）。恢复状态只在受控封存成功且摘要可验证后标为 available。seal/discard 故障同样保留原件并报告隔离未完成；后续用匹配旧环境完成保全，或按明确工程修复补足可信材料，再通过 draft_from 接手，不自动扫描任意目录。

故障顺序验收必须分别覆盖：合同查找、finalizer、seal、输入读取、输出 checker、发布及 CAS。前五类按责任保全；输出可修错误不终止；发布/CAS 沿既有幂等对账处理，不能统一当作失败重开。此设计不保证磁盘等基础设施故障时写入必成功，保证不会以保存成功名义清掉唯一交付。


## 6. P4：TCAD 作为首个完整交接案例

result_analysis.py::_identity_context 中只依赖 package/manifest/输入文件的关系检查迁入 validate_analysis_inputs；analysis_context 仅保留输出计划身份、输出引用、计算重放及防止夸大成功的规则。其他 P0 确认的越界按同一原则迁移，不局限本文件。

收集器额外诊断与 manifest 中求解器产品有不同用途。采用可选 diagnostics 输入端口接收现有 tcad_log：0–1 项，受现有总输入预算约束，媒体和声明符合 PortSpec 规则；它的受控父链、execution_id 与逻辑名在准入检查，字节完整性由控制层保证。solver_outputs 仍严格对应 manifest.outputs，放错端口在创建前拒绝，不自动改绑。

复用 ingest_result 已有来源记录，不修改 collector、旧 manifest 或历史 Artifact。诊断可以支持执行诊断，不能冒充已登记数值产品；不可从这条来源边界扩大推导成“禁止分析日志内容或日志中的数字”。具体计算工具仍按自己的实际输入能力调用，不能给所有诊断增加无关的科学禁令。

缺失求解器产物限制可声称的结论，不阻止失败/有限分析交付。评分和 curve contract 保持可选。当前已有产物用于后续验证，无需重跑求解器。

## 7. P5：可恢复且安全的工程可观测性

沿用 run_activity，追加可空 diagnostic_json 保存有界安全摘要；迁移幂等、旧行不改。与 P3 的 draft_from_run_id、recovery_policy_json 追加列统一执行兼容迁移；不再新增重复状态表。只记录类别、稳定 code/rule_id、声明端口/安全静态字段、是否能在本轮改输出解决；不保存任意异常文本、草稿值、堆栈或内部凭据。

Root run_status/run_list 通过同一投影展示最近拒绝、派生拒绝次数、失败类别和既有 recovery 可用状态。次数从活动记录派生，不另存计数真相。输入/完整性/检查器故障使用现有终态 reason 加安全分类，不能显示“请修改输出”。不新增 MCP 工具或状态机。

摘要持久化与活动 CAS 一致；重复完成提交不增加拒绝数。Root 的完整工程日志与 Worker 的详细可修错误保持各自权限，科学未验收内容不随摘要泄漏。

## 8. P6：兼容与资源预算先于发布

- 保存实施前真实编译目录及 Operation 摘要；新增可选字段默认缺省应保持未修改 Operation 的旧规范化表示，不能仅因新增 None 字段使全目录无意义失效。spec.py::_canonical_value 仅对本次新增字段缺省做窄省略，不使用全局 exclude_none 改写既有空字段。影响矩阵包含 catalog 中插件版本、reviewer digest 和 approval provider 的传播闭包。
- 更新实际改动组件和 Operation 身份，禁止伪造旧 digest。只有确定存在 ABI 不兼容才提升全局 ABI；若必须提升，先列出影响矩阵、旧记录可读及可续研路径，不以“实施后遇门禁再说”作为兼容策略。
- 覆盖已完成历史 Run、失败恢复材料、当前 review/package/执行产物和新分析请求。读历史不等于更新资格；真实需要重新审查的记录必须明确列出，不能让兼容问题隐藏到新一轮作者提交。
- 活跃任务不能由新合同验收。部署前处理受影响的 queued/running Run；不新增执行批准、不改 runner 协议和部署探针。core/插件/生成配置作为匹配版本发布与回滚。
- 定向检查单进程串行，不用 xdist、全量套件、压力测试或真实求解器。执行前记录可用内存；测试树总内存预算取 1 GiB 与当时 MemAvailable 的四分之一中的较小值，必须包含子进程，并采用可用的进程组/容器限制。没有可靠限额时先实现监测与停止机制，再运行；限制不足则停止并缩小 fixture，不自动加预算。记录峰值，不沿用 R1 的每进程 8 GiB。

## 9. 必须通过的验收

1. 全校验面盘点无遗漏：动态可达组件均有归属；确认的纯输入条件不再位于输出验收路径。架构调用检查用于阻止再次从提交入口调用 input_validation，但不冒充 Python 语义证明。
2. 合法冻结输入准入后，正确输出可交付；修改候选引用/数值可以准确触发输出错误，修正候选即可通过。
3. input_validation 使用可观测测试替身：在 preflight/创建时运行，在 validate_candidate/submit 时零调用。输入 current/资格变化不导致输出字段拒绝，后续资格动作仍保留正确门禁。
4. 清单错配等坏输入经真实 Root preflight/invoke 及直接 schedule 都在零 Run/工作区时拒绝，规则与模型可见合同一致。
5. 准入后字节损坏、校验器异常及人为注入准入漏检：不是可修输出拒绝；候选在预算内保全，重启可查，受控新 Run 可接续。保存失败必须可见，不伪造 recovery 成功。覆盖旧合同失败 → 新 digest/diagnostics 重绑 → draft_from → Worker 收到旧稿 → 新验收；同合同 resume 的原严格比较保持。另覆盖候选就绪后替换/移除 Operation，submit/预览/显式失败/重启都保留原件；seal/discard 失败和旧预算缺失不删除工作区。
6. 小型生产 collector → ingest_result → execution_outputs → 正式分析创建/提交贯通，包含附加日志、失败执行、缺产物的有限报告；跨执行同字节日志、篡改引用仍拒绝。
7. 当前已确认 test_tcad_result_analysis.py 旧 helper 调用缺 produced 参数随交接 fixture 修正；复用真实 producer/reviewer fixture，不再手造一致的输入掩盖接缝。
8. 选择少量代表性非 TCAD Operation 证明通用机制；其余迁移规则用最小受影响用例验证。源码及真实 wheel/entry point 均覆盖合同投影，旧记录/恢复的兼容矩阵明确通过。真实 Root catalog 必须显示 input_validation，原 input_admission 的 cohort/批准语义不变。
9. CAS、重复提交、故障重启、摘要隐私和总内存预算均满足；不得用全量测试通过替代上述验收。

优先扩展现有 test_tcad_result_analysis、test_analysis_input_descriptors、catalog/installed entrypoint、Run 恢复与 Root 路由测试；不为新增字段存在与函数形状写冗余测试。具体 node id 由 P0 迁移表确定并写入实施证据。

## 10. 执行顺序与完成边界

P0 盘点冻结迁移表 → P1 准入机制 → P2 职责迁移与输出隔离 → P3 成果保全 → P4 真实领域交接及其余确认项迁移 → P5 故障可见 → P6 兼容/资源验证。开发时按依赖运行最小测试，不等到最后才验证。新增源码实施须依本版计划另行推进，本次只修订文档。

发布前必须同时交付迁移表、精确增量 diff、定向测试证据、旧记录影响矩阵和真实交接结果。未迁移已确认越界项、成果恢复不通、旧记录继续受阻，任一存在都不能声称完成框架修复。

不重构全系统，不建设依赖图、规则解释器、新 Run 状态机、另一套资格系统或草稿服务；不删除来源、审查和授权保护。全局的是职责准则与审查覆盖面，代码改动限于确定违反准则之处及使该边界可执行的共享入口。

回滚保留不可变记录与追加活动列，按匹配 core/插件/配置集合处理；新版本活跃任务先终止/完成并保存交付，不让旧版本接管新合同。旧计划与失败记录保留，不能回滚数据库来抹掉研究事件。


## R3 审查意见闭合表

| R2 意见 | 本版修订 | 仍需实施验证 |
| --- | --- | --- |
| F1 跨合同恢复受阻 | P3a：保留严格 resume，显式 draft_from 起始材料，新合同新输入新验收 | 新摘要/端口重绑、次数与实例负例、无资格继承 |
| F2 合同失配阻止保全 | P3b：冻结最小保全预算，合同无关故障分支，无法保全不删原件 | 正式/预览/重启、旧记录及 seal/discard 故障 |
| F3 错误入口与准入归属 | P1：真实 schedule，保留 Root 现有政策权威 | 直接 schedule 坏绑定，Root 两入口一致 |
| F4 目录投影冲突 | P1：scheduler view 显式 input_validation，同源 Worker 投影 | 真 Root 目录/安装入口，既有 input_admission 不变 |

R3 为计划修订，不把上述条目写入等同于实现已通过。跨合同草稿与保全是已确认交付缺口所需的窄扩展；除此不放宽恢复资格，不增加科研阶段。本版仍需独立复审。
