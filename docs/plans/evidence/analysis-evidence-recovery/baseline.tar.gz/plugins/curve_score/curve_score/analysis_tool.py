"""Bounded analysis-time scoring, shared with domain parsers without contracts."""
from __future__ import annotations

import csv
import hashlib
import io
import json
import re
import time
from typing import Any, Mapping, Callable

from pydantic import BaseModel, ConfigDict, Field, ValidationError, model_validator

from scidiscovery.artifact_agent.operation_tool_context import OperationToolContext
from scidiscovery.artifact_agent.schema.common import canonical_json, Identifier
from scidiscovery.artifact_agent.schema.layered_diagnosis import CalculationRecord
from scidiscovery.operation_contract import SemanticRuleViolation
from scidiscovery.operations.tooling import WorkerToolDefinition
from .schema import CurveBundle, CurveComparisonSpec, CurveSeries, evaluate_curve_consistency

ALGORITHM_VERSION = "analysis-curve-operators.v1"
MAX_COMPARISONS = 16
MAX_SAMPLES = 4096
MAX_POINTS = 65536


def check_deadline(deadline: float | None) -> None:
    if deadline is not None and time.monotonic() >= deadline:
        raise TimeoutError("calculation_time_budget")


def admit_raw_lines(raw: bytes, *, max_lines: int = MAX_POINTS + 256) -> None:
    # Count before decode/split or domain parsers allocate per-row Python objects.
    if any(separator in raw for separator in
           (b"\x0b", b"\x0c", b"\x1c", b"\x1d", b"\x1e", b"\xc2\x85", b"\xe2\x80\xa8", b"\xe2\x80\xa9")):
        raise NotImplementedError("source_line_separator_unsupported")
    if raw.count(b"\n") + raw.count(b"\r") - raw.count(b"\r\n") > max_lines:
        raise NotImplementedError("source_line_limit")


class AnalysisScoreInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    record_key: Identifier
    request: dict[str, Any] = Field(description=(
        "Request keys: sources and comparison_spec. sources is a list of explicit mappings. "
        "Bundle mapping: {input_alias: curve_bundle, format: bundle}. CSV mapping requires "
        "input_alias, format=csv, series_key, case_key, role, x_axis, y_axis, x_column, y_column. "
        "Each axis is {name, unit, scale=linear|log10}. TCAD PLX mapping requires "
        "format=sprocess_plx, input_alias, output_name, experiment_key, case_key, series_key, "
        "role, x_axis, y_axis, dataset_name; log format=sprocess_log uses the same fields "
        "except dataset_name. Optional min_points applies to TCAD mappings. No weighting "
        "or arbitrary algorithm options are supported. Unsupported requests return records. "
        "comparison_spec schema (documentation, so unsupported operators remain reportable): "
        + json.dumps(CurveComparisonSpec.model_json_schema(), separators=(",", ":"))
    ))

    @model_validator(mode="after")
    def _request_bound(self):
        if len(canonical_json(self.request)) > 12 * 1024:
            raise ValueError("request exceeds 12 KiB replay limit")
        return self


def _aliases(request: dict[str, Any]) -> tuple[str, ...]:
    mappings = request.get("sources", [])
    if not isinstance(mappings, (list, tuple)) or len(mappings) > 40:
        raise ValueError("source_mapping_limit")
    if any(not isinstance(item, Mapping) or not isinstance(item.get("input_alias"), str) for item in mappings):
        raise ValueError("invalid_input_alias")
    names = tuple(dict.fromkeys(item["input_alias"] for item in mappings))
    if any(not isinstance(name, str) or not name for name in names):
        raise ValueError("invalid_input_alias")
    return names


def _digests(request: dict[str, Any], sources: Mapping[str, bytes], *, deadline: float | None = None) -> dict[str, str]:
    names = _aliases(request)
    digests = {}
    for name in names:
        check_deadline(deadline)
        if name in sources:
            digests[name] = hashlib.sha256(sources[name]).hexdigest()
    return digests


def csv_series(mapping: dict[str, Any], raw: bytes, *, deadline: float | None = None) -> CurveSeries:
    """Read only explicit columns. Original bytes remain the evidence source."""
    if len(raw) > 16 * 1024 * 1024:
        raise ValueError("source_byte_limit")
    check_deadline(deadline)
    admit_raw_lines(raw)
    reader = csv.DictReader(io.StringIO(raw.decode("utf-8-sig")))
    x, y = mapping["x_column"], mapping["y_column"]
    if not reader.fieldnames or len(set(reader.fieldnames)) != len(reader.fieldnames):
        raise ValueError("csv_header_ambiguous")
    if x not in reader.fieldnames or y not in reader.fieldnames:
        raise ValueError("csv_column_missing")
    points = []
    for row in reader:
        check_deadline(deadline)
        if len(points) >= MAX_POINTS:
            raise ValueError("source_point_limit")
        try:
            points.append({"x": float(row[x]), "y": float(row[y])})
        except (ValueError, TypeError) as error:
            raise ValueError("csv_non_numeric_column") from error
    return CurveSeries.model_validate_json(canonical_json({
        **{key: mapping[key] for key in ("series_key", "case_key", "role", "x_axis", "y_axis")},
        "points": points, "availability": {"status": "available", "rationale": "Explicit CSV columns."},
        "source_locator": mapping["input_alias"],
    }), strict=True)


def bundle_from_sources(request: dict[str, Any], sources: Mapping[str, bytes], *, deadline: float | None = None) -> CurveBundle:
    series = []
    for mapping in request["sources"]:
        check_deadline(deadline)
        allowed = {"input_alias", "format"}
        if mapping.get("format") == "csv":
            allowed.update({"series_key", "case_key", "role", "x_axis", "y_axis", "x_column", "y_column"})
        if set(mapping) - allowed:
            raise NotImplementedError("source_options_unsupported")
        raw = sources[mapping["input_alias"]]
        if mapping["format"] == "bundle":
            if len(raw) > 16 * 1024 * 1024:
                raise ValueError("source_byte_limit")
            series.extend(CurveBundle.model_validate_json(raw, strict=True).series)
        elif mapping["format"] == "csv":
            series.append(csv_series(mapping, raw, deadline=deadline))
        else:
            raise NotImplementedError("source_format_unsupported")
        if sum(len(item.points) for item in series) > MAX_POINTS:
            raise ValueError("source_point_limit")
    return CurveBundle(source_profile="analysis_inputs", source_digests=tuple(dict.fromkeys(_digests(request, sources).values())), series=tuple(series))


def evaluate_analysis_request(*, record_key: str, request: dict[str, Any], sources: Mapping[str, bytes], bundle: CurveBundle | None = None, deadline: float | None = None) -> CalculationRecord:
    """Evaluate explicit request; a domain adapter may supply its freshly parsed bundle."""
    AnalysisScoreInput(record_key=record_key, request=request)
    try:
        digests = _digests(request, sources, deadline=deadline)
    except TimeoutError:
        return CalculationRecord(record_key=record_key, request=request, input_digests={},
            algorithm_version=ALGORITHM_VERSION, status="error", reason_code="calculation_time_budget")
    except (ValueError, KeyError, TypeError):
        digests = {}
    base = dict(record_key=record_key, input_digests=digests, request=request, algorithm_version=ALGORITHM_VERSION)
    status, reason, result = "computed", None, None
    try:
        check_deadline(deadline)
        if set(request) != {"sources", "comparison_spec"}:
            raise NotImplementedError("request_options_unsupported")
        aliases = _aliases(request)
        if not aliases or any(name not in sources for name in aliases):
            raise ValueError("bound_source_missing")
        spec_raw = request["comparison_spec"]
        comparisons = spec_raw["comparisons"]
        if len(comparisons) > MAX_COMPARISONS:
            raise NotImplementedError("comparison_limit")
        if any(item.get("evaluation_points", 257) > MAX_SAMPLES or len(item.get("operators", [])) > 16 for item in comparisons):
            raise NotImplementedError("sampling_or_operator_limit")
        spec = CurveComparisonSpec.model_validate_json(canonical_json(spec_raw), strict=True)
        if bundle is None:
            bundle = bundle_from_sources(request, sources, deadline=deadline)
        if sum(len(item.points) for item in bundle.series) > MAX_POINTS:
            raise NotImplementedError("source_point_limit")
        work = sum(item.evaluation_points * len(item.operators) for item in spec.comparisons)
        points_by_key = {item.series_key: len(item.points) for item in bundle.series}
        interpolation_work = sum(item.evaluation_points * len(item.operators) * (points_by_key.get(item.reference_series, 0) + points_by_key.get(item.candidate_series, 0)) for item in spec.comparisons)
        if work > 65536 or interpolation_work > 2_000_000:
            raise NotImplementedError("calculation_work_limit")
        report = evaluate_curve_consistency(bundle, spec, operator_version=ALGORITHM_VERSION, check_budget=lambda: check_deadline(deadline))
        check_deadline(deadline)
        # Keep aggregate/scalar metrics only; crossing samples can be very large.
        result = report.model_dump(mode="json")
        for comparison in result["comparisons"]:
            for metric in comparison["metrics"]:
                metric.pop("crossing_support", None)
        if any(item.status == "unavailable" for item in report.comparisons):
            # Preserve available calculations in a computed partial report; unavailable
            # comparisons keep their evaluator reason codes and no fabricated values.
            if all(item.status == "unavailable" for item in report.comparisons):
                reasons = [metric.reason_code for item in report.comparisons for metric in item.metrics if metric.reason_code is not None]
                status, reason, result = "unavailable", (reasons[0] if reasons else "comparisons_unavailable"), None
        if result is not None and len(canonical_json({**base, "result": result})) > 31 * 1024:
            raise NotImplementedError("record_byte_limit")
    except TimeoutError:
        status, reason, result = "error", "calculation_time_budget", None
    except (ValidationError, NotImplementedError) as error:
        status, reason, result = "unsupported", (str(error) if isinstance(error, NotImplementedError) else "comparison_or_layout_unsupported"), None
    except (ValueError, KeyError, TypeError, AttributeError, UnicodeError, csv.Error) as error:
        message = str(error)
        status, reason, result = "unavailable", (message if re.fullmatch(r"[a-z][a-z0-9_]{0,127}", message) else "input_or_request_invalid"), None
    return CalculationRecord(**base, status=status, result=result, reason_code=reason)


def replay_calculation(record: CalculationRecord, sources: Mapping[str, bytes], *, bundle: CurveBundle | None = None, deadline: float | None = None) -> None:
    try:
        replay_sources = ({key: sources[key] for key in record.input_digests if key in sources}
                          if record.status == "error" else sources)
        digests = _digests(record.request, replay_sources, deadline=deadline)
    except TimeoutError as error:
        raise SemanticRuleViolation("calculation replay budget exhausted; remove this calculation and submit limited analysis") from error
    except (ValueError, KeyError, TypeError):
        digests = {}
    matches = (all(digests.get(name) == digest for name, digest in record.input_digests.items())
               if record.status == "error" else record.input_digests == digests)
    if record.algorithm_version != ALGORITHM_VERSION or not matches:
        raise SemanticRuleViolation("calculation algorithm or exact source bytes differ")
    if record.status == "error":
        if record.result is not None:
            raise SemanticRuleViolation("unfinished calculation cannot supply numeric evidence")
        return
    replay = evaluate_analysis_request(record_key=record.record_key, request=record.request, sources=sources, bundle=bundle, deadline=deadline)
    if replay.status == "error":
        raise SemanticRuleViolation("calculation replay budget exhausted; remove this calculation and submit limited analysis")
    if canonical_json(record) != canonical_json(replay):
        raise SemanticRuleViolation("calculation record differs from deterministic replay")


def run_score_tool(request: AnalysisScoreInput, context: OperationToolContext,
                   evaluate: Callable[..., CalculationRecord]) -> dict[str, Any]:
    deadline = time.monotonic() + context.remaining_seconds / 2
    sources = {}
    try:
        aliases = _aliases(request.request)
    except (ValueError, KeyError, TypeError):
        aliases = ()
    try:
        for name in aliases:
            check_deadline(deadline)
            try:
                sources[name] = context.read_input(name)
            except (KeyError, ValueError):
                continue
        check_deadline(deadline)
        result = evaluate(record_key=request.record_key, request=request.request,
                          sources=sources, deadline=deadline)
        check_deadline(deadline)
    except TimeoutError:
        result = CalculationRecord(record_key=request.record_key, request=request.request,
            input_digests={}, algorithm_version=ALGORITHM_VERSION, status="error",
            reason_code="calculation_time_budget")
    return result.model_dump(mode="json")


def score_tool(request: AnalysisScoreInput, context: OperationToolContext) -> dict[str, Any]:
    return run_score_tool(request, context, evaluate_analysis_request)


CURVE_SCORE_TOOL = WorkerToolDefinition(name="worker_curve_score", description="Optionally score bound bundle/explicit CSV columns with an existing comparison_spec; returns a replayable scalar record. Unsupported metrics are never substituted.", input_model=AnalysisScoreInput, capability="analysis.curve_score", contextual_handler=score_tool)
