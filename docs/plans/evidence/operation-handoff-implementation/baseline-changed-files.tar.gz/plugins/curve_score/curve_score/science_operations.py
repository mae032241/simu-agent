"""Curve-specific diagnosis Operations and components."""

from __future__ import annotations

from typing import Any

from pydantic import ValidationError

from scidiscovery.artifact_agent.schema.common import canonical_json, canonical_sha256
from .analysis_tool import replay_calculation
from .analysis import (
    CurveDiagnosticAnalysisPackage,
    analyze_curve_error,
    failed_residual_analysis_available,
    validate_curve_error_plot_collection,
)
from .curve_contract_compiler import validate_compiled_curve_contract
from .schema import (
    CurveBundle,
    CurveComparisonSpec,
    CurveConsistencyReport,
    CurveExperimentContract,
    validate_curve_experiment_contract,
)
from .transform_adapter import CURVE_SCORE_OPERATION
from scidiscovery.artifact_agent.schema.experiment import (
    ExperimentPortfolio,
    deterministic_validation_check_keys,
)
from scidiscovery.artifact_agent.schema.layered_diagnosis import (
    LayeredDiagnosisReport,
    validate_layered_diagnosis,
)
from scidiscovery.artifact_agent.schema.research_cycle import (
    ScientificReview,
    validate_scientific_review,
)
from scidiscovery.artifact_agent.schema.research_objective import (
    ResearchObjectiveContract,
)
from scidiscovery.operation_declaration import (
    OPERATION_AGENT_PREAMBLE,
    payload_validator,
    schema_resource,
    scientific_semantic_contract,
    scientific_agent_operation,
)
from scidiscovery.operation_contract import SemanticRuleViolation
from scidiscovery.operations.spec import (
    CallableComponent,
    CollectionSpec,
    ComponentRef,
    ComponentSpec,
    ExecutorRef,
    InputPortSpec,
    LimitsSpec,
    OperationDescription,
    OperationSpec,
    OutputPortSpec,
    ReviewSpec,
)


_GENERAL_SCIENCE = "general_science"
_GENERAL_RESOURCES = {
    "opaque_schema",
    "experiment_portfolio_schema",
    "hypothesis_schema",
    "scientific_review_schema",
    "research_objective_schema",
}


def _resource_ref(name: str) -> ComponentRef:
    return ComponentRef(
        name,
        plugin_id=_GENERAL_SCIENCE if name in _GENERAL_RESOURCES else None,
    )


BASE_TOOLS = tuple(
    ComponentRef(name, plugin_id="builtin")
    for name in (
        "file_write_begin_tool",
        "file_write_chunk_tool",
        "file_write_commit_tool",
    )
) + (
    ComponentRef("file_apply_patch_tool", plugin_id="builtin"),
)


_SCHEMA_RESOURCES = {
    "opaque": "opaque_schema",
    "scidiscovery.experiment-portfolio.v1": "experiment_portfolio_schema",
    "scidiscovery.research-objective.v1": "research_objective_schema",
    "scidiscovery.curve-experiment-contract.v1": "curve_contract_schema",
    "scidiscovery.scientific-review.v1": "scientific_review_schema",
    "scidiscovery.curve-consistency-report.v1": "metric_report_schema",
    "scidiscovery.curve-bundle.v1": "curve_bundle_schema",
    "scidiscovery.curve-diagnostic-analysis.v1": "curve_analysis_package_schema",
    "scidiscovery.layered-diagnosis.v1": "diagnosis_schema",
    "scidiscovery.hypothesis-proposal.v2": "hypothesis_schema",
}

_EVIDENCE_PATHS = {
    "scidiscovery.scientific-review.v1": ("/evidence",),
    "scidiscovery.layered-diagnosis.v1": ("/evidence",),
}


def _agent_marker() -> None:
    return None


def _curve_contract_context(
    payload: dict[str, Any], sources: dict[str, bytes], handoff: dict[str, Any]
) -> None:
    del handoff
    contract = CurveExperimentContract.model_validate_json(
        canonical_json(payload), strict=True
    )
    plan = ExperimentPortfolio.model_validate_json(
        sources["experiment_plan"], strict=True
    )
    objective = ResearchObjectiveContract.model_validate_json(
        sources["research_objective"], strict=True
    )
    reference_bundle = CurveBundle.model_validate_json(
        sources["reference_bundle"], strict=True
    )
    validate_compiled_curve_contract(
        contract,
        objective=objective,
        portfolio=plan,
        reference_bundle=reference_bundle,
    )


def _curve_contract_review_context(
    payload: dict[str, Any], sources: dict[str, bytes], handoff: dict[str, Any]
) -> None:
    contract = CurveExperimentContract.model_validate_json(
        sources["curve_contract"], strict=True
    )
    plan = ExperimentPortfolio.model_validate_json(
        sources["experiment_plan"], strict=True
    )
    objective = ResearchObjectiveContract.model_validate_json(
        sources["research_objective"], strict=True
    )
    reference_bundle = CurveBundle.model_validate_json(
        sources["reference_bundle"], strict=True
    )
    validate_compiled_curve_contract(
        contract,
        objective=objective,
        portfolio=plan,
        reference_bundle=reference_bundle,
    )
    review = ScientificReview.model_validate_json(
        canonical_json(payload), strict=True
    )
    if review.review_target != "domain_contract":
        raise SemanticRuleViolation("curve contract review_target must be domain_contract")
    expected_verdict = "blocked" if review.verdict == "reject" else review.verdict
    if handoff.get("verdict") != expected_verdict:
        raise SemanticRuleViolation("curve contract review handoff differs from payload verdict")


def _nonempty(raw: bytes) -> None:
    if not raw:
        raise ValueError("collection item must not be empty")


def _input(
    name: str,
    description: str,
    schema: str,
    *,
    min_items: int = 1,
    max_items: int = 1,
    max_item_bytes: int = 1024 * 1024,
    exposure: str = "full",
    usage: str = "claim_evidence",
) -> InputPortSpec:
    return InputPortSpec(
        name=name,
        description=description,
        schema=schema,
        media_types=("application/json",),
        codec=ComponentRef("json_codec", plugin_id=_GENERAL_SCIENCE),
        schema_resource=_resource_ref(_SCHEMA_RESOURCES[schema]),
        min_items=min_items,
        max_items=max_items,
        max_item_bytes=max_item_bytes,
        exposure=exposure,
        usage=usage,
    )


def _review_input(name: str, description: str) -> InputPortSpec:
    return _input(
        name,
        description,
        "scidiscovery.scientific-review.v1",
        max_item_bytes=64 * 1024,
        exposure="handoff_only",
        usage="prior_signal",
    )


def _output(
    name: str,
    description: str,
    kind: str,
    schema: str,
    validator: ComponentRef,
    *,
    max_item_bytes: int,
    media_types: tuple[str, ...] = ("application/json",),
    min_items: int = 1,
    max_items: int = 1,
    collection: CollectionSpec | None = None,
    context_validator: ComponentRef | None = None,
    context_sources: tuple[str, ...] = (),
    semantic_contract: ComponentRef | None = None,
) -> OutputPortSpec:
    opaque = schema == "opaque"
    contract = semantic_contract or ComponentRef("diagnosis_semantic_contract")
    payload_rule, context_rule = {
        "diagnosis_semantic_contract": (
            "curve.diagnosis.report_consistency", "curve.diagnosis.input_binding"
        ),
        "curve_contract_semantic_contract": (
            "curve.contract.case_metric_closure", "curve.contract.objective_binding"
        ),
        "curve_contract_review_contract": (
            "curve.review.verdict_consistency", "curve.review.subject_binding"
        ),
    }[contract.component_id]
    return OutputPortSpec(
        name=name,
        description=description,
        kind=kind,
        schema=schema,
        media_types=media_types,
        codec=ComponentRef(
            "opaque_codec" if opaque else "json_codec",
            plugin_id=_GENERAL_SCIENCE,
        ),
        schema_resource=_resource_ref(_SCHEMA_RESOURCES[schema]),
        min_items=min_items,
        max_items=max_items,
        max_item_bytes=max_item_bytes,
        validator=validator,
        validator_rule_id=payload_rule,
        semantic_contract=contract,
        collection=collection,
        context_validator=context_validator,
        context_rule_id=context_rule if context_validator else None,
        context_sources=context_sources,
        evidence_paths=_EVIDENCE_PATHS.get(schema, ()),
    )


def _inventory_input(name: str, description: str, *, min_items: int = 0, max_items: int = 4) -> InputPortSpec:
    return InputPortSpec(name=name, description=description, schema="*", media_types=("*/*",),
        codec=ComponentRef("opaque_codec", plugin_id=_GENERAL_SCIENCE),
        schema_resource=ComponentRef("wildcard_schema", plugin_id=_GENERAL_SCIENCE), min_items=min_items,
        max_items=max_items, max_item_bytes=16 * 1024 * 1024,
        exposure="on_demand", usage="evidence_inventory")


def _diagnosis_identity(inputs: tuple[Any, ...], parameters: Any) -> bool:
    del parameters
    by_port: dict[str, list[Any]] = {}
    for item in inputs:
        by_port.setdefault(item.port_name, []).append(item.artifact)
    plan, review = by_port["experiment_plan"][0], by_port["experiment_review"][0]
    if plan.ref not in review.parent_refs or review.handoff_verdict != "pass":
        return False
    # Generic results require explicit direct plan parentage. Runtime package chains
    # belong to the TCAD entry, whose guard checks the complete declared chain.
    return all(plan.ref in item.parent_refs for item in by_port["experiment_results"])


def _diagnosis_operation(operation_id: str, purpose: str, applies_when: str, *, prompt: str) -> OperationSpec:
    return scientific_agent_operation(
        operation_id, purpose, applies_when,
        "Changing evidence, inventing unsupported metrics, or executing experiments.",
        agent=ComponentRef("diagnosis_agent"), workspace=ComponentRef("workspace", plugin_id=_GENERAL_SCIENCE),
        prompt=ComponentRef(prompt), tools=BASE_TOOLS + (ComponentRef("analysis_score_tool"),),
        inputs=(
            _input("experiment_plan", "Exact experiment portfolio.", "scidiscovery.experiment-portfolio.v1", max_item_bytes=2 * 1024 * 1024, usage="prior_signal"),
            _review_input("experiment_review", "Exact independent passing plan review."),
            _inventory_input("experiment_results", "Exact results with direct plan parentage.", min_items=1),
            _inventory_input("reference_material", "Optional reference bytes and explicit tables.", max_items=8),
            _inventory_input("current_progress", "Relevant prior progress and limitations."),
            _input("metric_report", "Optional precomputed metrics, limited to actual coverage.", "scidiscovery.curve-consistency-report.v1", min_items=0, max_item_bytes=2 * 1024 * 1024),
            _input("curve_bundle", "Optional canonical curves.", "scidiscovery.curve-bundle.v1", min_items=0, max_item_bytes=8 * 1024 * 1024),
        ),
        outputs=(_output("layered_diagnosis", "Bounded analysis of exact results with optional calculations.", "layered_diagnosis", "scidiscovery.layered-diagnosis.v1", ComponentRef("diagnosis_validator"),
            max_item_bytes=128 * 1024, context_validator=ComponentRef("diagnosis_context"),
            context_sources=("experiment_plan", "experiment_results", "reference_material", "current_progress", "metric_report", "curve_bundle")),),
        guards=(ComponentRef("diagnosis_identity"),), timeout=900,
        max_input_bytes=272 * 1024 * 1024, max_output_bytes=128 * 1024,
        max_files=1, consequence="scientific",
    ).model_copy(update={"version": "2"})


def _curve_error_diagnosis_operation() -> OperationSpec:
    return scientific_agent_operation(
        "science.result.diagnose.curve-error.v1",
        "Interpret one deterministic curve-error analysis package.",
        "A deterministic curve-error analysis package localizes a failed residual metric.",
        "Recomputing analysis, producing plots, or changing exact scientific inputs.",
        agent=ComponentRef("diagnosis_agent"),
        workspace=ComponentRef("workspace", plugin_id=_GENERAL_SCIENCE),
        prompt=ComponentRef("curve_diagnosis_prompt"),
        tools=BASE_TOOLS,
        inputs=(
            _input(
                "curve_analysis_package",
                "Exact reproducible curve inputs and deterministic error localization.",
                "scidiscovery.curve-diagnostic-analysis.v1",
                max_item_bytes=12 * 1024 * 1024,
                usage="prior_signal",
            ),
        ),
        outputs=(
            _output(
                "layered_diagnosis",
                "Scientific interpretation of the fixed curve-error analysis.",
                "layered_diagnosis",
                "scidiscovery.layered-diagnosis.v1",
                ComponentRef("diagnosis_validator"),
                max_item_bytes=128 * 1024,
                context_validator=ComponentRef("curve_diagnosis_context"),
                context_sources=("curve_analysis_package",),
            ),
        ),
        timeout=900,
        max_input_bytes=12 * 1024 * 1024,
        max_output_bytes=128 * 1024,
        max_files=1,
        consequence="scientific",
    )


CURVE_CONTRACT_PROMPT = """Do not author output/result.json or fill mechanical
CurveExperimentContract fields. Read the exact objective, plan, and reference
bundle, then call worker_curve_contract_compile once with only: the selected
experiment key, the exact objective-target to reference-series bindings, and the
curve-score validation-check keys scientifically belonging to each target; the
candidate case keys that need target-fit curve comparison; and one supported
residual metric expressing the scientific comparison intent. Select targets for
the reviewed current experiment; sharing an observable does not require selecting
every overall objective target. Follow the plan's current objectives and reasons
for deferring others. If a necessary current target cannot be realized, report the
specific gap for redesign instead of silently dropping the current commitment.
Uncovered overall targets remain outstanding; their scientific impact belongs to
design and independent review, not an automatic coverage gate. Do not match checks
to targets by copying or rewriting free-text observable descriptions. The compiler copies
axes and units, calculates support domains and point counts, creates identifiers
and operators, binds each check owned by scidiscovery.curve-score.v1 to every
generated comparison for the same observable,
and writes and validates the complete v1 result. After it returns ready, call
worker_submit_result. Do not treat convergence-only cases as target-fit candidates.
"""

CURVE_CONTRACT_REVIEW_PROMPT = """Return exactly one RoleResultEnvelope whose
payload is the ScientificReview required by output.schema.json. Independently
review the curve-domain contract against the exact generic experiment plan.
Use review_target domain_contract. Check series identity, case binding, units,
domains, operator semantics, exact reference-bundle support, and the exact binding
between every operator and its supported curve check. One check may govern
multiple comparisons for the same observable; verify the metric and threshold on
every binding. Mechanical fields must equal the compiled result. Checks owned by
another evaluator are outside this contract. Compare the selected objective-target
bindings with the plan's current objectives and original research objective.
Assess whether uncovered targets remove a necessary prerequisite, control, or
meaningful interpretation of this experiment. Explain in the formal review why
the current scope can proceed, needs revision, or cannot proceed; neither reject
nor pass solely because overall coverage is incomplete. Preserve the limits of
the resulting conclusions and the outstanding goals. Do not mutate either input or grant
execution approval.
"""


def _curve_contract_operations() -> tuple[OperationSpec, ...]:
    design = scientific_agent_operation(
        "science.curve.contract.design.v1",
        "Realize one generic experiment as an explicit curve-domain contract.",
        "A reviewed generic experiment needs curve data and metric bindings.",
        "Changing generic scientific intent or running a curve evaluator.",
        agent=ComponentRef("curve_contract_agent"),
        workspace=ComponentRef("workspace", plugin_id=_GENERAL_SCIENCE),
        prompt=ComponentRef("curve_contract_prompt"),
        tools=(ComponentRef("curve_contract_compiler_tool"),),
        inputs=(
            _input(
                "research_objective",
                "Exact objective for the scientific plan.",
                "scidiscovery.research-objective.v1",
                max_item_bytes=512 * 1024,
                usage="prior_signal",
            ),
            _input(
                "experiment_plan",
                "Exact generic experiment portfolio.",
                "scidiscovery.experiment-portfolio.v1",
                max_item_bytes=2 * 1024 * 1024,
                usage="prior_signal",
            ),
            _review_input(
                "experiment_review",
                "Exact independent review of the generic experiment plan.",
            ),
            _input(
                "reference_bundle",
                "Exact normalized reference curves used by the contract compiler.",
                "scidiscovery.curve-bundle.v1",
                max_item_bytes=256 * 1024 * 1024,
                usage="evidence_inventory",
            ),
        ),
        outputs=(
            _output(
                "curve_contract",
                "Curve-domain realization of one experiment.",
                "domain_realization",
                "scidiscovery.curve-experiment-contract.v1",
                ComponentRef("curve_contract_validator"),
                max_item_bytes=2 * 1024 * 1024,
                context_validator=ComponentRef("curve_contract_context"),
                context_sources=(
                    "research_objective",
                    "experiment_plan",
                    "reference_bundle",
                ),
                semantic_contract=ComponentRef("curve_contract_semantic_contract"),
            ),
        ),
        timeout=900,
        max_input_bytes=261 * 1024 * 1024,
        max_output_bytes=2 * 1024 * 1024,
        max_files=1,
        review=ReviewSpec(
            reviewer_operation="science.curve.contract.review.v1",
            reviewer_input_port="curve_contract",
            subject_outputs=("curve_contract",),
        ),
    )
    review = scientific_agent_operation(
        "science.curve.contract.review.v1",
        "Independently review a curve-domain contract against its generic plan.",
        "A curve contract needs domain review before deterministic use.",
        "Editing the contract or granting human execution approval.",
        agent=ComponentRef("curve_contract_reviewer"),
        workspace=ComponentRef("workspace", plugin_id=_GENERAL_SCIENCE),
        prompt=ComponentRef("curve_contract_review_prompt"),
        tools=BASE_TOOLS,
        inputs=(
            _input(
                "research_objective",
                "Exact objective for the scientific plan.",
                "scidiscovery.research-objective.v1",
                max_item_bytes=512 * 1024,
                usage="prior_signal",
            ),
            _input(
                "experiment_plan",
                "Exact generic experiment portfolio.",
                "scidiscovery.experiment-portfolio.v1",
                max_item_bytes=2 * 1024 * 1024,
                usage="prior_signal",
            ),
            _review_input(
                "experiment_review",
                "Exact independent review of the generic experiment plan.",
            ),
            _input(
                "curve_contract",
                "Exact curve-domain contract under review.",
                "scidiscovery.curve-experiment-contract.v1",
                max_item_bytes=2 * 1024 * 1024,
                usage="prior_signal",
            ),
            _input(
                "reference_bundle",
                "Exact normalized reference curves used by the compiler.",
                "scidiscovery.curve-bundle.v1",
                max_item_bytes=256 * 1024 * 1024,
                usage="evidence_inventory",
            ),
        ),
        outputs=(
            _output(
                "scientific_review",
                "Independent curve-contract review.",
                "scientific_review",
                "scidiscovery.scientific-review.v1",
                ComponentRef("scientific_review_validator"),
                max_item_bytes=64 * 1024,
                context_validator=ComponentRef("curve_contract_review_context"),
                context_sources=(
                    "research_objective",
                    "experiment_plan",
                    "curve_contract",
                    "reference_bundle",
                ),
                semantic_contract=ComponentRef("curve_contract_review_contract"),
            ),
        ),
        timeout=600,
        max_input_bytes=261 * 1024 * 1024,
        max_output_bytes=64 * 1024,
        max_files=1,
    )
    return design, review


AGENT_OPERATIONS = (
    *_curve_contract_operations(),
    _diagnosis_operation(
        "science.result.diagnose.v1",
        "Analyze exact experiment results with optional deterministic calculations.",
        "Reviewed experiment results are available, including incomplete or failed results.",
        prompt="diagnosis_prompt",
    ),
    _curve_error_diagnosis_operation(),
)


def validate_analysis_report(diagnosis: LayeredDiagnosisReport, portfolio: ExperimentPortfolio, metric_report: CurveConsistencyReport | None = None) -> None:
    plans = tuple(item for item in portfolio.validation_plans if item.experiment_key == diagnosis.experiment_key and item.plan_key == diagnosis.plan_key)
    if len(plans) != 1 or diagnosis.study_kind != portfolio.study_kind:
        raise SemanticRuleViolation("analysis must identify the exact study and validation plan")
    if portfolio.objective_key is not None:
        if diagnosis.objective_assessment is None or diagnosis.objective_assessment.objective_key != portfolio.objective_key:
            raise SemanticRuleViolation("analysis objective differs from plan")
    elif diagnosis.objective_assessment is not None:
        raise SemanticRuleViolation("analysis cannot invent a plan objective key")
    records = {item.record_key: item for item in diagnosis.calculation_records}
    decisive_evidence = {key for gate in (diagnosis.gates.numerical_validity, diagnosis.gates.observation, diagnosis.gates.physical_interpretation) if gate.status == "pass" for key in gate.evidence_keys}
    used_record_keys = {item.locator.split(":", 1)[1] for item in diagnosis.evidence if item.source_key in decisive_evidence and item.locator.startswith("calculation_records:")}
    reports = {}
    planned_checks = {check.check_key: check for dimension in
                      (plans[0].numerical, plans[0].physical, plans[0].experimental)
                      for check in dimension.checks if check.evaluation_mode == "deterministic_threshold"}
    covered_checks = set()
    try:
        for record in records.values():
            if record.status != "computed":
                continue
            report = CurveConsistencyReport.model_validate_json(canonical_json(record.result), strict=True)
            spec = CurveComparisonSpec.model_validate_json(canonical_json(record.request["comparison_spec"]), strict=True)
            reports[record.record_key] = report
            results = {item.comparison_key: item for item in report.comparisons}
            for comparison in spec.comparisons:
                result = results.get(comparison.comparison_key)
                if result is None or result.status != "pass" or record.record_key not in used_record_keys:
                    continue
                passed = {item.operator_key for item in result.checks if item.status == "pass"}
                for operator in comparison.operators:
                    check = planned_checks.get(operator.validation_check_key)
                    if check is None or operator.threshold is None:
                        continue
                    threshold = operator.threshold
                    planned = check.threshold
                    matches = (planned is not None and check.evaluator_metric == operator.kind
                               and planned.operator == ("le" if threshold.comparison == "abs_le" else threshold.comparison)
                               and planned.value == threshold.value and planned.unit == threshold.unit
                               and planned.upper_value is None)
                    if not matches and not diagnosis.method_changes:
                        raise SemanticRuleViolation("changed calculation method requires method_changes; it cannot satisfy the original planned check")
                    if matches and operator.operator_key in passed:
                        covered_checks.add(check.check_key)
    except (ValidationError, KeyError, TypeError, AttributeError) as error:
        raise SemanticRuleViolation("calculation result or request is not a valid bounded curve report") from error
    if metric_report is not None:
        if metric_report.validation_plan_sha256 != canonical_sha256(plans[0]):
            raise SemanticRuleViolation("optional metric report differs from exact validation plan")
        if metric_report.aggregate_status == "pass" and any(item.source_key in decisive_evidence and item.locator.split(":", 1)[0] == "metric_report" for item in diagnosis.evidence):
            covered_checks.update(metric_report.covered_validation_check_keys)
    if diagnosis.overall_verdict == "pass" and not set(deterministic_validation_check_keys(plans[0])).issubset(covered_checks):
        raise SemanticRuleViolation("unperformed required quantitative checks cannot pass")
    for evidence in diagnosis.evidence:
        if evidence.locator.startswith("calculation_records:"):
            key = evidence.locator.split(":", 1)[1]
            if key not in records:
                raise SemanticRuleViolation("analysis references an unknown calculation")
            if records[key].status != "computed":
                for gate in (diagnosis.gates.numerical_validity, diagnosis.gates.observation, diagnosis.gates.physical_interpretation):
                    if gate.status in {"pass", "fail"} and evidence.source_key in gate.evidence_keys:
                        raise SemanticRuleViolation("unfinished calculation cannot support a decisive numeric gate")
    if diagnosis.objective_assessment is not None:
        available = {comparison.comparison_key for report in reports.values() for comparison in report.comparisons if comparison.status in {"pass", "fail"}}
        if metric_report is not None:
            available.update(item.comparison_key for item in metric_report.comparisons if item.status in {"pass", "fail"})
        if not set(diagnosis.objective_assessment.comparison_keys).issubset(available):
            raise SemanticRuleViolation("objective comparison lacks a completed calculation")
        if diagnosis.objective_assessment.status == "pass":
            successful = {item.comparison_key for report in reports.values()
                          for item in report.comparisons if item.status == "pass"}
            if metric_report is not None:
                successful.update(item.comparison_key for item in metric_report.comparisons if item.status == "pass")
            if not set(diagnosis.objective_assessment.comparison_keys).issubset(successful):
                raise SemanticRuleViolation("objective comparison success requires actual passing calculation")


def _diagnosis_context(payload: dict[str, Any], sources: dict[str, bytes], handoff: dict[str, Any]) -> None:
    del handoff
    diagnosis = LayeredDiagnosisReport.model_validate_json(canonical_json(payload), strict=True)
    portfolio = ExperimentPortfolio.model_validate_json(sources["experiment_plan"], strict=True)
    for record in diagnosis.calculation_records:
        replay_calculation(record, sources, deadline=getattr(sources, "validation_deadline", None))
    metric_report = CurveConsistencyReport.model_validate_json(sources["metric_report"], strict=True) if "metric_report" in sources else None
    validate_analysis_report(diagnosis, portfolio, metric_report)
    # Every evidence locator identifies a bound input or a replayed calculation.
    for evidence in diagnosis.evidence:
        alias = evidence.locator.split(":", 1)[0]
        if alias != "calculation_records" and alias not in sources:
            raise SemanticRuleViolation("analysis evidence locator is not a bound input")


def _curve_diagnosis_context(
    payload: dict[str, Any], sources: dict[str, bytes], handoff: dict[str, Any]
) -> None:
    del handoff
    if set(sources) != {"curve_analysis_package"}:
        raise SemanticRuleViolation("curve-error diagnosis requires one exact analysis package")
    package = CurveDiagnosticAnalysisPackage.model_validate_json(
        sources["curve_analysis_package"], strict=True
    )
    diagnosis = LayeredDiagnosisReport.model_validate_json(
        canonical_json(payload), strict=True
    )
    _validate_diagnosis_against(
        diagnosis,
        package.experiment_plan,
        package.curve_contract,
        package.metric_report,
    )


def _validate_diagnosis_against(
    diagnosis: LayeredDiagnosisReport,
    portfolio: ExperimentPortfolio,
    contract: CurveExperimentContract,
    metric_report: CurveConsistencyReport,
) -> None:
    covered_curve_checks = validate_curve_experiment_contract(
        contract,
        portfolio,
        expected_evaluator_profile=CURVE_SCORE_OPERATION,
    )
    if portfolio.objective_key is None:
        if diagnosis.objective_assessment is not None:
            raise SemanticRuleViolation(
                "objective_assessment is not admissible without plan objective_key"
            )
    else:
        assessment = diagnosis.objective_assessment
        if assessment is None or assessment.objective_key != portfolio.objective_key:
            raise SemanticRuleViolation("diagnosis objective assessment differs from the plan")
        comparisons = tuple(
            item
            for item in metric_report.comparisons
            if item.gate_scope == "objective" and item.purpose == "target_fit"
        )
        if assessment.comparison_keys != tuple(
            item.comparison_key for item in comparisons
        ):
            raise SemanticRuleViolation(
                "objective_assessment must name the exact target-fit comparisons"
            )
        if diagnosis.gates.prerequisite_status == "invalid":
            expected_status = "not_evaluable"
        else:
            statuses = {item.status for item in comparisons if item.required}
            expected_status = (
                "fail"
                if "fail" in statuses
                else "inconclusive"
                if not statuses or statuses & {"unavailable", "inconclusive"}
                else "pass"
            )
        if assessment.status != expected_status:
            raise SemanticRuleViolation(
                "objective assessment status differs from exact target-fit metrics"
            )
    plans = tuple(
        plan
        for plan in portfolio.validation_plans
        if plan.experiment_key == diagnosis.experiment_key
        and plan.plan_key == diagnosis.plan_key
    )
    if len(plans) != 1:
        raise SemanticRuleViolation("diagnosis does not name one exact validation plan")
    plan = plans[0]
    if metric_report.validation_scope != "complete_plan":
        raise SemanticRuleViolation("diagnosis requires a complete-plan metric report")
    if metric_report.validation_plan_sha256 != canonical_sha256(plan):
        raise SemanticRuleViolation("metric report validation-plan digest differs")
    if metric_report.covered_validation_check_keys != covered_curve_checks:
        raise SemanticRuleViolation(
            "metric report does not cover the exact curve-contract checks"
        )
    uncovered_checks = set(deterministic_validation_check_keys(plan)) - set(
        covered_curve_checks
    )
    if uncovered_checks and diagnosis.overall_verdict == "pass":
        raise SemanticRuleViolation(
            "curve-only diagnosis cannot pass an experiment with uncovered checks"
        )


def _curve_error_analysis(
    values: dict[str, tuple[bytes, ...]],
) -> dict[str, tuple[bytes, ...]]:
    required = (
        "experiment_plan",
        "experiment_review",
        "curve_contract",
        "curve_contract_review",
        "metric_report",
        "curve_bundle",
    )
    if set(values) != set(required) or any(len(values[name]) != 1 for name in required):
        raise ValueError("curve error analysis inputs violate their cardinality")
    portfolio = ExperimentPortfolio.model_validate_json(
        values["experiment_plan"][0], strict=True
    )
    contract = CurveExperimentContract.model_validate_json(
        values["curve_contract"][0], strict=True
    )
    metric_report = CurveConsistencyReport.model_validate_json(
        values["metric_report"][0], strict=True
    )
    bundle = CurveBundle.model_validate_json(values["curve_bundle"][0], strict=True)
    artifacts = analyze_curve_error(portfolio, contract, metric_report, bundle)
    package = CurveDiagnosticAnalysisPackage(
        experiment_plan=portfolio,
        curve_contract=contract,
        metric_report=metric_report,
        curve_bundle=bundle,
        curve_analysis=artifacts.report,
    )
    plots = dict(artifacts.plots)
    if sum(len(content) for content in plots.values()) > 8 * 1024 * 1024:
        raise ValueError("curve analysis plot collection exceeds its declared limit")
    validate_curve_error_plot_collection(
        package.model_dump(mode="json"), plots
    )
    return {
        "curve_analysis_package": (package.canonical_json(),),
        "curve_analysis_plots": tuple(plots.values()),
    }


DIAGNOSIS_PROMPT = """Return one RoleResultEnvelope with LayeredDiagnosisReport payload.
Analyze the exact plan and bound results, including failures and missing observations.
Scoring is optional: worker_curve_score accepts explicit sources and comparison_spec.
Do not invent metric implementations, replace unsupported statistics with RMS, or
change methods after seeing results without recording analysis_method and method_changes.
Include only calculation records used in the report (at most eight, aggregate 96 KiB).
Use evidence locator input_alias:detail for read inputs, or calculation_records:record_key
for calculations. Unavailable/unsupported/error records cannot support numeric success.
No score is a normal path: report valid findings, missing conditions, current objective
limits, remaining overall targets, and next steps. Preserve ordered gates: invalid
prerequisites imply invalid_study; missing observations may imply inconclusive.
A partial metric pass does not establish unperformed comparisons or overall closure.
Link computed operators to the selected plan using exact validation_check_key values,
and cite their calculation_records:record_key from the relevant gate evidence.
Required quantitative checks cannot pass solely because some calculation exists.
The optional curve-error helper is never a required next stage.
"""


class Resources:
    diagnosis_schema = schema_resource(
        LayeredDiagnosisReport, "scidiscovery.layered-diagnosis.v1"
    )
    curve_analysis_package_schema = schema_resource(
        CurveDiagnosticAnalysisPackage,
        "scidiscovery.curve-diagnostic-analysis.v1",
    )
    diagnosis_semantic_contract = scientific_semantic_contract(
        "curve.diagnosis",
        "Bind analysis to the exact plan, results, evidence and optional calculations.",
        "Report findings and limitations; replay used calculations without forcing scoring.",
        payload_rule_id="curve.diagnosis.report_consistency",
        context_rule_id="curve.diagnosis.input_binding",
    )
    curve_contract_semantic_contract = scientific_semantic_contract(
        "curve.contract",
        "Realize curve data and metric bindings without changing the generic experiment.",
        (
            "Every bound threshold and case must match the supplied experiment "
            "plan; checks owned by another evaluator remain unbound. Select the "
            "current target subset from the exact objective, without requiring "
            "all targets that share an observable."
        ),
        required_inputs=(
            "research_objective",
            "experiment_plan",
            "reference_bundle",
        ),
        payload_constraint=(
            "Mechanical series, axes, domains, counts, identifiers, operators, and "
            "thresholds must equal the deterministic compiler output."
        ),
        context_constraint=(
            "Objective, case, reference-series, metric, and threshold identities must "
            "match the exact objective, experiment plan, and reference bundle. "
            "Each selected target must exist in the original objective and its "
            "observable must belong to the selected experiment. Unselected targets "
            "remain outstanding; scientific review assesses their impact."
        ),
        payload_rule_id="curve.contract.case_metric_closure",
        context_rule_id="curve.contract.objective_binding",
    )
    curve_contract_review_contract = scientific_semantic_contract(
        "curve.review",
        "Review the complete curve contract independently without mutating it.",
        "The verdict is scientific review, not human approval.",
        required_inputs=(
            "research_objective",
            "experiment_plan",
            "curve_contract",
            "reference_bundle",
        ),
        context_constraint=(
            "The review must bind the exact research objective, experiment plan, and "
            "compiled curve contract and reference bundle. Assess whether any "
            "uncovered objective target prevents the current experiment from "
            "proceeding, and explain that judgment in the formal review."
        ),
        payload_rule_id="curve.review.verdict_consistency",
        context_rule_id="curve.review.subject_binding",
    )
    curve_contract_prompt = OPERATION_AGENT_PREAMBLE + CURVE_CONTRACT_PROMPT
    curve_contract_review_prompt = (
        OPERATION_AGENT_PREAMBLE + CURVE_CONTRACT_REVIEW_PROMPT
    )
    diagnosis_prompt = OPERATION_AGENT_PREAMBLE + DIAGNOSIS_PROMPT
    curve_diagnosis_prompt = OPERATION_AGENT_PREAMBLE + """Return exactly one
RoleResultEnvelope whose payload is the LayeredDiagnosisReport required by
output.schema.json. Interpret the supplied immutable curve-analysis package,
stopping at the earliest failed prerequisite. The package's metric values,
localized residuals, and plot identities are deterministic facts: do not
recompute or alter them. Do not mutate evidence or author state transitions.
"""


class Components:
    diagnosis_identity = CallableComponent("guard", _diagnosis_identity)
    diagnosis_validator = CallableComponent(
        "validator", payload_validator(validate_layered_diagnosis)
    )
    diagnosis_context = CallableComponent("validator", _diagnosis_context)
    curve_diagnosis_context = CallableComponent(
        "validator", _curve_diagnosis_context
    )
    curve_analysis_package_validator = CallableComponent(
        "validator",
        lambda raw: CurveDiagnosticAnalysisPackage.model_validate_json(
            raw, strict=True
        ),
    )
    diagnosis_agent = CallableComponent("agent", _agent_marker)
    curve_contract_agent = CallableComponent("agent", _agent_marker)
    curve_contract_reviewer = CallableComponent("agent", _agent_marker)
    curve_contract_context = CallableComponent("validator", _curve_contract_context)
    curve_contract_review_context = CallableComponent(
        "validator", _curve_contract_review_context
    )
    scientific_review_validator = CallableComponent(
        "validator", payload_validator(validate_scientific_review)
    )
    curve_error_analysis = CallableComponent("transform", _curve_error_analysis)


def _curve_error_analysis_operation() -> OperationSpec:
    return OperationSpec(
        operation_id="science.curve.error.analyze.v1",
        version="1",
        catalog_scope="support",
        description=OperationDescription(
            purpose="Reproduce failed residual metrics and localize their curve error.",
            applies_when="A reviewed curve contract, complete metric report, and exact curve bundle are available.",
            not_for="Authoring scientific diagnoses or proposing the next experiment.",
        ),
        executor=ExecutorRef(
            kind="transform",
            component=ComponentRef("curve_error_analysis"),
        ),
        inputs=(
            _input(
                "experiment_plan",
                "Exact experiment portfolio.",
                "scidiscovery.experiment-portfolio.v1",
                max_item_bytes=2 * 1024 * 1024,
                usage="prior_signal",
            ),
            _input(
                "experiment_review",
                "Exact independent plan review.",
                "scidiscovery.scientific-review.v1",
                max_item_bytes=64 * 1024,
                exposure="handoff_only",
                usage="prior_signal",
            ),
            _input(
                "curve_contract",
                "Exact reviewed curve-domain contract.",
                "scidiscovery.curve-experiment-contract.v1",
                max_item_bytes=2 * 1024 * 1024,
                usage="prior_signal",
            ),
            _review_input(
                "curve_contract_review",
                "Exact independent review of the curve-domain contract.",
            ),
            _input(
                "metric_report",
                "Exact deterministic curve comparison report.",
                "scidiscovery.curve-consistency-report.v1",
                max_item_bytes=2 * 1024 * 1024,
            ),
            _input(
                "curve_bundle",
                "Canonical curve bundle for residual localization.",
                "scidiscovery.curve-bundle.v1",
                max_item_bytes=8 * 1024 * 1024,
            ),
        ),
        outputs=(
            _output(
                "curve_analysis_package",
                "Exact inputs and reproducible deterministic curve-error analysis.",
                "curve_diagnostic_analysis",
                "scidiscovery.curve-diagnostic-analysis.v1",
                ComponentRef("curve_analysis_package_validator"),
                max_item_bytes=12 * 1024 * 1024,
                semantic_contract=ComponentRef("diagnosis_semantic_contract"),
            ),
            _output(
                "curve_analysis_plots",
                "Deterministic residual plots bound to the analysis package.",
                "curve_error_plot",
                "opaque",
                ComponentRef("nonempty_validator"),
                max_item_bytes=1024 * 1024,
                media_types=("image/png",),
                min_items=1,
                max_items=8,
                collection=CollectionSpec(
                    max_total_bytes=8 * 1024 * 1024,
                ),
            ),
        ),
        consequence="scientific",
        limits=LimitsSpec(
            timeout_seconds=120,
            max_input_bytes=12 * 1024 * 1024,
            max_output_bytes=20 * 1024 * 1024,
            max_files=9,
        ),
    )


TRANSFORM_OPERATIONS = (
    _curve_error_analysis_operation(),
)


def component_specs() -> tuple[ComponentSpec, ...]:
    values = [
        ComponentSpec("diagnosis_identity", "guard", "curve_score.science_operations:Components.diagnosis_identity"),
        ComponentSpec("analysis_score_tool", "worker_tool", "curve_score.analysis_tool:CURVE_SCORE_TOOL"),
        ComponentSpec(
            "diagnosis_validator",
            "validator",
            "curve_score.science_operations:Components.diagnosis_validator",
            resources=(ComponentRef("diagnosis_semantic_contract"),),
        ),
        ComponentSpec(
            "diagnosis_context",
            "validator",
            "curve_score.science_operations:Components.diagnosis_context",
            resources=(ComponentRef("diagnosis_semantic_contract"),),
        ),
        ComponentSpec(
            "curve_diagnosis_context",
            "validator",
            "curve_score.science_operations:Components.curve_diagnosis_context",
            resources=(ComponentRef("diagnosis_semantic_contract"),),
        ),
        ComponentSpec(
            "curve_analysis_package_validator",
            "validator",
            "curve_score.science_operations:Components.curve_analysis_package_validator",
            resources=(ComponentRef("diagnosis_semantic_contract"),),
        ),
        ComponentSpec(
            "diagnosis_agent",
            "agent",
            "curve_score.science_operations:Components.diagnosis_agent",
        ),
        ComponentSpec(
            "curve_contract_agent",
            "agent",
            "curve_score.science_operations:Components.curve_contract_agent",
        ),
        ComponentSpec(
            "curve_contract_reviewer",
            "agent",
            "curve_score.science_operations:Components.curve_contract_reviewer",
        ),
        ComponentSpec(
            "curve_contract_compiler_tool",
            "worker_tool",
            "curve_score.curve_contract_compiler:CURVE_CONTRACT_COMPILER_TOOL",
        ),
        ComponentSpec(
            "curve_contract_context",
            "validator",
            "curve_score.science_operations:Components.curve_contract_context",
            resources=(ComponentRef("curve_contract_semantic_contract"),),
        ),
        ComponentSpec(
            "curve_contract_review_context",
            "validator",
            "curve_score.science_operations:Components.curve_contract_review_context",
            resources=(ComponentRef("curve_contract_review_contract"),),
        ),
        ComponentSpec(
            "scientific_review_validator",
            "validator",
            "curve_score.science_operations:Components.scientific_review_validator",
            resources=(ComponentRef("curve_contract_review_contract"),),
        ),
        ComponentSpec(
            "curve_error_analysis",
            "transform",
            "curve_score.science_operations:Components.curve_error_analysis",
            configuration_identity="curve-error-analysis:v1",
        ),
        ComponentSpec(
            "nonempty_validator",
            "validator",
            "curve_score.science_operations:_NONEMPTY_COMPONENT",
            resources=(ComponentRef("diagnosis_semantic_contract"),),
        ),
    ]
    for name in (
        "diagnosis_schema",
        "curve_analysis_package_schema",
        "diagnosis_semantic_contract",
        "diagnosis_prompt",
        "curve_diagnosis_prompt",
        "curve_contract_semantic_contract",
        "curve_contract_review_contract",
        "curve_contract_prompt",
        "curve_contract_review_prompt",
    ):
        values.append(
            ComponentSpec(
                name,
                "resource",
                f"curve_score.science_operations:Resources.{name}",
                public=name == "diagnosis_schema",
            )
        )
    return tuple(values)


_NONEMPTY_COMPONENT = CallableComponent("validator", _nonempty)
COMPONENT_SPECS = component_specs()
OPERATIONS = AGENT_OPERATIONS + TRANSFORM_OPERATIONS

__all__ = ["COMPONENT_SPECS", "OPERATIONS"]
