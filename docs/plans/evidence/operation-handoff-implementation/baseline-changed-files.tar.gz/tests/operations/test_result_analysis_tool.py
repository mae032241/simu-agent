from __future__ import annotations

from copy import deepcopy
import hashlib
import runpy
from pathlib import Path

import pytest

from curve_score.analysis_tool import AnalysisScoreInput, evaluate_analysis_request, replay_calculation
from curve_score.science_operations import Components
from curve_score.plugin import PLUGIN
from scidiscovery.artifact_agent.schema.common import canonical_json
from scidiscovery.artifact_agent.schema.layered_diagnosis import CalculationRecord
from scidiscovery.artifact_agent.schema.refs import ArtifactRef
from scidiscovery.builtin_plugin import CORE_PLUGIN
from scidiscovery.general_science_plugin import PLUGIN as GENERAL
from scidiscovery.operations.catalog import compile_catalog
from scidiscovery.operations.invoke import InvocationArtifact, OperationInvocationError, preflight_operation
from scidiscovery.operation_contract import SemanticRuleViolation

_FIXTURES = runpy.run_path(str(Path(__file__).with_name('test_m2_curve_analysis_boundary.py')))


def score_inputs():
    return {'curve_bundle': _FIXTURES['_bundle']().canonical_json()}, {'sources': [{'input_alias': 'curve_bundle', 'format': 'bundle'}], 'comparison_spec': _FIXTURES['_contract']().comparison_spec.model_dump(mode='json')}


def limited_report():
    report = _FIXTURES['_diagnosis']().model_dump(mode='json')
    report['evidence'][0].update(source_key='experiment_results', locator='experiment_results:failure', title='Bound result failure')
    for gate in report['gates'].values():
        if isinstance(gate, dict) and gate.get('evidence_keys'):
            gate['evidence_keys'] = ['experiment_results']
    report['summary'] = 'Execution ended before the requested observable was saved.'
    report['gates']['numerical_validity']['summary'] = 'The execution failed; quantitative validity cannot be established.'
    report['remaining_contradiction'] = 'The planned comparison remains unperformed because its output is missing.'
    report['next_action'] = 'Resolve the execution failure and preserve the required observable before comparison.'
    return report


def test_generic_score_replays_exact_values_without_contract():
    sources, request = score_inputs()
    record = evaluate_analysis_request(record_key='score', request=request, sources=sources)
    assert record.status == 'computed'
    replay_calculation(record, sources)
    raw = record.model_dump(mode='json')
    raw['result']['comparisons'][0]['metrics'][0]['value'] += 1
    with pytest.raises(SemanticRuleViolation, match='replay'):
        replay_calculation(CalculationRecord.model_validate_json(canonical_json(raw)), sources)
    with pytest.raises(SemanticRuleViolation, match='source bytes'):
        replay_calculation(record, {'curve_bundle': sources['curve_bundle'] + b' '})


@pytest.mark.parametrize('change', ['metric', 'exploration', 'samples', 'work'])
def test_unsupported_requests_are_explicit_replayable(change):
    sources, request = score_inputs()
    comparison = request['comparison_spec']['comparisons'][0]
    if change == 'metric':
        comparison['operators'][0]['kind'] = 'raw_row_group_weighted_rms'
    elif change == 'exploration':
        comparison['required'] = False
    elif change == 'samples':
        comparison['evaluation_points'] = 4097
    else:
        comparison['evaluation_points'] = 4096
        comparison['operators'] = [{**comparison['operators'][0], 'operator_key': f'op_{i}'} for i in range(17)]
    record = evaluate_analysis_request(record_key='unsupported', request=request, sources=sources)
    assert record.status == 'unsupported' and record.result is None
    replay_calculation(record, sources)


@pytest.mark.parametrize('mappings', [[{'format': 'bundle'}], [{'input_alias': 'absent', 'format': 'bundle'}], []])
def test_missing_or_malformed_sources_return_bounded_unavailable(mappings):
    sources, request = score_inputs()
    request['sources'] = mappings
    record = evaluate_analysis_request(record_key='missing', request=request, sources=sources)
    assert record.status == 'unavailable'
    replay_calculation(record, sources)
    assert len(record.canonical_json()) < 32768


def test_request_byte_admission_precedes_calculation():
    with pytest.raises(ValueError, match='12 KiB'):
        AnalysisScoreInput(record_key='oversize', request={'unbounded': 'x' * 13000})


def test_csv_columns_preserve_explicit_identity_and_missing_column_reason():
    bundle = _FIXTURES['_bundle']()
    sources, request = {}, score_inputs()[1]
    request['sources'] = []
    for item in bundle.series:
        alias = item.series_key
        sources[alias] = ('depth,value,extra\n' + ''.join(f'{point.x},{point.y},kept\n' for point in item.points)).encode()
        request['sources'].append({'input_alias': alias, 'format': 'csv', 'series_key': item.series_key, 'case_key': item.case_key, 'role': item.role, 'x_axis': item.x_axis.model_dump(mode='json'), 'y_axis': item.y_axis.model_dump(mode='json'), 'x_column': 'depth', 'y_column': 'value'})
    record = evaluate_analysis_request(record_key='csv', request=request, sources=sources)
    assert record.status == 'computed'
    assert all(record.input_digests[key] == hashlib.sha256(raw).hexdigest() for key, raw in sources.items())
    replay_calculation(record, sources)
    request['sources'][0]['y_column'] = 'absent'
    missing = evaluate_analysis_request(record_key='missing', request=request, sources=sources)
    assert missing.status == 'unavailable'
    replay_calculation(missing, sources)


def test_error_has_no_numeric_result_and_is_not_required_to_recur():
    sources, request = score_inputs()
    good = evaluate_analysis_request(record_key='error', request=request, sources=sources)
    record = CalculationRecord(**{**good.model_dump(mode='json'), 'status': 'error', 'result': None, 'reason_code': 'timeout'})
    replay_calculation(record, sources)
    with pytest.raises(ValueError, match='no numeric result'):
        CalculationRecord(**{**record.model_dump(mode='json'), 'result': {'value': 1}})


def test_no_score_limited_analysis_uses_actual_bound_results():
    Components.diagnosis_context.implementation(limited_report(), {'experiment_plan': _FIXTURES['_plan']().canonical_json(), 'experiment_results': b'Execution failed before observable output.'}, {})


def test_generic_compiled_preflight_accepts_no_score_and_rejects_wrong_round():
    compiled = compile_catalog((CORE_PLUGIN, GENERAL, PLUGIN)).operation('science.result.diagnose.v1')
    assert compiled.spec.version == '2'
    assert 'curve_contract' not in {item.name for item in compiled.spec.inputs}
    def artifact(name, schema, parents=(), verdict=None):
        return InvocationArtifact(artifact_name=name, ref=ArtifactRef(artifact_id='art_' + name, sha256='0' * 64, kind='fixture', schema_id=schema), schema_id=schema, media_type='application/json', size_bytes=2, parent_refs=parents, handoff_verdict=verdict)
    plan = artifact('plan', 'scidiscovery.experiment-portfolio.v1')
    review = artifact('review', 'scidiscovery.scientific-review.v1', (plan.ref,), 'pass')
    result = artifact('result', 'opaque', (plan.ref,))
    inputs = {**{item.name: () for item in compiled.spec.inputs}, 'experiment_plan': (plan,), 'experiment_review': (review,), 'experiment_results': (result,)}
    preflight_operation(compiled, name='analysis', artifacts_by_port=inputs, instruction='Analyze available evidence.')
    for port in ('experiment_results', 'experiment_review'):
        from dataclasses import replace
        invalid = {**inputs, port: (replace(inputs[port][0], parent_refs=()),)}
        with pytest.raises(OperationInvocationError, match='guard_rejected'):
            preflight_operation(compiled, name='wrong_round', artifacts_by_port=invalid, instruction='Analyze.')


def test_near_bound_records_replay_cumulatively():
    sources, request = score_inputs()
    request['comparison_spec']['comparisons'][0]['evaluation_points'] = 4096
    records = [evaluate_analysis_request(record_key=f'score_{i}', request=request, sources=sources) for i in range(8)]
    assert all(item.status == 'computed' for item in records)
    for record in records:
        replay_calculation(record, sources)
    report = limited_report()
    report['calculation_records'] = [item.model_dump(mode='json') for item in records]
    Components.diagnosis_context.implementation(report, {'experiment_plan': _FIXTURES['_plan']().canonical_json(), 'experiment_results': b'failure', **sources}, {})


def test_no_score_real_review_worker_submit_then_next_design_reads_sealed_report(tmp_path, monkeypatch):
    from scidiscovery.artifact_agent.interfaces.mcp_local_worker import LocalWorkerMCPRouter
    from scidiscovery.artifact_agent.schema.artifact import ArtifactRegistration
    catalog = compile_catalog((CORE_PLUGIN, GENERAL, PLUGIN))
    runtime, instance, root = runpy.run_path(str(Path(__file__).with_name('test_general_transform_operations.py')))['_root'](tmp_path, catalog=catalog)
    runtime.runs.operation_catalog = catalog

    def register(name, schema, raw, parents=()):
        item = runtime.artifacts.register(raw, ArtifactRegistration(kind='fixture', schema_id=schema, payload_schema_version=1, media_type='application/json', creator=runtime.actor, parent_refs=parents, labels={'scientific_claim_admissible': 'true'}), idempotency_key='analysis:' + name)
        runtime.scheduler_bindings.bind(instance=instance.instance_id, namespace='artifact', name=name, object_id=item.artifact_id)
        return item

    def invoke_worker(name, operation_id, inputs):
        request = {'name': name, 'operation_id': operation_id, 'inputs': [{'port': key, 'artifact_names': [value]} for key, value in inputs.items()], 'instruction': 'Analyze only the supplied fixture evidence.'}
        assert root.call_tool('operation_preflight', request)['admissible'] is True
        root.call_tool('operation_invoke', request)
        operation = catalog.operation(operation_id)
        worker = LocalWorkerMCPRouter(runtime.runs, operation_id=operation_id, operation_digest=operation.digest)
        return worker, worker.call_tool('worker_open_assignment', {})

    def submit(worker, opened, payload, verdict):
        run_id = next(item.run_id for item in runtime.runs.list(instance_id=instance.instance_id) if item.state == 'running')
        Path(opened['output_directory'], 'result.json').write_bytes(canonical_json({'schema_version': 1, 'handoff': {'verdict': verdict, 'summary': 'Bounded fixture result.'}, 'payload': payload}))
        status = worker.call_tool('worker_submit_result', {})
        assert status['state'] == 'completed', status
        return next(item for item in runtime.runs.list(instance_id=instance.instance_id) if item.run_id == run_id)

    plan = register('plan', 'scidiscovery.experiment-portfolio.v1', _FIXTURES['_plan']().canonical_json())
    worker, opened = invoke_worker('review', 'science.object.review.v1', {'experiment_plan': 'plan'})
    review = submit(worker, opened, {'review_target': 'experiment_portfolio', 'verdict': 'pass', 'summary': 'Bounded fixture plan is coherent.'}, 'pass')
    register('actual_result', 'opaque', b'Execution failed before observable output.', (plan.ref,))
    worker, opened = invoke_worker('analysis', 'science.result.diagnose.v1', {'experiment_plan': 'plan', 'experiment_review': review.output_binding_name, 'experiment_results': 'actual_result'})
    analysis = submit(worker, opened, limited_report(), 'blocked')
    artifact_id = runtime.scheduler_bindings.resolve(instance=instance.instance_id, namespace='artifact', name=analysis.output_binding_name)
    sealed = runtime.artifacts.get_by_id(artifact_id)
    sealed_bytes = runtime.artifacts.read(sealed.ref)
    assert b'remaining_contradiction' in sealed_bytes

    # Foundation qualification is fixture-only; the analysis/feedback route itself
    # uses unchanged Root admission, actual Run outputs, and the installed reader.
    foundation = register('foundation', 'scidiscovery.scientific-foundation.v1', b'{}')
    register('objective', 'scidiscovery.research-objective.v1', b'{}', (foundation.ref,))
    hypothesis = register('hypotheses', 'scidiscovery.hypothesis-proposal.v2', b'{}', (foundation.ref,))
    register('critic', 'scidiscovery.critic-review.v2', b'{}', (foundation.ref, hypothesis.ref))
    monkeypatch.setattr(runtime.approvals, 'are_subjects_approved_by_provider', lambda *a, **k: True)
    worker, opened = invoke_worker('next_design', 'science.experiment.design.v1', {'scientific_foundation': 'foundation', 'research_objective': 'objective', 'hypothesis_portfolio': 'hypotheses', 'critic_review': 'critic', 'result_analysis': analysis.output_binding_name})
    # Exact sealed bytes are delivered to the next design's bound inventory.
    next_run = next(item for item in runtime.runs.list(instance_id=instance.instance_id) if item.operation_id == 'science.experiment.design.v1')
    binding = next(item for item in next_run.inputs if item.port_name == 'result_analysis')
    assert binding.artifact_ref == sealed.ref
    assert runtime.artifacts.read(binding.artifact_ref) == sealed_bytes
    delivered = next((Path(opened['workspace_path']) / 'inputs').glob('result_analysis.*'))
    assert delivered.read_bytes() == sealed_bytes


@pytest.mark.parametrize('record_kind', ['unsupported', 'failed', 'unrelated'])
def test_record_presence_cannot_grant_quantitative_pass(record_kind):
    sources, request = score_inputs()
    if record_kind == 'unsupported':
        request['comparison_spec']['comparisons'][0]['operators'][0]['kind'] = 'unsupported_statistic'
    if record_kind == 'unrelated':
        request['comparison_spec']['comparisons'][0]['operators'][0]['validation_check_key'] = 'unrelated_check'
    record = evaluate_analysis_request(record_key='score', request=request, sources=sources)
    report = _FIXTURES['_passing_diagnosis']().model_dump(mode='json')
    report['evidence'][0]['locator'] = 'calculation_records:score'
    report['calculation_records'] = [record.model_dump(mode='json')]
    with pytest.raises(SemanticRuleViolation, match='quantitative checks|unfinished calculation'):
        Components.diagnosis_context.implementation(report, {'experiment_plan': _FIXTURES['_plan']().canonical_json(), **sources}, {})


def test_inconclusive_observation_can_submit_without_scoring():
    report = _FIXTURES['_passing_diagnosis']().model_dump(mode='json')
    report['evidence'][0].update(source_key='experiment_results', locator='experiment_results:run_log')
    for gate in report['gates'].values():
        if isinstance(gate, dict) and gate.get('evidence_keys'):
            gate['evidence_keys'] = ['experiment_results']
    report['gates']['observation']['status'] = 'inconclusive'
    report['gates']['observation']['summary'] = 'The requested observable is absent.'
    report['overall_verdict'] = 'inconclusive'
    report['summary'] = 'Run prerequisites hold but the observation cannot be compared.'
    Components.diagnosis_context.implementation(report, {'experiment_plan': _FIXTURES['_plan']().canonical_json(), 'experiment_results': b'Run completed; observable missing.'}, {})


@pytest.mark.parametrize('location', ['request', 'source'])
def test_unknown_weighting_option_is_not_silently_scored_as_rms(location):
    sources, request = score_inputs()
    if location == 'request':
        request['weighting'] = 'original_row_groups'
    else:
        request['sources'][0]['weight_column'] = 'group_weight'
    record = evaluate_analysis_request(record_key='weighted', request=request, sources=sources)
    assert record.status == 'unsupported'
    replay_calculation(record, sources)


@pytest.mark.parametrize('comparisons', [[None], [42], ['invalid'], None])
def test_malformed_comparisons_return_replayable_unavailable(comparisons):
    sources, request = score_inputs()
    request['comparison_spec']['comparisons'] = comparisons
    record = evaluate_analysis_request(record_key='malformed', request=request, sources=sources)
    assert record.status == 'unavailable' and record.result is None
    replay_calculation(record, sources)


@pytest.mark.parametrize('documented', [False, True])
def test_relaxed_threshold_cannot_pass_the_original_planned_check(documented):
    sources, request = score_inputs()
    request['comparison_spec']['comparisons'][0]['operators'][0]['threshold']['value'] = 100.0
    record = evaluate_analysis_request(record_key='score', request=request, sources=sources)
    report = _FIXTURES['_passing_diagnosis']().model_dump(mode='json')
    report['evidence'][0]['locator'] = 'calculation_records:score'
    report['calculation_records'] = [record.model_dump(mode='json')]
    if documented:
        report['method_changes'] = ['Exploratory relaxed threshold, not the original acceptance criterion.']
    with pytest.raises(SemanticRuleViolation, match='method_changes|quantitative checks'):
        Components.diagnosis_context.implementation(report, {'experiment_plan': _FIXTURES['_plan']().canonical_json(), **sources}, {})


def test_deadline_stops_reading_more_inputs_and_error_can_be_replayed(monkeypatch):
    from types import SimpleNamespace
    import curve_score.analysis_tool as tool
    clock = [0.0]
    monkeypatch.setattr(tool.time, 'monotonic', lambda: clock[0])
    sources, request = score_inputs()
    request['sources'].append({'input_alias': 'second_bundle', 'format': 'bundle'})
    reads = []
    def read(name):
        reads.append(name)
        clock[0] = 6.0
        return sources['curve_bundle']
    raw = tool.score_tool(AnalysisScoreInput(record_key='timed', request=request),
        SimpleNamespace(remaining_seconds=10, read_input=read))
    record = CalculationRecord.model_validate_json(canonical_json(raw))
    assert record.status == 'error' and record.result is None
    assert reads == ['curve_bundle']
    replay_calculation(record, sources)


def test_expired_final_replay_is_correctable_and_no_score_still_submits():
    from scidiscovery.artifact_agent.service.run_outputs import ValidationSources
    sources, request = score_inputs()
    record = evaluate_analysis_request(record_key='score', request=request, sources=sources)
    report = limited_report()
    report['calculation_records'] = [record.model_dump(mode='json')]
    bound = ValidationSources({'experiment_plan': _FIXTURES['_plan']().canonical_json(),
        'experiment_results': b'failure', **sources}, {}, validation_deadline=0.0)
    with pytest.raises(SemanticRuleViolation, match='replay budget exhausted'):
        Components.diagnosis_context.implementation(report, bound, {})
    report['calculation_records'] = []
    Components.diagnosis_context.implementation(report, bound, {})


def test_score_tool_contract_describes_comparison_and_rejects_invalid_record_key():
    description = AnalysisScoreInput.model_json_schema()['properties']['request']['description']
    assert all(word in description for word in ('series_declarations', 'residual_rms', 'x_column', 'dataset_name'))
    with pytest.raises(ValueError):
        AnalysisScoreInput(record_key='bad key', request={})


def test_matching_plan_check_can_still_pass_with_computed_evidence():
    import json
    sources, request = score_inputs()
    bundle = json.loads(sources['curve_bundle'])
    by_key = {item['series_key']: item for item in bundle['series']}
    comparison = request['comparison_spec']['comparisons'][0]
    by_key[comparison['candidate_series']]['points'] = by_key[comparison['reference_series']]['points']
    sources['curve_bundle'] = canonical_json(bundle)
    record = evaluate_analysis_request(record_key='score', request=request, sources=sources)
    report = _FIXTURES['_passing_diagnosis']().model_dump(mode='json')
    report['evidence'][0]['locator'] = 'calculation_records:score'
    report['calculation_records'] = [record.model_dump(mode='json')]
    Components.diagnosis_context.implementation(report, {'experiment_plan': _FIXTURES['_plan']().canonical_json(), **sources}, {})
